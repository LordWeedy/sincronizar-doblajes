"""
actualizador_ventana.py - La parte visible de las actualizaciones de Sync Master (actualizador.py).

En la ventana del programa: el número de versión con el botón «Actualizar» a su derecha (solo si hay una versión
nueva y compatible), la ventana con las novedades y el progreso real de la descarga, y lo que hace falta para cerrar
y volver a abrir el programa sin perder la lista de episodios. En el proceso ayudante: una ventana pequeña con lo que
está haciendo mientras el programa está cerrado.
"""

import os
import queue
import threading
import time

import tkinter as tk
from tkinter import ttk

VERSION = '1.4'

PALETA = {'bg': '#2b2b2b', 'fg': '#f5f5f5', 'muted': '#a8a8a8', 'ok': '#5cc74a', 'error': '#ef5350',
          'aviso': '#f0a030', 'entry_bg': '#3c3f41', 'entry_fg': '#f5f5f5', 'select_bg': '#4a90d9'}


def _legible(n):
    if n < 1024:
        return f"{n} B"
    if n < 1 << 20:
        return f"{n / 1024:.1f} KB".replace(".", ",")
    return f"{n / 1048576:.2f} MB".replace(".", ",")


# ---------------------------------------------------------------------------------------------------------------
# En la ventana del programa

class Integracion:
    """Une la GUI con actualizador.py. Nada de aquí puede romper la GUI: los fallos se apuntan y se sigue."""
    COMPROBANDO = "Comprobando la actualización..."

    def __init__(self, app, nucleo, raiz, versiones, arranque=None, trabajo=None, leer_informe=None,
                 en_curso=(), paleta=None):
        self.app, self.n, self.raiz = app, nucleo, os.path.realpath(raiz)
        self.versiones = dict(versiones)
        self.version = self.versiones.get("Sincronizar_Doblaje_Gui")
        self.arranque = arranque or {}
        self.trabajo, self.leer_informe, self.en_curso = trabajo, leer_informe, tuple(en_curso)
        self.paleta = paleta or (lambda: PALETA)
        self.cwd = os.getcwd()
        self.desarrollo = os.path.isfile(os.path.join(self.raiz, "publicacion", "publicar_version.py"))
        self.configurado = bool(nucleo.SERVIDORES and nucleo.CLAVES_PUBLICAS)
        self.registro = nucleo.Registro(self.raiz)
        self.instancia = nucleo.registrar_instancia(self.raiz, "gui")
        self.q = queue.Queue()
        self.comprobacion = None
        self.dialogo = None
        self.comprobando = False
        self.marco = None
        self._abierta_sola = set()     # versiones cuya ventana ya se ha abierto sola desde que se abrió el programa

    # --- barra de la versión ---
    def crear_barra(self, padre):
        self.marco = ttk.Frame(padre)
        self.etiqueta = ttk.Label(self.marco, text=f"Versión {self.version}")
        self.etiqueta.pack(side="left")
        self.boton = ttk.Button(self.marco, text="Actualizar", command=self.abrir_dialogo)
        self.estado = ttk.Label(self.marco, text="", style="Muted.TLabel", cursor="")
        self.estado.pack(side="left", padx=(10, 0))
        self.estado.bind("<Button-1>", lambda e: self._ver_detalle())
        self.detalle = None
        if self.desarrollo:
            self._poner_estado("· copia de desarrollo (aquí se publican las versiones)", "muted")
        return self.marco

    def _poner_estado(self, texto, tipo="muted", detalle=None):
        try:
            self.estado.configure(text=texto, style={"ok": "Ok.TLabel", "aviso": "Aviso.TLabel"}.get(tipo,
                                                                                                   "Muted.TLabel"),
                                  cursor="hand2" if detalle else "")
            self.detalle = detalle
        except tk.TclError:
            pass

    def _ver_detalle(self):
        if self.detalle:
            mensaje(self.app.master, "Actualización", self.detalle, self.paleta())

    def _mostrar_boton(self, texto=None):
        if texto:
            self.boton.configure(text=texto)
            if not self.boton.winfo_manager():
                self.boton.pack(side="left", padx=(8, 0), before=self.estado)
        elif self.boton.winfo_manager():
            self.boton.pack_forget()

    # --- al abrir ---
    def empezar(self):
        try:
            ttk.Style().configure("Ok.TLabel", background=self.paleta()['bg'], foreground=self.paleta()['ok'])
        except tk.TclError:
            pass
        self._mostrar_resultado()
        pendiente = self.arranque if self.arranque.get("salud") else None
        if not pendiente:
            p = self._seguro(lambda: self.n.pendiente_de_salud(self.raiz))
            if p:
                pendiente = {"salud": p[0], "hacia": p[1]}
        if pendiente and pendiente.get("hacia") == self.version:
            # la señal de arranque, ya con la ventana entera montada y respondiendo; el ayudante la confirma después
            self.app.master.after(1500, lambda: self._seguro(
                lambda: self.n.escribir_salud(self.raiz, pendiente["salud"], self.versiones)))
            self._poner_estado(self.COMPROBANDO, "muted")
            self.app.master.after(2000, lambda: self._esperar_resultado(time.time()))
        self._seguro(self._restaurar_sesion)
        if self.instancia is not None:
            self.app.master.after(2000, self._mirar_peticiones)
        if self.configurado and not self.desarrollo:
            self.app.master.after(4000, self.comprobar_ya)
        self.app.master.after(200, self._sondear)

    def _mostrar_resultado(self):
        res = self._seguro(lambda: self.n.leer_resultado(self.raiz))
        if not res:
            return False
        if res.get("ok"):
            self._poner_estado(f"✔ {res['mensaje']}", "ok")
        else:
            self._poner_estado("⚠ No se ha podido actualizar (clic para ver por qué)", "aviso",
                               res.get("mensaje", "") + (f"\n\nDetalle técnico:\n{res['detalle'][-1500:]}"
                                                         if res.get("detalle") else ""))
        return True

    def _esperar_resultado(self, desde):
        try:
            if self._mostrar_resultado():
                return
            if time.time() - desde > self.n.T_SALUD + 30:
                self._poner_estado("")
                return
            self.app.master.after(500, lambda: self._esperar_resultado(desde))
        except tk.TclError:
            pass

    def _seguro(self, funcion):
        try:
            return funcion()
        except Exception as e:
            try:
                self.registro(f"GUI: {type(e).__name__}: {e}")
            except Exception:
                pass
            return None

    # --- comprobar en segundo plano, al abrir y cada pocas horas ---
    def comprobar_ya(self):
        if not self.comprobando:
            self.comprobando = True
            threading.Thread(target=self._comprobar, daemon=True).start()
        self.app.master.after(int(self.n.PERIODO_COMPROBACION * 1000), self.comprobar_ya)

    def _comprobar(self):
        try:
            red = self.n.Red(registro=self.registro)
            self.q.put(("comprobado", self.n.comprobar(self.raiz, self.version, red)))
        except Exception as e:
            self.registro(f"Comprobación de versión nueva: {self.n.mensaje_de(e)}")
            self.q.put(("sin_respuesta", self.n.mensaje_de(e)))

    def _sondear(self):
        try:
            while True:
                tipo, dato = self.q.get_nowait()
                if tipo == "comprobado":
                    self.comprobando = False
                    self.comprobacion = dato
                    if dato.estado == "disponible":
                        self._mostrar_boton(f"Actualizar a la {dato.pub.version}")
                        # el resultado de la última actualización (o su comprobación en marcha) se queda a la vista
                        if not str(self.estado.cget("text")).startswith(("⚠", "✔", self.COMPROBANDO)):
                            self._poner_estado("")
                        self._abrir_sola(dato.pub.version)
                    else:
                        self._mostrar_boton(None)
                        if dato.estado == "incompatible":
                            self._poner_estado(f"(hay una versión nueva, la {dato.pub.version}, pero {dato.motivo})",
                                               "muted")
                elif tipo == "sin_respuesta":
                    self.comprobando = False
        except queue.Empty:
            pass
        except tk.TclError:
            return
        try:
            self.app.master.after(200, self._sondear)
        except tk.TclError:
            pass

    # --- trabajos en marcha ---
    def ocupado(self):
        hilo = getattr(self.app, "worker_thread", None)
        return bool(hilo is not None and hilo.is_alive())

    def marcar_ocupado(self, ocupado, que=""):
        if self.instancia is not None:
            self._seguro(lambda: self.instancia.marcar(ocupado, que))

    def _mirar_peticiones(self):
        """Otra actualización (de otra ventana o de la consola) pide que esta se cierre: solo si no trabaja."""
        try:
            if self.instancia.peticion_de_cierre():
                if self.ocupado():
                    self.instancia.responder("ocupado")
                else:
                    self.instancia.responder("cerrando")
                    self._seguro(self.app._guardar_ajustes)
                    self.instancia.cerrar()
                    self.app.master.destroy()
                    return
            self.app.master.after(2000, self._mirar_peticiones)
        except tk.TclError:
            pass
        except Exception as e:
            texto = f"Petición de cierre: {e}"
            self._seguro(lambda: self.registro(texto))

    # --- conservar la lista de episodios al cerrar y abrir ---
    def guardar_sesion(self, id_):
        a = self.app
        trabajos = []
        for j in a.trabajos:
            trabajos.append({"clave": list(j.clave) if j.clave else None, "doblaje": j.doblaje, "original": j.original,
                             "sub": j.sub, "sub_quitado": j.sub_quitado, "sub_auto": j.sub_auto,
                             "nombre_mux": j.nombre_mux, "correcciones": j.correcciones,
                             "estado": None if j.estado in self.en_curso else j.estado, "log": j.log,
                             "salida": j.salida})
        opciones = {}
        for clave in ("output_folder", "sobrescribir", "forzados", "limpiar"):
            var = getattr(a, clave, None)
            if var is not None:
                opciones[clave] = var.get()
        self.n.escribir_json(self.n.Rutas(self.raiz).sesion, {"id": id_, "trabajos": trabajos, "opciones": opciones})

    def _restaurar_sesion(self):
        id_ = os.environ.get("SINCRONIZAR_ACTUALIZACION")
        ruta = self.n.Rutas(self.raiz).sesion
        if not id_ or not os.path.exists(ruta):
            return
        s = self.n.leer_json(ruta) or {}
        if s.get("id") != id_ or self.trabajo is None:
            return
        os.remove(ruta)
        a = self.app
        for t in s.get("trabajos", []):
            j = self.trabajo(tuple(t["clave"]) if t.get("clave") else None)
            for campo in ("doblaje", "original", "sub", "sub_quitado", "sub_auto", "nombre_mux", "correcciones",
                          "estado", "salida"):
                if campo in t:
                    setattr(j, campo, t[campo])
            j.log = list(t.get("log") or [])
            if j.log and self.leer_informe and j.estado and j.estado != "Cancelado":
                try:
                    j.res = self.leer_informe(j.log)
                except Exception:
                    j.res = None
            a.trabajos.append(j)
        for clave, valor in (s.get("opciones") or {}).items():
            var = getattr(a, clave, None)
            if var is not None:
                try:
                    var.set(valor)
                except tk.TclError:
                    pass
        a._refresh_list()
        if a.trabajos:
            a.status_text.set(f"Se ha recuperado la lista de episodios ({len(a.trabajos)}) de antes de actualizar.")

    # --- la ventana de la actualización ---
    def _abrir_sola(self, version):
        """Con una versión nueva, la ventana de la actualización se abre sola (pedido del usuario, 28-10-2026: sin tener
        que pulsar «Actualizar»), una vez por versión cada vez que se abre el programa; si se cierra, queda el botón.
        Con una tanda en marcha espera a que termine; recién actualizado, a que se compruebe que esa ha ido bien. Si la
        última actualización falló, no (queda el aviso y el botón)."""
        try:
            c = self.comprobacion
            if version in self._abierta_sola or not c or c.estado != "disponible" or c.pub.version != version:
                return
            if self.dialogo is not None and self.dialogo.vivo():
                self._abierta_sola.add(version)
                return
            texto = str(self.estado.cget("text"))
            if texto.startswith("⚠"):
                return
            if texto.startswith(self.COMPROBANDO) or self.ocupado():
                self.app.master.after(1000 if texto.startswith(self.COMPROBANDO) else 30000,
                                      lambda: self._abrir_sola(version))
                return
            self._abierta_sola.add(version)
            self.abrir_dialogo()
        except tk.TclError:
            pass

    def abrir_dialogo(self):
        if self.dialogo is not None and self.dialogo.vivo():
            self.dialogo.ventana.lift()
            return
        if not self.comprobacion or self.comprobacion.estado != "disponible":
            return
        self.dialogo = Dialogo(self, self.comprobacion)

    def instalar(self, plan, carpeta):
        """Con todo descargado y comprobado: guarda lo necesario, lanza el ayudante y cierra la ventana."""
        if self.ocupado():
            raise self.n.Ocupado("Hay una tanda en marcha: se podrá actualizar cuando termine.")
        otras = self.n.ocupadas(self.raiz, excepto=self.instancia.id if self.instancia else None)
        if otras:
            raise self.n.Ocupado(f"Hay {self.n.describir_instancia(otras[0])} con un trabajo en marcha: se podrá "
                                 "actualizar cuando termine.")
        self._seguro(self.app._guardar_ajustes)
        sin_ventana = os.environ.get("SINCRONIZAR_ACTUALIZADOR_SIN_VENTANA") == "1"
        id_ = self.n.lanzar_ayudante(self.raiz, plan, carpeta, self.n.orden_de_arranque(),
                                     instancia=self.instancia.id if self.instancia else None, cwd=self.cwd,
                                     ventana=not sin_ventana)
        self.guardar_sesion(id_)
        if self.instancia is not None:
            self.instancia.cerrar()
        self.app.master.after(100, self.app.master.destroy)


class Dialogo:
    """Novedades, descarga con su progreso real y el paso de instalar (que cierra y vuelve a abrir el programa)."""

    def __init__(self, integ, comprobacion):
        self.i, self.c = integ, comprobacion
        self.n = integ.n
        pal = integ.paleta()
        self.q = queue.Queue()
        self.cancelar = threading.Event()
        self.hilo = None
        self.plan = self.carpeta = None
        m = comprobacion.pub.manifiesto
        v = self.ventana = tk.Toplevel(integ.app.master)
        v.title("Actualizar Sync Master")
        v.configure(background=pal['bg'])
        v.transient(integ.app.master)
        v.minsize(560, 420)
        marco = ttk.Frame(v, padding=16)
        marco.pack(fill="both", expand=True)
        marco.grid_columnconfigure(0, weight=1)
        marco.grid_rowconfigure(2, weight=1)
        ttk.Label(marco, style="Bold.TLabel",
                  text=f"Versión nueva: {m['version']}   (tienes la {integ.version})").grid(row=0, column=0, sticky="w")
        ttk.Label(marco, text="Novedades:", style="Muted.TLabel").grid(row=1, column=0, sticky="w", pady=(10, 2))
        texto = tk.Text(marco, height=12, wrap="word", background=pal['entry_bg'], foreground=pal['entry_fg'],
                        relief="flat", padx=8, pady=6, font="TkDefaultFont")
        texto.insert("1.0", m["notas"].strip() or "(sin notas)")
        texto.configure(state=tk.DISABLED)
        texto.grid(row=2, column=0, sticky="nsew")
        self.fase = tk.StringVar(value="Se descargan solo los archivos que cambian; el programa sigue funcionando "
                                       "mientras tanto.")
        ttk.Label(marco, textvariable=self.fase, wraplength=620, justify="left").grid(row=3, column=0, sticky="w",
                                                                                       pady=(12, 2))
        self.barra = ttk.Progressbar(marco, mode="determinate", maximum=1, value=0)
        self.barra.grid(row=4, column=0, sticky="ew")
        self.cifras = tk.StringVar(value="")
        ttk.Label(marco, textvariable=self.cifras, style="Muted.TLabel").grid(row=5, column=0, sticky="w", pady=(2, 0))
        self.error = tk.StringVar(value="")
        ttk.Label(marco, textvariable=self.error, style="Aviso.TLabel", wraplength=620,
                  justify="left").grid(row=6, column=0, sticky="w", pady=(6, 0))
        botones = ttk.Frame(marco)
        botones.grid(row=7, column=0, pady=(12, 0), sticky="e")
        self.principal = ttk.Button(botones, text="Descargar e instalar", command=self._principal)
        self.principal.pack(side="left", padx=(0, 6))
        self.cerrar_b = ttk.Button(botones, text="Cerrar", command=self.cerrar)
        self.cerrar_b.pack(side="left")
        v.protocol("WM_DELETE_WINDOW", self.cerrar)
        self.estado = "inicio"
        v.after(150, self._sondear)

    def vivo(self):
        try:
            return bool(self.ventana.winfo_exists())
        except tk.TclError:
            return False

    def _principal(self):
        if self.estado in ("inicio", "error"):
            self._descargar()
        elif self.estado == "descargando":
            self.cancelar.set()
            self.principal.configure(state=tk.DISABLED)
            self.fase.set("Cancelando: no se ha cambiado nada del programa...")
        elif self.estado == "listo":
            self._instalar()

    def _descargar(self):
        self.estado = "descargando"
        self.cancelar.clear()
        self.error.set("")
        self.principal.configure(text="Cancelar", state=tk.NORMAL)
        self.fase.set("Comprobando qué archivos cambian...")
        self.barra.configure(mode="indeterminate")
        self.barra.start(12)
        self.hilo = threading.Thread(target=self._trabajo, daemon=True)
        self.hilo.start()

    def _trabajo(self):
        try:
            red = self.n.Red(registro=self.i.registro, cancelar=self.cancelar)
            plan = self.n.calcular_plan(self.i.raiz, self.c.pub, self.c.servidor, desde=self.i.version)
            if plan.vacio():
                self.q.put(("vacio", None))
                return
            self.q.put(("plan", plan))
            carpeta = self.n.preparar(self.i.raiz, plan, red, progreso=lambda **k: self.q.put(("progreso", k)))
            self.q.put(("listo", (plan, carpeta)))
        except Exception as e:
            self.i.registro(f"Descarga de la {self.c.pub.version}: {self.n.mensaje_de(e)} "
                            f"{getattr(e, 'detalle', '')}".rstrip())
            self.q.put(("cancelado" if isinstance(e, self.n.Cancelado) else "error", self.n.mensaje_de(e)))

    def _sondear(self):
        if not self.vivo():
            return
        try:
            while True:
                tipo, dato = self.q.get_nowait()
                if tipo == "plan":
                    n_arch = len(dato.descargas)
                    self.fase.set(f"Hay que descargar {n_arch} archivo(s), {_legible(dato.bytes)} en total"
                                  + (f", y retirar {sum(1 for o in dato.operaciones if o['tipo'] == 'retirar')}"
                                     if any(o['tipo'] == 'retirar' for o in dato.operaciones) else "") + ".")
                elif tipo == "progreso":
                    self._progreso(dato)
                elif tipo == "vacio":
                    self.estado = "inicio"
                    self.barra.stop()
                    self.barra.configure(mode="determinate", maximum=1, value=1)
                    self.fase.set("Todos los archivos ya están como en la versión nueva; no hay nada que descargar.")
                    self.principal.configure(text="Descargar e instalar", state=tk.DISABLED)
                elif tipo == "listo":
                    self.plan, self.carpeta = dato
                    self.estado = "listo"
                    self.barra.stop()
                    self.barra.configure(mode="determinate", maximum=1, value=1)
                    self.fase.set("Descargado y comprobado (tamaño, SHA-256 y que el código se puede leer). Al "
                                  "instalar, el programa se cierra, se cambian los archivos y se vuelve a abrir "
                                  "solo; la lista de episodios se conserva.")
                    self.principal.configure(text="Instalar y volver a abrir", state=tk.NORMAL)
                elif tipo in ("error", "cancelado"):
                    self.estado = "error"
                    self.barra.stop()
                    self.barra.configure(mode="determinate", maximum=1, value=0)
                    if tipo == "cancelado":
                        self.fase.set("Descarga cancelada. No se ha cambiado nada del programa; lo descargado se "
                                      "aprovecha la próxima vez.")
                        self.error.set("")
                    else:
                        self.fase.set("No se ha podido descargar. El programa sigue como estaba.")
                        self.error.set(dato)
                    self.principal.configure(text="Reintentar", state=tk.NORMAL)
        except queue.Empty:
            pass
        if self.estado == "listo":
            if self.i.ocupado():
                self.principal.configure(state=tk.DISABLED)
                self.error.set("Hay una tanda en marcha: podrás instalar cuando termine (no se interrumpe).")
            elif str(self.principal.cget("state")) == tk.DISABLED:
                self.principal.configure(state=tk.NORMAL)
                self.error.set("")
        self.ventana.after(150, self._sondear)

    def _progreso(self, k):
        fase = k.get("fase")
        if fase == "reintento":
            self.error.set(k.get("mensaje", ""))
            return
        total = k.get("total") or 0
        if fase == "descargando":
            if str(self.barra.cget("mode")) != "determinate":
                self.barra.stop()
                self.barra.configure(mode="determinate")
            self.barra.configure(maximum=max(total, 1), value=k.get("hecho_total", 0))
            if k.get("archivo"):
                self.error.set("")
                self.fase.set(f"Descargando {k['archivo']} ({k['n']} de {k['de']})")
                self.cifras.set(f"{_legible(k.get('hecho') or 0)} de {_legible(k.get('tamano') or 0)} · total "
                                f"{_legible(k.get('hecho_total', 0))} de {_legible(total)}")
            else:
                self.cifras.set(f"{_legible(k.get('hecho_total', 0))} de {_legible(total)} ya descargados antes")
        elif fase == "verificando":
            self.fase.set("Comprobando lo descargado...")

    def _instalar(self):
        if self.i.ocupado():
            return
        self.principal.configure(state=tk.DISABLED)
        self.cerrar_b.configure(state=tk.DISABLED)
        self.fase.set("Cerrando el programa para instalar...")
        try:
            self.i.instalar(self.plan, self.carpeta)
        except Exception as e:
            self.estado = "listo"
            self.error.set(self.n.mensaje_de(e))
            self.principal.configure(state=tk.NORMAL)
            self.cerrar_b.configure(state=tk.NORMAL)

    def cerrar(self):
        if self.estado == "descargando":
            self.cancelar.set()
        try:
            self.ventana.destroy()
        except tk.TclError:
            pass


def mensaje(padre, titulo, texto, pal):
    v = tk.Toplevel(padre)
    v.title(titulo)
    v.configure(background=pal['bg'])
    v.transient(padre)
    marco = ttk.Frame(v, padding=16)
    marco.pack(fill="both", expand=True)
    ttk.Label(marco, text=texto, wraplength=560, justify="left").pack(anchor="w")
    ttk.Button(marco, text="Cerrar", command=v.destroy).pack(pady=(12, 0))


# ---------------------------------------------------------------------------------------------------------------
# En el proceso ayudante (con el programa cerrado)

class VentanaAyudante:
    """Ventana pequeña del ayudante. ejecutar(trabajo) corre trabajo(ui) en un hilo y la ventana va contando lo
    que pasa; se cierra sola si todo va bien."""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Sync Master · actualizando")
        self.root.configure(background=PALETA['bg'])
        self.root.resizable(False, False)
        self.q = queue.Queue()
        marco = tk.Frame(self.root, background=PALETA['bg'], padx=22, pady=16)
        marco.pack(fill="both", expand=True)
        self.fase_v = tk.StringVar(value="Preparando...")
        self.detalle_v = tk.StringVar(value="")
        tk.Label(marco, textvariable=self.fase_v, background=PALETA['bg'], foreground=PALETA['fg'],
                 font=("TkDefaultFont", 10, "bold"), wraplength=460, justify="left").pack(anchor="w")
        estilo = ttk.Style(self.root)
        try:
            estilo.theme_use("clam")
        except tk.TclError:
            pass
        estilo.configure("Horizontal.TProgressbar", background=PALETA['select_bg'], troughcolor=PALETA['entry_bg'])
        self.barra = ttk.Progressbar(marco, mode="determinate", length=460, maximum=1, value=0)
        self.barra.pack(fill="x", pady=(10, 4))
        self.detalle_l = tk.Label(marco, textvariable=self.detalle_v, background=PALETA['bg'],
                                  foreground=PALETA['muted'], wraplength=460, justify="left")
        self.detalle_l.pack(anchor="w")
        self.boton = ttk.Button(marco, text="Cerrar", command=self.root.destroy)
        self.codigo = 1
        self.root.protocol("WM_DELETE_WINDOW", lambda: None)

    # (llamadas desde el hilo de trabajo)
    def linea(self, t):
        pass

    def fase(self, t):
        self.q.put(("fase", t))

    def aplicando(self, i, n, ruta):
        self.q.put(("aplicando", (i, n, ruta)))

    def esperando(self, version, t):
        self.q.put(("esperando", (version, t)))

    def fin(self, ok, texto):
        self.q.put(("fin", (ok, texto)))

    def ejecutar(self, trabajo):
        def hilo():
            try:
                self.codigo = trabajo(self)
            except Exception as e:
                self.fin(False, f"Fallo inesperado: {e}")
            self.q.put(("terminado", None))
        threading.Thread(target=hilo, daemon=True).start()
        self.root.after(100, self._sondear)
        self.root.mainloop()
        return self.codigo

    def _sondear(self):
        terminado = False
        try:
            while True:
                tipo, dato = self.q.get_nowait()
                if tipo == "fase":
                    self.fase_v.set(dato)
                    self.detalle_v.set("")
                    self.barra.stop()
                    self.barra.configure(mode="determinate", maximum=1, value=0)
                elif tipo == "aplicando":
                    i, n, ruta = dato
                    self.barra.configure(mode="determinate", maximum=n, value=i)
                    self.detalle_v.set(f"{i} de {n}: {ruta}")
                elif tipo == "esperando":
                    version, t = dato
                    if str(self.barra.cget("mode")) != "indeterminate":
                        self.barra.configure(mode="indeterminate")
                        self.barra.start(15)
                    self.detalle_v.set(f"Esperando a que la versión {version} se abra y diga que funciona "
                                       f"({int(t)} s)")
                elif tipo == "fin":
                    ok, texto = dato
                    self.barra.stop()
                    self.barra.configure(mode="determinate", maximum=1, value=1 if ok else 0)
                    if texto:
                        self.fase_v.set(texto if ok else "No se ha actualizado")
                        self.detalle_v.set("" if ok else texto)
                        self.detalle_l.configure(foreground=PALETA['muted'] if ok else PALETA['aviso'])
                    self.ok = ok
                elif tipo == "terminado":
                    terminado = True
        except queue.Empty:
            pass
        if terminado:
            if getattr(self, "ok", False) or not self.detalle_v.get():
                self.root.after(1500, self.root.destroy)
            else:
                self.boton.pack(pady=(12, 0))
                self.root.protocol("WM_DELETE_WINDOW", self.root.destroy)
                self.root.after(60000, self.root.destroy)
            return
        self.root.after(100, self._sondear)
