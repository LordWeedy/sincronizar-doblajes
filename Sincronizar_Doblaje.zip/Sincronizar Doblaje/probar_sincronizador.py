"""Batería de pruebas del sincronizador, con la respuesta conocida: cada caso se fabrica a partir de vídeos cortos (de
G:\\cosas varias\\Intros y cosas random), se sincroniza con sincronizar_doblaje.py tal cual y se compara su informe con
lo que tiene que salir. Se pasa después de cada cambio del programa: si algo que funcionaba se rompe, sale FALLO.
Pedido del usuario (21-10-2026): «la robustez para no romper lo que ya funcionaba».

Uso:  python probar_sincronizador.py [--carpeta CARPETA] [--solo caso1,caso2] [--conservar]
Tarda unos minutos (vídeos de 1-4 min en SD). Los archivos fabricados van a una carpeta temporal que se borra al final
(con --conservar se deja, para mirar un fallo). Termina con código 1 si algún caso falla."""
import argparse, ast, builtins, os, re, shutil, subprocess, sys, tempfile, time

VERSION = '1.4.15'
AQUI = os.path.dirname(os.path.abspath(__file__))
MOTOR = os.path.join(AQUI, "sincronizar_doblaje.py")
CARPETA = r"G:\cosas varias\Intros y cosas random"
BASE = "TVE 1 (Continuidad).mp4"            # 3:41, 640x480, 25 fps
CORTO = "Cocodrilos al rescate.mp4"         # 1:00
COLOR = "Motorratones de Marte.mp4"         # 1:01, 1080p HEVC con datos de color mal puestos («trc:reserved»)
OTRO_DIALOGO = "Vaya Semanita - El Katxi - MARTÍN DE IDIAZABAL (480p, h264, youtube).mp4"     # 5:06, otras voces
FONDO = [CORTO, "El locomundo de Tex Avery.mp4", COLOR, "Intro motorratones.mp4"]           # 4:08 seguidos
PAL = 1001 / 960


def ffmpeg(*args):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-v", "error", "-y", *args], capture_output=True, text=True,
                       errors="replace")
    if r.returncode:
        raise RuntimeError(f"ffmpeg: {r.stderr.strip()[-300:]}")


def hablar_en_ingles(wav, texto):
    """El texto dicho por una voz inglesa de Windows (la de serie, Zira) en wav; RuntimeError si no hay ninguna."""
    orden = ("Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
             "$v = $s.GetInstalledVoices() | Where-Object { $_.VoiceInfo.Culture.Name -like 'en-*' } | "
             "Select-Object -First 1; if (-not $v) { exit 3 }; $s.SelectVoice($v.VoiceInfo.Name); "
             f"$s.SetOutputToWaveFile('{wav}'); $s.Speak('{texto}'); $s.Dispose()")
    r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", orden], capture_output=True,
                       text=True, errors="replace")
    if r.returncode or not os.path.exists(wav):
        raise RuntimeError("no hay una voz inglesa de Windows para fabricar la prueba" if r.returncode == 3 else
                           f"la voz de Windows ha fallado: {r.stderr.strip()[-200:]}")


def tasa(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=sample_rate",
                        "-of", "csv=p=0", path], capture_output=True, text=True)
    return int(r.stdout.strip() or 48000)


def segundos(mmss):
    m, s = mmss.split(":")
    return int(m) * 60 + float(s)


def leer(texto):
    """Lo que interesa del informe (o de la salida, si no hay informe): error, inicio (ms, negativo si se recorta),
    cortes [(s, ms con signo)], velocidad, verificación, avisos."""
    r = dict(texto=texto, error=None, inicio=None, cortes=[], velocidad="", verif=None, avisos=[])
    en_avisos = False
    for linea in texto.splitlines():
        if linea.startswith("ERROR"):
            r["error"] = linea
        elif (m := re.match(r"^Inicio: (recortados|añadidos) (\d+) ms", linea)):
            r["inicio"] = int(m[2]) * (-1 if m[1] == "recortados" else 1)
        elif (m := re.match(r"^Corte\s+(\S+)\s+(inserta|recorta)\s+(\d+) ms", linea)):
            r["cortes"].append((segundos(m[1]), int(m[3]) * (-1 if m[2] == "recorta" else 1)))
        elif linea.startswith("Velocidad"):
            r["velocidad"] += linea + "\n"
        elif (m := re.match(r"^Verificación(?! \(con el castellano\)).*(?:desviación típica|mediana) ([\d.]+) ms, "
                            r"p90 ([\d.]+) ms", linea)):
            r["verif"] = (float(m[1]), float(m[2]))
        elif linea.startswith("Avisos:"):
            en_avisos = True
        elif en_avisos and linea.startswith("  - "):
            r["avisos"].append(linea[4:])
        else:
            en_avisos = False
    r["revisar"] = [a for a in r["avisos"] if a.startswith("[revisar] ")]
    return r


# --- comprobaciones (cada una devuelve una lista de fallos, vacía si todo va bien)
def sin_error(r):
    return [f"error: {r['error']}"] if r["error"] else []


def inicio(ms, tol):
    return lambda r: [] if r["inicio"] is not None and abs(r["inicio"] - ms) <= tol else \
        [f"inicio {r['inicio']} ms, se esperaba {ms:+d} ±{tol}"]


def cortes(n):
    return lambda r: [] if len(r["cortes"]) == n else [f"{len(r['cortes'])} cortes {r['cortes']}, se esperaban {n}"]


def un_corte(ms, tol, desde, hasta):
    def f(r):
        if len(r["cortes"]) != 1:
            return [f"{len(r['cortes'])} cortes {r['cortes']}, se esperaba uno de {ms:+d} ms"]
        t, d = r["cortes"][0]
        return ([] if abs(d - ms) <= tol else [f"el corte es de {d:+d} ms, se esperaba {ms:+d} ±{tol}"]) + \
               ([] if desde <= t <= hasta else [f"el corte va en {t:.2f} s, se esperaba entre {desde} y {hasta}"])
    return f


def contiene(texto, donde="texto"):
    return lambda r: [] if texto in r[donde] else [f"falta «{texto}»"]


def no_contiene(texto):
    return lambda r: [f"sale «{texto}»"] if texto in r["texto"] else []


def nada_que_revisar(r):
    return [f"avisa «{a}»" for a in r["revisar"]]


def verificacion(max_ms):
    return lambda r: [] if r["verif"] and r["verif"][0] <= max_ms else [f"verificación {r['verif']}, máx. {max_ms} ms"]


def error_con(texto):
    return lambda r: [] if r["error"] and texto in r["error"] else [f"se esperaba el error «{texto}», salió {r['error']}"]


def verif_castellano(max_ms):
    """La verificación con la propia pista doblada (con guía, 1.4.4): su p90, como mucho max_ms."""
    def f(r):
        m = re.search(r"Verificación \(con el castellano\): mediana ([\d.]+) ms, p90 ([\d.]+) ms", r["texto"])
        return [] if m and float(m[2]) <= max_ms else \
            [f"verificación con el castellano: {m[0] if m else 'no sale'}; se esperaba p90 <= {max_ms} ms"]
    return f


def correccion_sugerida(desde, hasta, ms, tol_ms):
    """Un aviso de trozo descolocado con su corrección a mano: que cubra desde-hasta (s, con 3 s de margen) y mueva ms."""
    def f(r):
        for m in re.finditer(r"la corrección a mano sería «(\d+):(\d\d)-(\d+):(\d\d) ([+-]\d+)»", r["texto"]):
            a, b = int(m[1]) * 60 + int(m[2]), int(m[3]) * 60 + int(m[4])
            if a <= desde + 3 and b >= hasta - 3 and a >= desde - 3 and b <= hasta + 3 and abs(int(m[5]) - ms) <= tol_ms:
                return []
        return [f"no sale la corrección de {desde}-{hasta} s ({ms:+d} ms)"]
    return f


def cortes_en(esperados, tol_ms, tol_s):
    """Los cortes [(s del doblaje, ms con signo)], en ese orden."""
    def f(r):
        if len(r["cortes"]) != len(esperados):
            return [f"{len(r['cortes'])} cortes {r['cortes']}, se esperaban {esperados}"]
        return [f"corte en {t:.2f} s de {d:+d} ms, se esperaba en {te} s de {de:+d} ms"
                for (t, d), (te, de) in zip(r["cortes"], esperados) if abs(d - de) > tol_ms or abs(t - te) > tol_s]
    return f


def empalme_en(te, de, tol_ms, tol_s, mover=1.55):
    """El empalme de un relleno de de ms en te ±tol_s s del doblaje: ahí el corte, o (1.4.12: las frases enteras, también
    las castellanas que cruzan un empalme) el corte a menos de `mover` s y el informe diciendo que el empalme estaba ahí
    («Empalme del corte m:ss.cc: a ...»)."""
    def f(r):
        for t, d in r["cortes"]:
            if abs(d - de) > tol_ms:
                continue
            if abs(t - te) <= tol_s:
                return []
            for m in re.finditer(r"^Empalme del corte (\d+):([\d.]+): a (\d+):([\d.]+),", r["texto"], re.M):
                antes, ahora = int(m[1]) * 60 + float(m[2]), int(m[3]) * 60 + float(m[4])
                if abs(antes - te) <= tol_s and abs(ahora - t) < 0.02 and abs(t - te) <= mover:
                    return []
        return [f"no hay un relleno de {de:+d} ms empalmado en {te} ±{tol_s} s; cortes: {r['cortes']}"]
    return f


def corte_cerca(te, de, tol_ms, tol_s):
    """Que haya un corte de de ms (con signo) a te ±tol_s s del doblaje (para casos con cortes de tolerancias distintas:
    un recorte va al silencio más cercano, un relleno justo al empalme)."""
    return lambda r: [] if any(abs(d - de) <= tol_ms and abs(t - te) <= tol_s for t, d in r["cortes"]) else \
        [f"no hay un corte de {de:+d} ms en {te} ±{tol_s} s; cortes: {r['cortes']}"]


# --- los casos: (nombre, qué comprueba, cómo se fabrica el doblaje -> (doblaje, original), comprobaciones)
def casos(c, tmp):
    base, corto, color = (os.path.join(c, x) for x in (BASE, CORTO, COLOR))
    sr = tasa(base)
    t = lambda nombre: os.path.join(tmp, nombre)

    def limpio():
        ffmpeg("-i", base, "-map", "0:a:0", "-ac", "2", "-c:a", "flac", t("limpio.mka"))
        return t("limpio.mka"), base

    def desfase():
        ffmpeg("-i", base, "-map", "0:a:0", "-ac", "2", "-af", "adelay=1500|1500", "-c:a", "flac", t("desfase.mka"))
        return t("desfase.mka"), base

    def sobra():
        ffmpeg("-i", base, "-filter_complex", "[0:a]atrim=0:60,asetpts=PTS-STARTPTS[a1];[0:a]atrim=58,"
               "asetpts=PTS-STARTPTS[a2];[a1][a2]concat=n=2:v=0:a=1[a]", "-map", "[a]", "-ac", "2", "-c:a", "flac",
               t("sobra.mka"))
        return t("sobra.mka"), base

    def falta():
        ffmpeg("-i", base, "-filter_complex", "[0:a]atrim=0:90,asetpts=PTS-STARTPTS[a1];[0:a]atrim=91,"
               "asetpts=PTS-STARTPTS[a2];[a1][a2]concat=n=2:v=0:a=1[a]", "-map", "[a]", "-ac", "2", "-c:a", "flac",
               t("falta.mka"))
        return t("falta.mka"), base

    def pal():
        ffmpeg("-i", base, "-map", "0:a:0", "-ac", "2", "-af", f"asetrate={sr}*1001/960,aresample={sr}", "-c:a", "flac",
               t("pal.mka"))
        return t("pal.mka"), base

    def otra_mezcla_24():
        # (1.4.11, repaso de puntos débiles; la guía de otra mezcla de Top Dog, B): 7,5 min (TVE y el principio de Vaya
        # Semanita), el doblaje a 24 frente a 23,976 y «otra mezcla» (la misma energía en cada frecuencia con la fase al
        # azar: la onda no se parece y la envolvente sí). La 1.4.10 solo probaba la envolvente en PAL y, a la misma
        # velocidad, las ventanas de los minutos 1 a 7 se separan 120 ms cada dos: «¿es el mismo episodio?»
        ffmpeg("-i", base, "-i", os.path.join(c, OTRO_DIALOGO), "-filter_complex",
               "[0:a]aresample=48000,aformat=channel_layouts=stereo[a0];[1:a]atrim=0:230,aresample=48000,"
               "aformat=channel_layouts=stereo[a1];[a0][a1]concat=n=2:v=0:a=1,asetpts=N/SR/TB[o]", "-map", "[o]",
               "-c:a", "flac", "-metadata:s:a:0", "language=eng", t("otra_mezcla_original.mka"))
        ffmpeg("-i", t("otra_mezcla_original.mka"), "-af", "asetrate=48000*1001/1000,aresample=48000,afftfilt="
               "real='hypot(re,im)*cos(random(0)*2*PI)':imag='hypot(re,im)*sin(random(0)*2*PI)':win_size=2048",
               "-c:a", "flac", "-metadata:s:a:0", "language=spa", t("otra_mezcla_24.mka"))
        return t("otra_mezcla_24.mka"), t("otra_mezcla_original.mka")

    def pal_tono():
        ffmpeg("-i", base, "-map", "0:a:0", "-ac", "2", "-af", f"atempo={PAL:.10f}", "-c:a", "flac", t("pal_tono.mka"))
        return t("pal_tono.mka"), base

    def corto_pal():
        ffmpeg("-i", corto, "-map", "0:a:0", "-ac", "2", "-af",
               f"asetrate={tasa(corto)}*1001/960,aresample={tasa(corto)}", "-c:a", "flac", t("corto_pal.mka"))
        return t("corto_pal.mka"), corto

    def imagen_desplazada():
        ffmpeg("-itsoffset", "0.5", "-i", base, "-i", base, "-map", "0:v:0", "-map", "1:a:0", "-c", "copy",
               t("imagen_desplazada.mkv"))
        return t("imagen_desplazada.mkv"), base

    def escena_movida_audio():
        # (1.4.12; El último superviviente / Man vs. Wild 1x02: una escena que el doblaje pone 3 minutos antes, medida con
        # el audio, se quitaba como castellano que sobraba y su sitio iba con el original) la escena de 2:30-2:45 de TVE,
        # imagen y sonido, puesta en el 0:40. Va por el audio (el mismo sonido); tiene que volver a su sitio entera
        ffmpeg("-i", base, "-filter_complex",
               "[0:v]trim=0:40,setpts=PTS-STARTPTS[v1];[0:v]trim=150:165,setpts=PTS-STARTPTS[v2];"
               "[0:v]trim=40:150,setpts=PTS-STARTPTS[v3];[0:v]trim=165,setpts=PTS-STARTPTS[v4];"
               "[v1][v2][v3][v4]concat=n=4:v=1:a=0[v];[0:a]atrim=0:40,asetpts=N/SR/TB[a1];"
               "[0:a]atrim=150:165,asetpts=N/SR/TB[a2];[0:a]atrim=40:150,asetpts=N/SR/TB[a3];"
               "[0:a]atrim=165,asetpts=N/SR/TB[a4];[a1][a2][a3][a4]concat=n=4:v=0:a=1[a]",
               "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-c:a", "flac",
               t("escena_movida.mkv"))
        return t("escena_movida.mkv"), base

    def con_imagen():
        ffmpeg("-i", base, "-f", "lavfi", "-i", "anoisesrc=d=230:c=pink:r=48000", "-filter_complex",
               "[0:v]trim=0:63,setpts=PTS-STARTPTS[v1];[0:v]trim=60,setpts=PTS-STARTPTS[v2];[v1][v2]concat=n=2:v=1:a=0[v]",
               "-map", "[v]", "-map", "1:a:0", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-c:a", "aac",
               "-shortest", t("con_imagen.mp4"))
        return t("con_imagen.mp4"), base

    def color_raro():
        ffmpeg("-i", color, "-f", "lavfi", "-i", "anoisesrc=d=70:c=pink:r=48000", "-map", "0:v:0", "-map", "1:a:0",
               "-c:v", "copy", "-c:a", "aac", "-shortest", t("color.mkv"))
        return t("color.mkv"), color

    def destellos():
        # 15 s de destellos al principio (imagen normal e invertida cada 0,16 s, como la cabecera de Becker), en la
        # RAW y en el doblaje; al doblaje le faltan sus primeros 1,5 s (hay que añadírselos) y su audio no se parece
        # (se mide con la imagen)
        ffmpeg("-i", base, "-vf", r"negate=enable='lt(mod(t\,0.32)\,0.16)*lt(t\,15)'", "-c:v", "libx264",
               "-preset", "ultrafast", "-crf", "23", "-c:a", "copy", t("destellos_raw.mp4"))
        ffmpeg("-ss", "1.5", "-i", t("destellos_raw.mp4"), "-f", "lavfi", "-i", "anoisesrc=d=230:c=pink:r=48000",
               "-map", "0:v:0", "-map", "1:a:0", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-c:a", "aac",
               "-shortest", t("destellos.mp4"))
        return t("destellos.mp4"), t("destellos_raw.mp4")

    def lateral_rota():
        # La pelu del señor Pan 3x02 (27-10-2026): la guía, en AAC y con el tono corregido, tenía la lateral (L-R)
        # estropeada y la mezcla intacta; el programa miraba solo la lateral, daba el sonido por «otro» y medía con la
        # imagen. Aquí, en la RAW y en el doblaje, la lateral es ruido (distinto en cada uno) y la mezcla, el sonido;
        # el del doblaje, además, estirado y vuelto a encoger (la onda no coincide: hace falta la envolvente)
        lado = lambda semilla: (f"anoisesrc=d=230:c=pink:r={sr}:a=0.2:s={semilla}[n];[m][n]amerge=inputs=2,"
                                "pan=stereo|c0=0.6*c0+c1|c1=0.6*c0-c1[a]")
        ffmpeg("-i", base, "-filter_complex", "[0:a]pan=mono|c0=0.5*c0+0.5*c1[m];" + lado(1), "-map", "0:v:0",
               "-map", "[a]", "-c:v", "copy", "-c:a", "flac", "-shortest", t("lateral_rota_raw.mkv"))
        ffmpeg("-i", base, "-filter_complex", f"[0:a]atempo={PAL:.10f},atempo={1 / PAL:.10f},"
               "pan=mono|c0=0.5*c0+0.5*c1[m];" + lado(2), "-map", "0:v:0", "-map", "[a]", "-c:v", "copy",
               "-c:a", "flac", "-shortest", t("lateral_rota.mkv"))
        return t("lateral_rota.mkv"), t("lateral_rota_raw.mkv")

    def guia_sin_imagen():
        # un doblaje con imagen, su castellano (aquí ruido) y la guía inglesa, que es el audio de la RAW: con la guía
        # encajando en todo el episodio no se leen los vídeos (27-10-2026; antes, más de la mitad del tiempo)
        ffmpeg("-i", base, "-map", "0:v:0", "-map", "0:a:0", "-c", "copy", "-metadata:s:a:0", "language=eng",
               t("guia_raw.mkv"))
        ffmpeg("-i", base, "-f", "lavfi", "-i", f"anoisesrc=d=230:c=pink:r={sr}:a=0.1", "-map", "0:v:0", "-map", "1:a:0",
               "-map", "0:a:0", "-c:v", "copy", "-c:a:0", "flac", "-c:a:1", "copy", "-metadata:s:a:0", "language=spa",
               "-metadata:s:a:1", "language=eng", "-shortest", t("guia.mkv"))
        return t("guia.mkv"), t("guia_raw.mkv")

    def guia_sin_idioma():
        # La pelu del señor Pan 3x14: la guía (el audio de la RAW, con el tono corregido) sin idioma y un castellano;
        # con la envolvente, una pista sin idioma no se daba nunca por versión original (y se medía con la imagen)
        ffmpeg("-i", base, "-map", "0:v:0", "-map", "0:a:0", "-c", "copy", "-metadata:s:a:0", "language=eng",
               t("guia_sin_idioma_raw.mkv"))
        ffmpeg("-i", base, "-f", "lavfi", "-i", f"anoisesrc=d=230:c=pink:r={sr}:a=0.1", "-filter_complex",
               f"[0:a]atempo={PAL:.10f},atempo={1 / PAL:.10f}[g]", "-map", "0:v:0", "-map", "1:a:0", "-map", "[g]",
               "-c:v", "copy", "-c:a", "flac", "-metadata:s:a:0", "language=spa", "-metadata:s:a:1", "language=und",
               "-shortest", t("guia_sin_idioma.mkv"))
        return t("guia_sin_idioma.mkv"), t("guia_sin_idioma_raw.mkv")

    def etiquetas_cambiadas():
        # la versión original (con el tono corregido) etiquetada «spa» y el doblaje (aquí ruido) «eng»: con la onda no se
        # veía que la «castellana» tiene los diálogos del original, y se habría muxeado inglés como castellano
        ffmpeg("-i", base, "-f", "lavfi", "-i", f"anoisesrc=d=230:c=pink:r={sr}:a=0.1", "-filter_complex",
               f"[0:a]atempo={PAL:.10f},atempo={1 / PAL:.10f}[g]", "-map", "0:v:0", "-map", "[g]", "-map", "1:a:0",
               "-c:v", "copy", "-c:a", "flac", "-metadata:s:a:0", "language=spa", "-metadata:s:a:1", "language=eng",
               "-shortest", t("etiquetas_cambiadas.mkv"))
        ffmpeg("-i", base, "-map", "0:v:0", "-map", "0:a:0", "-c", "copy", "-metadata:s:a:0", "language=eng",
               t("etiquetas_cambiadas_raw.mkv"))
        return t("etiquetas_cambiadas.mkv"), t("etiquetas_cambiadas_raw.mkv")

    def ruido():
        ffmpeg("-f", "lavfi", "-i", "anoisesrc=d=221:c=pink:r=48000", "-ac", "2", "-c:a", "flac", t("ruido.mka"))
        return t("ruido.mka"), base

    def desfasada_de_la_guia():
        # Diagnóstico asesinato S06 (02-11-2026): dentro del doblaje el castellano no iba a la par de la guía (de 0 a 180
        # ms, distinto en cada trozo) y, con la verificación hecha con la guía, salía «0,0 ms». Aquí el castellano (los
        # graves del audio de la RAW, con otra «voz» encima) va 150 ms tarde entre 1:00 y 2:30, con silencios en los dos
        # empalmes; la guía, a la par
        ffmpeg("-i", base, "-map", "0:v:0", "-map", "0:a:0", "-c", "copy", "-metadata:s:a:0", "language=eng",
               t("desf_raw.mkv"))
        ffmpeg("-i", base, "-f", "lavfi", "-i", f"anoisesrc=d=230:c=white:r={sr}:a=0.3:s=7", "-filter_complex",
               "[0:a]aformat=channel_layouts=stereo,lowpass=f=300,lowpass=f=300,asplit=3[a][b][c];"
               "[a]atrim=0:60,asetpts=PTS-STARTPTS[a1];[b]atrim=59.85:149.85,asetpts=PTS-STARTPTS[b1];"
               "[c]atrim=150,asetpts=PTS-STARTPTS[c1];[a1][b1][c1]concat=n=3:v=0:a=1[me];"
               "[1:a]bandpass=f=1200:width_type=h:w=2000,aformat=channel_layouts=stereo[v];"
               "[me][v]amix=inputs=2:normalize=0:duration=first,"
               "volume=0:enable='between(t,59.6,60.4)+between(t,149.6,150.4)'[cas]",
               "-map", "0:v:0", "-map", "[cas]", "-map", "0:a:0", "-c:v", "copy", "-c:a:0", "flac", "-c:a:1", "copy",
               "-metadata:s:a:0", "language=spa", "-metadata:s:a:1", "language=eng", "-shortest", t("desf.mkv"))
        return t("desf.mkv"), t("desf_raw.mkv")

    def trozo_corto_descolocado():
        # 8 s (1:40-1:48) puestos 1,5 s fuera de su sitio: demasiado corto para ser un desfase de la medida (pide unos
        # 10 s), así que se monta con el de al lado; la verificación solo contaba lo que encaja y salía bien. Ahora lo
        # busca más lejos y avisa, con la corrección a mano que lo arreglaría (1.4.5)
        ffmpeg("-i", base, "-filter_complex", "[0:a]asplit=3[a][b][c];[a]atrim=0:100,asetpts=PTS-STARTPTS[a1];"
               "[b]atrim=101.5:109.5,asetpts=PTS-STARTPTS[b1];[c]atrim=108,asetpts=PTS-STARTPTS[c1];"
               "[a1][b1][c1]concat=n=3:v=0:a=1[a]", "-map", "[a]", "-ac", "2", "-c:a", "flac", t("descolocado.mka"))
        return t("descolocado.mka"), base

    def sonido_desfasado_por_trozos():
        # medido con la imagen (aquí, a la fuerza): el sonido del doblaje va 120 ms tarde de su imagen entre 1:00 y 2:30.
        # Seguir al sonido solo ve partes de 0,2 s o más; el contraste lo corrige (1.4.5)
        ffmpeg("-i", base, "-f", "lavfi", "-i", f"anoisesrc=d=230:c=white:r={sr}:a=0.3:s=7", "-filter_complex",
               "[0:a]aformat=channel_layouts=stereo,lowpass=f=300,lowpass=f=300,asplit=3[a][b][c];"
               "[a]atrim=0:60,asetpts=PTS-STARTPTS[a1];[b]atrim=59.88:149.88,asetpts=PTS-STARTPTS[b1];"
               "[c]atrim=150,asetpts=PTS-STARTPTS[c1];[a1][b1][c1]concat=n=3:v=0:a=1[me];"
               "[1:a]bandpass=f=1200:width_type=h:w=2000,aformat=channel_layouts=stereo[v];"
               "[me][v]amix=inputs=2:normalize=0:duration=first,"
               "volume=0:enable='between(t,59.6,60.4)+between(t,149.6,150.4)'[cas]",
               "-map", "0:v:0", "-map", "[cas]", "-c:v", "copy", "-c:a", "flac", "-metadata:s:a:0", "language=spa",
               "-shortest", t("sonido_trozos.mkv"))
        return t("sonido_trozos.mkv"), base, ["--medir", "video"]

    def desfasada_tono():
        # lo mismo en un DVD PAL con el tono corregido (como La pelu del señor Pan): castellano y guía acelerados sin
        # cambiar el tono; la onda no coincide con el original y se contrasta con la envolvente de los graves
        desfasada_de_la_guia()
        ffmpeg("-i", t("desf.mkv"), "-filter_complex", f"[0:a:0]atempo={PAL:.10f}[c];[0:a:1]atempo={PAL:.10f}[g]",
               "-map", "[c]", "-map", "[g]", "-c:a", "flac", "-metadata:s:a:0", "language=spa",
               "-metadata:s:a:1", "language=eng", t("desf_tono.mka"))
        return t("desf_tono.mka"), t("desf_raw.mkv")

    def empalme_en_mono():
        # One Piece 1x01 de Netflix (04-11-2026, prueba de un compañero del usuario): la escena de después de la
        # cortinilla iba en mono; con la lateral, que ahí calla, el empalme del relleno caía 1 s tarde, ese segundo de
        # ambiente sonaba dos veces y la música de la cortinilla entraba a medias. Aquí, un original con lateral de
        # verdad (otro vídeo en ella) y 6 s en mono justo después de un hueco de 10 s que le falta al doblaje
        # (1:30-1:40); el doblaje, con un ruido lateral muy bajo que no es el del original (como el de un códec). Con la
        # 1.4.5 el corte iba en 1:35,40 y la verificación decía «0,0 ms»
        ffmpeg("-i", base, "-stream_loop", "-1", "-i", corto, "-filter_complex",
               f"[0:a]pan=mono|c0=0.5*c0+0.5*c1[m];[1:a]aresample={sr},pan=mono|c0=0.5*c0+0.5*c1,volume=0.7,"
               "volume=0:enable='between(t,100,106)'[s];[m][s]amerge=inputs=2,pan=stereo|c0=c0+c1|c1=c0-c1[a]",
               "-map", "0:v:0", "-map", "[a]", "-c:v", "copy", "-c:a", "flac", "-shortest", t("mono_raw.mkv"))
        ffmpeg("-i", t("mono_raw.mkv"), "-f", "lavfi", "-i", f"anoisesrc=d=230:c=white:r={sr}:a=0.0001:s=3",
               "-filter_complex", "[0:a]asplit=2[a][b];[a]atrim=0:90,asetpts=PTS-STARTPTS[a1];[b]atrim=100,"
               "asetpts=PTS-STARTPTS[b1];[a1][b1]concat=n=2:v=0:a=1[d];[d][1:a]amerge=inputs=2,"
               "pan=stereo|c0=c0+c2|c1=c1-c2[a]", "-map", "[a]", "-c:a", "flac", "-shortest", t("mono.mka"))
        return t("mono.mka"), t("mono_raw.mkv")

    def estereo_otro_dialogo():
        # Lo de casi todos los doblajes de verdad (05-11-2026, tras la 1.4.6): estéreo con la misma música y efectos en
        # los dos y el diálogo en el centro, cada uno en su idioma. La lateral (L-R) lleva solo el fondo y encaja; la
        # mezcla (L+R) lleva el diálogo, distinto, y encaja poco. Los demás casos se fabrican con audios casi mono y se
        # miden con la mezcla, así que este es el que comprueba que medir también con la mezcla (1.4.6) no mueve nada
        # donde la lateral suena. Fondo: cuatro vídeos seguidos (sin bucles, que darían coincidencias cada vuelta), en
        # la lateral y algo en el centro. Al doblaje le sobran 2 s en el 1:00 y le faltan 8 s del 2:30 del original.
        # (asetpts=N/SR/TB: tiempos seguidos; sin él el doblaje salía con un salto de 40 ms en sus primeros paquetes, que
        # el motor lee como un reproductor, como un hueco, y el informe daba «recortados 40 ms»)
        fondo = [os.path.join(c, x) for x in FONDO]
        mezcla = "".join(f"[{i + 1}:a]aresample={sr},pan=mono|c0=0.5*c0+0.5*c1[f{i}];" for i in range(len(fondo))) + \
            "".join(f"[f{i}]" for i in range(len(fondo))) + f"concat=n={len(fondo)}:v=0:a=1[fondo];" + \
            f"[0:a]aresample={sr},pan=mono|c0=0.5*c0+0.5*c1[dlg];" + \
            "[dlg][fondo]amerge=inputs=2,pan=stereo|c0=0.6*c0+0.6*c1|c1=0.6*c0-0.2*c1,asetpts=N/SR/TB,atrim=0:221"
        entradas = [x for f in fondo for x in ("-i", f)]
        ffmpeg("-i", base, *entradas, "-filter_complex", mezcla + "[a]", "-map", "0:v:0", "-map", "[a]", "-c:v",
               "copy", "-c:a", "flac", "-shortest", t("dial_raw.mkv"))
        ffmpeg("-i", os.path.join(c, OTRO_DIALOGO), *entradas, "-filter_complex",
               mezcla + ",asplit=3[a][b][c];[a]atrim=0:60,asetpts=PTS-STARTPTS[a1];[b]atrim=58:150,asetpts=PTS-STARTPTS"
               "[b1];[c]atrim=158,asetpts=PTS-STARTPTS[c1];[a1][b1][c1]concat=n=3:v=0:a=1,asetpts=N/SR/TB[a]", "-map", "[a]",
               "-c:a", "flac", t("dial.mka"))
        return t("dial.mka"), t("dial_raw.mkv")

    def fondo_desplazado(nombre, voz_tambien, desplazado=True, callar=(), frases=False):
        # (1.4.12; El último superviviente / Man vs. Wild 1x02, 18-11-2026) en los primeros 2:33 del doblaje la música y
        # los efectos iban 2,35 y 1,43 s desplazados de su voz y de su imagen; medido con la lateral, el castellano salió
        # 2,35 s adelantado y sin su primera frase. Aquí, diálogo de verdad (Vaya Semanita) en el centro, con el tono
        # cambiado en el doblaje (otra voz, las frases a la par), y el fondo de estereo_otro_dialogo en la lateral; la
        # imagen, la de TVE en los dos. En el doblaje el fondo va 2 s tarde entre 0:02 y 1:10 (lo de 0:00-0:02, dos
        # veces). Con voz_tambien, la voz también: el sonido entero desplazado de su imagen, y ahí manda el audio
        fondo = [os.path.join(c, x) for x in FONDO]
        entradas = [x for f in fondo for x in ("-i", f)]
        f_ = "".join(f"[{i + 2}:a]aresample={sr},pan=mono|c0=0.5*c0+0.5*c1[f{i}];" for i in range(len(fondo))) + \
            "".join(f"[f{i}]" for i in range(len(fondo))) + f"concat=n={len(fondo)}:v=0:a=1,asetpts=N/SR/TB[fondo];"
        # (frases: la voz en frases de 3 s con 1,5 s de pausa, como una narración, en los dos; callar: trozos [(desde,
        # hasta)] sin la voz del doblaje)
        voz = lambda tono: (f"[1:a]aresample={sr},pan=mono|c0=0.5*c0+0.5*c1" +
                            (f",asetrate={sr}*1.06,aresample={sr},atempo={1 / 1.06:.6f}" if tono else "") +
                            ",atrim=0:221,asetpts=N/SR/TB" +
                            (r",volume=0:enable='gt(mod(t\,4.5)\,3)'" if frases else "") +
                            "".join(f",volume=0:enable='between(t,{c0},{c1})'" for c0, c1 in (callar if tono else ())) +
                            "[dlg];")
        raw = "frases_raw.mkv" if frases else "fondo_desplazado_raw.mkv"
        # (el fondo, en la lateral como en estereo_otro_dialogo, pero en el centro bajo, como en un doblaje de verdad: con
        # el 0,4 de aquel caso, la música de los dibujos tapaba la voz y voz_sonora marcaba el 2 % del tiempo, no el 23 %)
        formato = f"aformat=sample_fmts=fltp:sample_rates={sr}:channel_layouts=mono"
        mezclar = lambda d, f, o: (f"[{d}]{formato}[{d}_];[{f}]{formato}[{f}_];[{d}_][{f}_]amerge=inputs=2,"
                                   f"pan=stereo|c0=0.6*c0+0.45*c1|c1=0.6*c0-0.35*c1,atrim=0:221,asetpts=N/SR/TB[{o}]")
        desplazar = lambda x, o: (f"[{x}]asplit=3[{x}a][{x}b][{x}c];[{x}a]atrim=0:2,asetpts=N/SR/TB[{x}1];"
                                  f"[{x}b]atrim=0:68,asetpts=N/SR/TB[{x}2];[{x}c]atrim=70,asetpts=N/SR/TB[{x}3];"
                                  f"[{x}1][{x}2][{x}3]concat=n=3:v=0:a=1[{o}]")
        hecho = lambda filtro, salida: ffmpeg("-i", base, "-i", os.path.join(c, OTRO_DIALOGO), *entradas,
                                              "-filter_complex", filtro, "-map", "0:v:0", "-map", "[a]", "-c:v", "copy",
                                              "-c:a", "flac", "-shortest", salida)
        if not os.path.exists(t(raw)):
            hecho(f_ + voz(False) + mezclar("dlg", "fondo", "a"), t(raw))
        if not desplazado:          # (el doblaje sin desplazar nada: la misma mezcla con la voz en otro tono)
            hecho(f_ + voz(True) + mezclar("dlg", "fondo", "a"), t(nombre))
        elif voz_tambien:
            hecho(f_ + voz(True) + mezclar("dlg", "fondo", "m") + ";" + desplazar("m", "a"), t(nombre))
        else:
            hecho(f_ + voz(True) + desplazar("fondo", "fd") + ";" + mezclar("dlg", "fd", "a"), t(nombre))
        return t(nombre), t(raw)

    def hueco_imagen_desplazada():
        # (1.4.12; El último superviviente / Man vs. Wild 1x02, 8:57) un trozo sin coincidencias del audio se mide con la
        # imagen, pero su calibración solo admitía la imagen a menos de 80 ms del audio; allí iba 198 ms desplazada de su
        # sonido en todo el episodio, «la imagen no dice con claridad» y el salto se quedaba donde lo ponía el audio (5 s
        # antes, partiendo una frase). Aquí, 24 s de ruido en el sonido del doblaje (1:28-1:52), al doblaje le faltan 10 s
        # del original (1:40-1:50, cortados a mitad de plano) y su imagen va 0,2 s tarde en todo el vídeo: el trozo se
        # mide con los cambios de plano (con la calibración de antes, no), el salto va en el cambio de plano del montaje
        # (1:40,2 de su imagen, 1:40,0 de su sonido: la 1.4.11, tras corregirlo con el contenido de la imagen, cortaba en
        # 1:40,2) y en un solo corte (el audio ponía su salto en 1:28,4, antes de lo que pintaba la imagen, y quedaban 0,6 s
        # sueltos: dos cortes de más)
        ffmpeg("-i", base, "-f", "lavfi", "-i", f"anoisesrc=d=24:c=pink:r={sr}:a=0.3:s=11", "-filter_complex",
               "[0:v]trim=0:100,setpts=PTS-STARTPTS[v1];[0:v]trim=110,setpts=PTS-STARTPTS[v2];"
               "[v1][v2]concat=n=2:v=1:a=0[v];[0:a]atrim=0:88,asetpts=N/SR/TB[a1];"
               "[1:a]aformat=channel_layouts=stereo,asetpts=N/SR/TB[a2];[0:a]atrim=122,asetpts=N/SR/TB[a3];"
               "[a1][a2][a3]concat=n=3:v=0:a=1[a]", "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset",
               "ultrafast", "-crf", "23", "-c:a", "flac", t("hueco_a_la_par.mkv"))
        ffmpeg("-itsoffset", "0.2", "-i", t("hueco_a_la_par.mkv"), "-i", t("hueco_a_la_par.mkv"), "-map", "0:v:0",
               "-map", "1:a:0", "-c", "copy", t("hueco_desplazado.mkv"))
        return t("hueco_desplazado.mkv"), base

    def frase_en_relleno():
        # (1.4.12; El último superviviente 1x02, 9:10: el relleno con el original acababa con «I've abseiled into the...»
        # cortado contra el castellano; el usuario: «prefiero que no se corte la frase, en ambos idiomas, con preferencia
        # SIEMPRE en castellano») voz de verdad en los dos (Vaya Semanita en el centro, en frases de 3 s con 1,5 s de pausa;
        # en el doblaje, con otro tono) y el fondo en la lateral, como en fondo_desplazado; al doblaje, solo sonido, le
        # faltan 10 s en el 1:40, con frases que cruzan los dos empalmes (las de 1:39-1:42 y 1:48-1:51 del original). Con
        # el castellano hablando a los dos lados, lo del original que cruza cada borde del relleno va sin voz (su lateral)
        return falta_10s_en_1_40("frase_relleno")

    def falta_10s_en_1_40(nombre, callar=()):
        """El doblaje de frase_en_relleno (sin 1:40-1:50 del original), con la voz castellana callada en callar (s del
        original), y el original (frases_raw.mkv)."""
        _, raw = fondo_desplazado(nombre + "_base.mkv", False, False, callar, frases=True)
        ffmpeg("-i", t(nombre + "_base.mkv"), "-filter_complex",
               "[0:a]asplit=2[a][b];[a]atrim=0:100,asetpts=N/SR/TB[a1];[b]atrim=110,asetpts=N/SR/TB[b1];"
               "[a1][b1]concat=n=2:v=0:a=1,asetpts=N/SR/TB[o]", "-map", "[o]", "-c:a", "flac", t(nombre + ".mka"))
        return t(nombre + ".mka"), raw

    def frase_entera_relleno():
        # (1.4.12; El último superviviente 1x02, 9:29,8: el relleno acababa en «...to a river and», con el castellano
        # callado 7 s después; el usuario: «da tiempo de sobra para que diga la frase y lo empalmes con el castellano»)
        # lo de frase_en_relleno con la voz castellana callada a los dos lados del empalme (1:34,5-1:40 y 1:50-1:55,5 del
        # original): las dos frases del original que cruzan los bordes del relleno se oyen enteras (empieza antes y acaba
        # después, donde el castellano calla)
        return falta_10s_en_1_40("frase_entera_relleno", [(94.5, 100), (110, 115.5)])

    def forzados_de_la_vo():
        # (1.4.13) los forzados de lo que va en VO (--forzados-vo): al doblaje le faltan 10 s (1:40-1:50) en los que el
        # original dice una frase en inglés (la voz inglesa de Windows, con su sonido de fondo bajo); el relleno se
        # transcribe con Whisper y se traduce: un _forzados.srt con la frase en castellano en su sitio
        hablar_en_ingles(t("voz_en.wav"), "The river is far too deep to cross here. I will climb the hill and look "
                                          "for another way down.")
        ffmpeg("-i", base, "-i", t("voz_en.wav"), "-filter_complex",
               "[0:a]volume=0.15:enable='between(t,100,110)'[f];"
               f"[1:a]aresample={sr},aformat=channel_layouts=stereo,adelay=101500|101500,volume=2[v];"
               "[f][v]amix=inputs=2:normalize=0:duration=first[a]", "-map", "0:v:0", "-map", "[a]", "-c:v", "copy",
               "-c:a", "flac", "-shortest", t("vo_raw.mkv"))
        ffmpeg("-i", base, "-filter_complex", "[0:a]asplit=2[a][b];[a]atrim=0:100,asetpts=N/SR/TB[a1];"
               "[b]atrim=110,asetpts=N/SR/TB[b1];[a1][b1]concat=n=2:v=0:a=1[o]", "-map", "[o]", "-c:a", "flac",
               t("vo.mka"))
        return t("vo.mka"), t("vo_raw.mkv"), ["--forzados-vo", "small"]

    def forzados_traducidos(desde, hasta, palabras):
        """El _forzados.srt de forzados_de_la_vo: todos sus subtítulos entre desde y hasta (s) y, entre todos, las
        palabras (en minúscula)."""
        def f(r):
            ruta = t("forzados_vo_SYNC_forzados.srt")
            if not os.path.exists(ruta):
                return ["no sale el _forzados.srt"]
            texto_srt = open(ruta, encoding="utf-8-sig").read().replace("\r\n", "\n")
            subs = re.findall(r"(\d+):(\d+):(\d+),(\d+) --> (\d+):(\d+):(\d+),(\d+)\n(.*?)\n\n", texto_srt, re.S)
            seg = lambda h, m, s, ms: int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000
            fuera = [f"{seg(*x[:4]):.2f}-{seg(*x[4:8]):.2f}" for x in subs
                     if seg(*x[:4]) < desde or seg(*x[4:8]) > hasta]
            texto = " ".join(x[8] for x in subs).lower()
            faltan = [w for w in palabras if w not in texto]
            return ([f"subtítulos fuera de {desde}-{hasta} s: {fuera}"] if fuera else []) + \
                   ([f"no dice {faltan}: «{texto}»"] if faltan else []) + ([] if subs else ["el .srt está vacío"])
        return f

    def salida_estereo():
        # un castellano 5.1 en AC3 sin cortes: tal cual iría intacto, pero se ha pedido 2.0 a 224 kb/s (1.4.3)
        ffmpeg("-i", base, "-map", "0:a:0", "-ac", "6", "-c:a", "ac3", "-b:a", "448k", t("estereo.mka"))
        return t("estereo.mka"), base, ["--canales", "2.0", "--formato", "ac3", "--kbps", "224"]

    def salida_es(canales, codec, kbps):
        def f(r):
            ruta = t("salida_estereo_SYNC.mka")
            p = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries",
                                "stream=codec_name,channels,bit_rate", "-of", "csv=p=0", ruta], capture_output=True,
                               text=True).stdout.strip()
            return [] if p == f"{codec},{canales},{kbps * 1000}" else [f"la salida es «{p}», se esperaba "
                                                                       f"{codec}, {canales} canales, {kbps} kb/s"]
        return f

    def rearmar(partes, salida, recorte=""):
        """Un vídeo con imagen y sonido hecho de trozos [(archivo, desde, hasta o None)] seguidos (a 640x480 y 25 fps,
        el sonido en FLAC estéreo a la tasa de la RAW), con los tiempos de cada archivo desde 0 (el vídeo base empieza en
        0,2 s) y, en el sonido, un ruido blanco de marca: así se distingue el doblaje colocado del relleno con el
        original (sin ella, un relleno con el original suena igual que el doblaje fabricado con su audio). recorte: un
        filtro crop de ffmpeg (con su coma) antes de escalar, como una emisión de TV que corta los bordes."""
        entradas = list(dict.fromkeys(e for e, _, _ in partes))
        f = ""
        for k, (e, a, b) in enumerate(partes):
            n = entradas.index(e)
            tr = f"start={a}" + (f":end={b}" if b is not None else "")
            f += (f"[{n}:v]setpts=PTS-STARTPTS,trim={tr},setpts=PTS-STARTPTS,{recorte}scale=640:480,setsar=1,fps=25,"
                  f"format=yuv420p[v{k}];[{n}:a]aresample={sr},asetpts=PTS-STARTPTS,atrim={tr},asetpts=PTS-STARTPTS,"
                  f"aformat=channel_layouts=stereo,volume=0.5[a{k}];")
        f += "".join(f"[v{k}][a{k}]" for k in range(len(partes))) + f"concat=n={len(partes)}:v=1:a=1[v][c];" + \
            f"anoisesrc=c=white:a=0.15:r={sr}:s=5,aformat=channel_layouts=stereo[r];" + \
            "[c][r]amix=inputs=2:normalize=0:duration=first[a]"
        ffmpeg(*[x for e in entradas for x in ("-i", e)], "-filter_complex", f, "-map", "[v]", "-map", "[a]",
               "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-c:a", "flac", salida)

    CAMBIADOS = [(base, 0, 60), (base, 90, 120), (base, 60, 90), (base, 120, None)]
    CABECERA = [(corto, 0, 12), (base, 30, 45), (base, 0, 30), (base, 45, None)]
    # (1.4.12) un avance antes de la pausa que solo tiene el doblaje: trozos de lo que viene después, con su imagen y su
    # sonido (El último superviviente / Man vs. Wild 1x02, 18-11-2026)
    AVANCE = [(base, 0, 90), (base, 120, 135), (base, 160, 175), (base, 90, None)]
    AVANCE_ESCENA = [(base, 0, 60), (base, 150, 180), (base, 60, None)]
    # (1.4.13) en medio, algo que el original no tiene, entre dos trozos que van en orden (El último superviviente 1x01)
    OTRO_EN_MEDIO = [(base, 0, 60), (corto, 0, 20), (base, 90, None)]

    def avance_doblaje():
        # medido con el audio, cada trozo del avance iba encima de su escena y, al volver el desfase atrás, el montaje
        # tomaba por castellano que sobraba el principio de la escena (en el episodio, 94 s quitados y 70 s del original
        # con su audio). Lo del avance no se coloca y la escena sale entera, con el doblaje. (Con trozos de 15 s el audio
        # no los coloca: el avance va con el tramo de antes y lo resuelve el recorte que no cabía en su hueco)
        rearmar(AVANCE, t("avance.mkv"))
        return t("avance.mkv"), base

    def avance_escena():
        # lo mismo con 30 s de una sola escena: el audio no los coloca (no busca tan lejos) y deja el borde del tramo 3,4 s
        # tarde; el recorte va justo en 1:00-1:30, con los bordes por el sonido (los dos trozos en el mismo sitio del
        # original, con imagen y sonido fabricados, en la prueba suelta «repeticiones»)
        rearmar(AVANCE_ESCENA, t("avance_escena.mkv"))
        return t("avance_escena.mkv"), base

    def cortes_whisper():
        # (1.4.13; El último superviviente 1x01, 21:03: el recorte quitaba de en medio de una frase a en medio de otra,
        # en respiros que la voz tomaba por pausas) lo de avance_escena con --cortes-whisper: tiene que salir igual y
        # con cada unión escuchada
        if not os.path.exists(t("avance_escena.mkv")):
            rearmar(AVANCE_ESCENA, t("avance_escena.mkv"))
        return t("avance_escena.mkv"), base, ["--cortes-whisper"]

    def bloques_cambiados():
        # Top Dog (15-11-2026): el doblaje tiene escenas en otro orden que el original, y hasta la 1.4.8 el bloque que
        # vuelve atrás se tomaba por castellano que sobra (se quitaban 401 s) y su sitio iba en inglés. Aquí, con su
        # imagen y su sonido, los trozos 1:00-1:30 y 1:30-2:00 del original cambiados de sitio; se mide con la imagen.
        # Tiene que salir todo con el doblaje, cada trozo en su sitio: los tres cortes como bloques en otro orden, sin
        # quitar ni añadir nada
        rearmar(CAMBIADOS, t("cambiados.mkv"))
        return t("cambiados.mkv"), base, ["--medir", "video"]

    def recorte_tv():
        # (1.4.13; El último superviviente 1x01: la emisión de TV corta arriba y abajo, el 86 % del alto del original)
        # lo de bloques_cambiados con la imagen del doblaje recortada así: se tiene que ver el recorte y comparar con el
        # original recortado igual, y salir lo mismo
        rearmar(CAMBIADOS, t("recorte_tv.mkv"), "crop=iw:ih*0.86,")
        return t("recorte_tv.mkv"), base, ["--medir", "video"]

    def cabecera_reeditada():
        # la cabecera de Top Dog: el doblaje empieza con algo que el original no tiene (sus propios créditos; aquí, 12 s
        # de otro vídeo) y luego trae los planos del principio en otro orden (aquí, 0:30-0:45 del original antes que
        # 0:00-0:30). Lo que no está en el original no se coloca (iba con el primer trozo, encima de otra escena) y el
        # resto va cada cosa en su sitio
        rearmar(CABECERA, t("cabecera.mkv"))
        return t("cabecera.mkv"), base, ["--medir", "video"]

    def otro_en_medio():
        # (1.4.13; El último superviviente 1x01, 18:06-18:32 del doblaje: la emisión de TV mete 26 s de unos rastreadores
        # con un portátil, que la versión original no tiene, en lugar de 32 s del original, entre dos trozos que van en
        # orden; iban con el de antes, con su castellano encima de otra escena) aquí, 20 s de otro vídeo en lugar de
        # 1:00-1:30 del original, medido con la imagen: lo de en medio no se coloca y su sitio va con el original
        rearmar(OTRO_EN_MEDIO, t("otro_en_medio.mkv"))
        return t("otro_en_medio.mkv"), base, ["--medir", "video"]

    def suena_como(nombre, doblaje, partes, minimo=0.95):
        """El audio sincronizado (nombre_SYNC.mka) es el doblaje fabricado (doblaje, hecho con rearmar de partes)
        colocado donde va cada trozo en el original (base), y el original donde el doblaje no lo tiene: en ventanas de
        1 s con sonido, la onda (a 8 kHz, en mono) se parece 0,9 o más con ±10 ms de margen en al menos `minimo` de
        ellas (con la marca del doblaje, un relleno con el original no llega)."""
        def f(r):
            if r["error"]:
                return []                       # (ya lo dice sin_error)
            import numpy as np
            dec = lambda ruta: np.frombuffer(subprocess.run(
                ["ffmpeg", "-v", "error", "-i", ruta, "-map", "0:a:0", "-ac", "1", "-ar", "8000", "-f", "f32le", "-"],
                capture_output=True).stdout, np.float32)
            x, y, z = dec(t(nombre + "_SYNC.mka")), dec(base).copy(), dec(t(doblaje))
            # (el resultado lleva delante el retraso de la pista del original: va a la par de su imagen)
            m = re.search(r"Retraso de la pista original aplicado al principio: (-?\d+) ms", r["texto"])
            x = x[int(round(int(m[1]) * 8)):] if m and int(m[1]) > 0 else x
            # lo que tiene que salir: el original, con lo del doblaje encima donde va cada trozo de base
            D = 0
            for e, a, b in partes:
                n = int(round((b - a) * 8000)) if b is not None else len(z) - D
                if e == base:
                    i0 = int(round(a * 8000))
                    k = min(n, len(y) - i0, len(z) - D)
                    y[i0:i0 + k] = z[D:D + k]
                D += n
            W, M, malas, total = 8000, 80, [], 0
            for i in range(M, min(len(x), len(y)) - W - M, W):
                a, b = x[i:i + W], y[i - M:i + W + M]
                if np.sqrt(np.mean(b[M:M + W] ** 2)) < 1e-3:
                    continue
                total += 1
                c = np.correlate(b, a, "valid") / (np.linalg.norm(a) * np.sqrt(np.convolve(b ** 2, np.ones(W), "valid"))
                                                   + 1e-9)
                if c.max() < 0.9:
                    malas.append(i / 8000)
            if not total or (total - len(malas)) / total < minimo:
                return [f"el resultado no es el doblaje colocado en su sitio en {len(malas)} de {total} s "
                        f"(desde {', '.join(f'{s:.0f}' for s in malas[:8])}{' ...' if len(malas) > 8 else ''} s)"]
            return []
        return f

    return [
        ("limpio", "el mismo audio: ni cortes ni nada que revisar", limpio,
         [sin_error, inicio(0, 5), cortes(0), verificacion(5), nada_que_revisar]),
        ("desfase", "1,5 s tarde en todo el episodio", desfase,
         [sin_error, inicio(-1500, 10), cortes(0), nada_que_revisar]),
        ("sobra_2s", "2 s repetidos en el 1:00: un recorte ahí", sobra,
         [sin_error, inicio(0, 10), un_corte(-2000, 40, 57, 63), nada_que_revisar]),
        # (el corte, justo en el empalme: hasta la 1.4.5 iba en 1:31,33 y se admitía de 1:28 a 1:32; 1 s sonaba dos
        # veces, y lo vio la comprobación de los empalmes)
        # (1.4.12: si una frase castellana cruza el empalme, el corte va donde empieza o acaba; aquí, 1:29,84, y el segundo
        # del original, media frase, en silencio: empalme_en)
        ("falta_1s", "le falta 1 s en el 1:30: un relleno ahí, con el corte en el empalme", falta,
         [sin_error, inicio(0, 10), cortes(1), empalme_en(90.0, 1000, 40, 0.15), nada_que_revisar]),
        ("pal", "PAL, el tono subido", pal,
         [sin_error, contiene("4,3 %", "velocidad"), inicio(0, 15), cortes(0), nada_que_revisar]),
        ("pal_tono", "PAL con el tono corregido (se mide con la envolvente)", pal_tono,
         [sin_error, contiene("4,3 %", "velocidad"), contiene("tono corregido", "velocidad"), inicio(0, 25), cortes(0)]),
        ("otra_mezcla_24", "24 frente a 23,976 con otra mezcla (la onda no se parece): la velocidad, con la envolvente",
         otra_mezcla_24, [sin_error, contiene("0,1 %", "velocidad"), contiene("otra mezcla", "velocidad"), cortes(0),
                          nada_que_revisar]),
        ("corto_pal", "un vídeo de 1 min a velocidad PAL", corto_pal,
         [sin_error, contiene("4,3 %", "velocidad"), cortes(0)]),
        ("imagen_desplazada", "la imagen del doblaje 0,5 s desplazada de su sonido: se sigue al sonido", imagen_desplazada,
         [sin_error, contiene("imagen va +500 ms"), inicio(0, 5), cortes(0), nada_que_revisar]),
        ("escena_movida_audio", "medido con el audio, una escena puesta 1:50 antes vuelve a su sitio (sin quitarla ni "
                                "rellenar con el original)", escena_movida_audio,
         [sin_error, contiene("Escena en otro orden: 0:40"), contiene("va en 2:30"), cortes(0), verificacion(10)]),
        ("con_imagen", "sin audio que encaje: con la imagen, 3 s repetidos en el 1:03", con_imagen,
         [sin_error, contiene("Señal de análisis: vídeo"), un_corte(-3000, 80, 58, 68)]),
        ("color_raro", "un vídeo con los datos de color mal puestos se lee", color_raro,
         [sin_error, no_contiene("no se ha podido leer el vídeo"), contiene("Señal de análisis: vídeo")]),
        ("destellos", "15 s de destellos al principio: no cuentan, sin cortes ahí", destellos,
         [sin_error, contiene("Destellos"), inicio(1500, 60), cortes(0)]),
        ("lateral_rota", "la lateral de los dos audios estropeada y el mismo sonido: se mide con la mezcla, no con la "
                         "imagen", lateral_rota,
         [sin_error, contiene("Señal de análisis: mezcla L+R"), no_contiene("Señal de análisis: vídeo"), inicio(0, 25),
          cortes(0)]),
        ("guia_sin_imagen", "con una guía que encaja en todo el episodio no se leen los vídeos", guia_sin_imagen,
         [sin_error, contiene("guía: pista 2"), contiene("Comprobación con la imagen: no hace falta"),
          no_contiene("Leyendo los cambios de plano"), inicio(0, 5), cortes(0), no_contiene("NO va a la par")]),
        ("guia_sin_idioma", "la guía sin idioma (y con el tono corregido) se reconoce por cómo suena", guia_sin_idioma,
         [sin_error, contiene("guía: pista 2"), no_contiene("Señal de análisis: vídeo"), inicio(0, 25), cortes(0),
          no_contiene("NO va a la par")]),
        ("etiquetas_cambiadas", "la versión original etiquetada como castellano: se ve por el audio", etiquetas_cambiadas,
         [sin_error, contiene("Las etiquetas de idioma no cuadran"), contiene("Se sincroniza la pista 2"),
          contiene("guía: pista 1"), inicio(0, 25), no_contiene("NO va a la par")]),
        ("desfasada_de_la_guia", "el castellano 150 ms tarde de su guía en un trozo: se contrasta con el original y se "
                                 "corrige, con los cortes en sus silencios", desfasada_de_la_guia,
         [sin_error, contiene("NO va a la par de la guía"), cortes_en([(60.0, -150), (150.0, 150)], 10, 1.0),
          verif_castellano(5), nada_que_revisar]),
        ("trozo_corto_descolocado", "8 s descolocados 1,5 s: la verificación lo ve y avisa con la corrección a mano",
         trozo_corto_descolocado,
         [sin_error, contiene("puede estar descolocado"), correccion_sugerida(100, 108, 1500, 40),
          contiene("ventanas encajan en su sitio")]),
        ("sonido_desfasado_por_trozos", "medido con la imagen, el sonido 120 ms tarde de ella en un trozo: el contraste "
                                        "lo corrige", sonido_desfasado_por_trozos,
         [sin_error, contiene("Señal de análisis: vídeo"), contiene("NO va a la par de su imagen"),
          cortes_en([(60.0, -120), (150.0, 120)], 15, 1.0), verif_castellano(5)]),
        ("desfasada_tono", "lo mismo con el tono corregido (PAL): se contrasta con la envolvente de los graves",
         desfasada_tono,
         [sin_error, contiene("NO va a la par de la guía"),
          cortes_en([(57.5, -144), (143.9, 144)], 10, 1.0), verif_castellano(5)]),
        ("empalme_en_mono", "un hueco de 10 s junto a una escena en mono (la lateral calla): el empalme del relleno se "
                            "busca también con la mezcla y va en su sitio", empalme_en_mono,
         [sin_error, contiene("Señal de análisis: lateral"), cortes(1), empalme_en(90.0, 10000, 40, 0.15),
          verificacion(5), nada_que_revisar]),
        ("estereo_otro_dialogo", "estéreo con la misma música y efectos y otro diálogo (un doblaje de verdad): se mide "
                                 "con la lateral, 2 s de más en el 1:00 y 8 s de menos en el 2:32, en su sitio",
         estereo_otro_dialogo,
         [sin_error, contiene("Señal de análisis: lateral"), inicio(0, 10), cortes(2), corte_cerca(60.0, -2000, 40, 3.0),
          corte_cerca(152.0, 8000, 40, 0.15), verificacion(5), nada_que_revisar]),
        ("musica_desplazada", "medido con el audio, la música y los efectos del doblaje 2 s desplazados de su voz y de su "
                              "imagen en un trozo: va con la voz, sin recortar el principio ni cortar",
         lambda: fondo_desplazado("musica_desplazada.mkv", False),
         [sin_error, contiene("Señal de análisis: lateral"), contiene("va con la imagen y la voz"), inicio(0, 50),
          cortes(0)]),
        ("sonido_desplazado", "lo contrario: el sonido entero del doblaje (la voz también) 2 s desplazado de su imagen en "
                              "un trozo: manda el audio", lambda: fondo_desplazado("sonido_desplazado.mkv", True),
         [sin_error, contiene("Señal de análisis: lateral"), no_contiene("va con la imagen y la voz"),
          contiene("se deja el del audio"), inicio(-2000, 40), corte_cerca(70.0, 2000, 40, 3.0)]),
        ("frase_en_relleno", "voz de verdad en los dos y 10 s de menos en el 1:40: el relleno, sin media frase del "
                             "original en sus bordes, y el corte sin partir la castellana", frase_en_relleno,
         [sin_error, contiene("Señal de análisis: lateral"), contiene("del original sin voz"),
          un_corte(10000, 40, 98.4, 101.6)]),
        ("frase_entera_relleno", "lo mismo con el castellano callado antes del empalme: la frase del original se oye "
                                 "entera, empezando el relleno antes", frase_entera_relleno,
         [sin_error, contiene("Señal de análisis: lateral"), contiene("se oye entera"), no_contiene("sin voz"),
          un_corte(10000, 40, 98.4, 101.6)]),
        ("forzados_vo", "10 s del original con una frase en inglés que no tiene el doblaje: con --forzados-vo, la "
                        "frase traducida en _forzados.srt, en su sitio", forzados_de_la_vo,
         [sin_error, un_corte(10000, 40, 99.6, 100.4), contiene("Forzados de la VO: "),
          contiene("subtítulos (Whisper small"), forzados_traducidos(100.0, 111.0, ["río", "colina"])]),
        ("hueco_imagen_desplazada", "24 s sin coincidencias del audio con 10 s de menos y la imagen 0,2 s desplazada de "
                                    "su sonido: la imagen pone el salto en su cambio de plano", hueco_imagen_desplazada,
         [sin_error, no_contiene("Señal de análisis: vídeo"), contiene("medido con los cambios de plano, el salto de "
                                                                       "+10000 ms"),
          contiene("ms desplazada de su sonido)"), contiene("plano a plano con la imagen, en"),
          un_corte(10000, 40, 99.85, 100.15)]),
        ("ruido", "un audio sin relación: error, sin inventarse nada", ruido,
         [error_con("apenas hay coincidencias")]),
        ("salida_estereo", "un 5.1 sin cortes, pedido en 2.0 a 224 kb/s: se recodifica así, no va intacto",
         salida_estereo,
         [sin_error, cortes(0), contiene("5.1 → 2.0"), contiene("pasado a 2.0 como se ha pedido; no había cortes"),
          no_contiene("intacto, sin recodificar"), salida_es(2, "ac3", 224)]),
        ("bloques_cambiados", "dos trozos del original cambiados de orden (con la imagen): sale el original tal cual, "
                              "sin quitar ni añadir nada", bloques_cambiados,
         [sin_error, contiene("Señal de análisis: vídeo"), contiene("bloque en otro orden"), cortes(0),
          no_contiene("Imagen: el doblaje es un recorte"), suena_como("bloques_cambiados", "cambiados.mkv", CAMBIADOS)]),
        ("recorte_tv", "lo mismo con la imagen del doblaje recortada arriba y abajo (una emisión de TV): se ve el "
                       "recorte y sale igual", recorte_tv,
         [sin_error, contiene("Señal de análisis: vídeo"), contiene("Imagen: el doblaje es un recorte"),
          contiene("bloque en otro orden"), cortes(0), suena_como("recorte_tv", "recorte_tv.mkv", CAMBIADOS)]),
        ("cabecera_reeditada", "12 s que el original no tiene y luego sus planos del principio en otro orden: lo que no "
                               "está no se coloca y el resto va en su sitio", cabecera_reeditada,
         [sin_error, contiene("Señal de análisis: vídeo"), suena_como("cabecera_reeditada", "cabecera.mkv", CABECERA)]),
        ("otro_en_medio", "20 s que el original no tiene en lugar de 30 s suyos, entre dos trozos en orden: no se "
                          "colocan y su sitio va con el original", otro_en_medio,
         [sin_error, contiene("Señal de análisis: vídeo"), contiene("Entre dos tramos en orden"),
          suena_como("otro_en_medio", "otro_en_medio.mkv", OTRO_EN_MEDIO)]),
        ("avance_doblaje", "medido con el audio, 30 s de avance (trozos de lo que viene después) que el original no "
                           "tiene: no se colocan y la escena sale entera, con el doblaje", avance_doblaje,
         [sin_error, no_contiene("Señal de análisis: vídeo"), contiene("no está en el original"),
          un_corte(-30000, 80, 104.5, 105.5), suena_como("avance_doblaje", "avance.mkv", AVANCE)]),
        ("avance_escena", "medido con el audio, 30 s de una escena de después que el original no tiene ahí, con el borde "
                          "del audio 3,4 s tarde: el recorte va justo ahí y la escena sale entera", avance_escena,
         [sin_error, contiene("no está en el original"), un_corte(-30000, 80, 74.5, 75.5),
          suena_como("avance_escena", "avance_escena.mkv", AVANCE_ESCENA)]),
        ("cortes_whisper", "lo mismo con --cortes-whisper: el recorte, donde acaban las frases según Whisper, y cada "
                           "unión del resultado escuchada con él", cortes_whisper,
         [sin_error, contiene("no está en el original"), contiene("Uniones revisadas con Whisper"),
          suena_como("cortes_whisper", "avance_escena.mkv", AVANCE_ESCENA)]),
    ]


def pruebas_sueltas(carpeta=CARPETA):
    """Comprobaciones de funciones sueltas del motor, sin fabricar nada: [(nombre, fallos)]."""
    sys.path.insert(0, AQUI)
    import numpy as np
    import sincronizar_doblaje as sd
    out = []
    muestra = ("frame:0    pts:0       pts_time:0\ntimecode=00:00:00:00\nlavfi.scd.mafd=0.000\nlavfi.scd.score=0.000\n"
               "frame:1    pts:42      pts_time:0.042\nlavfi.scd.mafd=0.632\nlavfi.scd.score=0.632\n")
    n = len(sd.RE_FOTOGRAMA.findall(muestra))
    out.append(("patron_fotogramas", "las líneas de ffmpeg con código de tiempo se leen",
                [] if n == 2 else [f"lee {n} fotogramas de 2"]))
    c = sd.ncc_curve(np.ones(100, np.float32), np.ones(50, np.float32))
    out.append(("ncc_corto", "buscar un trozo más largo que la señal no revienta",
                [] if c is None else ["no devuelve None"]))
    av = ["corte 1:00.00: sin silencio claro, conviene escucharlo",
          "1:00-2:00: 12 cambios de plano seguidos del doblaje no encajan con el original; puede estar descolocado"]
    clase = [sd.para_revisar(a) for a in av]
    out.append(("clases_de_aviso", "los avisos se separan en «revisar» y «escuchar»",
                [] if clase == [False, True] else [f"clasificados {clase}"]))
    # el nombre del audio sincronizado: el nuevo, y los de antes se siguen reconociendo (no se repite lo ya hecho)
    fallos = []
    with tempfile.TemporaryDirectory(prefix="nombres_") as d:
        dob = os.path.join(d, "Serie 1x01.avi")
        nuevo = sd.ruta_salida(dob, "es-ES")
        if os.path.basename(nuevo) != "Serie 1x01_[es-ES]_SYNC.mka":
            fallos.append(f"nombre nuevo: {os.path.basename(nuevo)}")
        for viejo, idioma in (("Serie 1x01_[spa]_SYNC_ENG.mka", "es-ES"), ("Serie 1x01_[spa]_SYNC_ENG.flac", "es-ES"),
                              ("Serie 1x01_[spa]_SYNC_ENG.mka", "es-419")):
            open(os.path.join(d, viejo), "w").close()
            r = os.path.basename(sd.ruta_salida(dob, idioma))
            if r != viejo:
                fallos.append(f"con {viejo} ya hecho ({idioma}) da {r}")
            os.remove(os.path.join(d, viejo))
        otra = os.path.join(d, "salida")
        os.makedirs(otra)
        open(os.path.join(otra, "Serie 1x01_[spa]_SYNC_ENG.mka"), "w").close()
        if os.path.dirname(sd.ruta_salida(dob, "es-ES", otra)) != otra or \
                not sd.ruta_salida(dob, "es-ES", otra).endswith("_SYNC_ENG.mka"):
            fallos.append("con carpeta de salida no encuentra el de antes")
    out.append(("nombre_salida", "«…_[es-ES]_SYNC.mka», y los «…_[spa]_SYNC_ENG» de antes se reconocen", fallos))
    # la pista de la RAW con la que se mide (y se rellena): por idioma y, si no decide, por el título (el DVDRemux de
    # Becker: ucraniano «MVO» primero, inglés «Original» después, doblaje .avi sin idioma)
    pista = lambda n, idioma="", titulo="": {"_n": n, "index": n, "codec_name": "ac3", "channels": 2,
                                            "tags": {k: v for k, v in (("language", idioma), ("title", titulo)) if v}}
    casos_pista = [  # (pistas de la RAW, pistas del doblaje, la que tiene que salir)
        ([pista(1, "ukr", "MVO | Comedy Central"), pista(2, "eng", "Original")], [pista(1)], 2),
        ([pista(1, "rus", "Закадровый"), pista(2, "eng")], [pista(1)], 2),
        ([pista(1, "eng", "Commentary"), pista(2, "eng", "English")], [pista(1)], 2),
        ([pista(1, "dan"), pista(2, "eng")], [pista(1, "spa"), pista(2, "eng")], 2),      # por idioma
        ([pista(1, "spa", "Castellano"), pista(2, "eng", "V.O.")], [pista(1)], 2),
        ([pista(1, "ukr"), pista(2, "eng")], [pista(1)], 1),                               # nada lo dice: la primera
        ([pista(1, "eng", "Original")], [pista(1)], 1),
    ]
    fallos, antes = [], sd.pistas_audio
    try:
        for ori, dob, bien in casos_pista:
            sd.pistas_audio = lambda ruta, ori=ori, dob=dob: ori if ruta == "raw" else dob
            sale = sd.elegir_original("raw", "doblaje", "spa", p=lambda *a: None)["_n"]
            if sale != bien:
                fallos.append(f"con {[sd.describir_pista(s) for s in ori]} elige la {sale}, no la {bien}")
    finally:
        sd.pistas_audio = antes
    out.append(("pista_original", "de la RAW se mide con la versión original, no con voces superpuestas", fallos))
    # etiquetas de idioma que no lo son (La pelu del señor Pan 3x14: «???» en ffprobe, «und» en mkvmerge): sin idioma, y
    # que no acaben en el nombre de un archivo («?» no vale en Windows: salía «Broken pipe»)
    fallos = [f"«{e}» -> «{sd.idioma_valido(e)}»" for e, bien in (("???", ""), ("und", ""), ("", ""), ("spa", "spa"),
                                                                  ("es-ES", "es-ES"), ("eng", "eng"))
              if sd.idioma_valido(e) != bien]
    ruta = sd.ruta_pista_extra("x_SYNC.mka", {"_n": 2, "tags": {"language": "???"}})
    if any(ch in os.path.basename(ruta) for ch in '?*<>|:"'):
        fallos.append(f"nombre de la pista extra: {ruta}")
    out.append(("idioma_sin_valor", "«???» y «und» son «sin idioma» y no van al nombre de archivo", fallos))
    # cuándo la envolvente mide bien sin la imagen: el mismo sonido con otra codificación (parecido 0,85-0,94, desfase
    # estable) sí; otra mezcla (el desfase salta 0,18 s de ida y vuelta) no
    t = np.arange(600.0)
    estable = np.column_stack([t, 0.465 + np.random.default_rng(2).normal(0, 0.001, 600), np.full(600, 0.88)])
    salta = estable.copy()
    salta[::7, 1] += 0.18
    fallos = ([] if sd.envolvente_precisa(estable) else ["el mismo sonido con parecido 0,88 no se da por preciso"]) + \
             (["otra mezcla, con saltos de 0,18 s, se da por precisa"] if sd.envolvente_precisa(salta) else [])
    out.append(("envolvente_precisa", "la envolvente vale sin imagen si el desfase es estable, no si salta", fallos))
    # subtítulo de otra versión con diálogo seguido (huecos de 0,5 s) y dos desfases candidatos a 30 s que cubren voz
    # por bloques alternos (Black Mask, 01-11-2026: se alternaban y las líneas salían desordenadas y solapadas)
    iv = np.array([(10 + 2.5 * i, 12 + 2.5 * i) for i in range(48)])
    v = np.zeros(400 * sd.FR_VOZ, np.float32)
    for i, (x0, x1) in enumerate(iv):
        L = 0.0 if (i // 6) % 2 == 0 else -30.0        # el desfase con el que cada bloque de 6 cubre voz
        v[int((x0 + L + 40) * sd.FR_VOZ):int((x1 + L + 40) * sd.FR_VOZ)] = 1
    ref = dict(v=v, t0=-40.0, escala=1.0)
    a, L = sd._tramos_con_deriva(iv, ref, 1.0, 0.0, np.array([50.0, 60, 100, 110]), np.array([0.0, 0, -30, -30]))
    ini, fin = a * iv[:, 0] + L, a * iv[:, 1] + L
    mal = int((ini[1:] < fin[:-1] - sd.SUB_TOL_ORDEN - 1e-9).sum())
    out.append(("subtitulo_en_orden", "un subtítulo de otra versión no sale nunca antes que el anterior",
                [f"{mal} subtítulos salen antes que el anterior"] if mal else []))
    # velocidad con la envolvente (La pelu del señor Pan 3x21): a la misma velocidad una ventana suelta de 0,80 (música
    # lenta, que la envolvente casa aunque vaya un 4 % más rápida) no puede vetar la PAL, confirmada con 0,94-0,98
    misma, pal = (-1.0, 1, 0.80, 5, 0.80), (0.97, 2, 0.95, 5, 0.98)
    fallos = [] if sd.encaja_velocidad(pal, sd.base_envolvente(misma), True) else ["la PAL no encaja"]
    if sd.encaja_velocidad(misma, sd.ENV_RUIDO, True):
        fallos.append("una ventana suelta a la misma velocidad se da por buena")
    out.append(("velocidad_suelta", "una ventana suelta a la misma velocidad no veta la PAL confirmada", fallos))
    # el seguimiento empieza con el desfase del principio, no con el mejor (La pelu del señor Pan 3x18: +1,01 s al
    # principio y +28,4 s, más claro, al final; empezando en +28,4 el primer minuto salía con desfases casuales)
    rng = np.random.default_rng(1)
    AR, n = sd.AR, 700 * sd.AR
    x = rng.standard_normal(n + 60 * AR).astype(np.float32)
    a = x[30 * AR:30 * AR + n]
    b = np.concatenate([x[29 * AR:29 * AR + 300 * AR] + rng.standard_normal(300 * AR).astype(np.float32),
                        x[5 * AR + 300 * AR:5 * AR + n]])                      # +1 s (con ruido) y luego +25 s
    p, m = sd.desfase_inicial(a, b, primero=True)[0], sd.desfase_inicial(a, b)[0]
    out.append(("desfase_del_principio", "con dos desfases en el episodio, el seguimiento empieza por el del principio",
                [] if abs(p - 1) < 0.01 and abs(m - 25) < 0.01 else [f"primero {p:+.3f} s, mejor {m:+.3f} s"]))
    # la limpieza del ruido de la cinta, por trozos (1.4.2: una película de 86 min no se limpiaba, «demasiado largo»):
    # los trozos casan con la limpieza de una vez, en disco sale lo mismo que en la RAM, el ruido de las pausas baja
    # y un 5.1 no se toca (con su aviso). Un tono con vibrato y pausas, siseo, zumbido de 50 Hz, continua y chasquidos.
    # El tono entra y sale en 30 ms, como un sonido de verdad: cortado en seco a -13 dB, el siseo (tramas de 46 ms) deja
    # algo de ese corte en la pausa de al lado y el ruido de las pausas enteras solo bajaba 7 dB (igual en la 1.4.1)
    import limpiar_vhs as lv
    from scipy.ndimage import uniform_filter1d
    fs, fallos, calla = 44100, [], lambda *a: None
    rng = np.random.default_rng(3)
    t = np.arange(100 * fs) / fs
    suena = np.sin(2 * np.pi * 0.25 * t) > -0.3                     # 1,6 s de pausa cada 4 s
    tono = 0.3 * np.sin(2 * np.pi * 180 * t + 2 * np.sin(2 * np.pi * 3 * t)) * uniform_filter1d(suena * 1.0,
                                                                                                int(0.03 * fs))
    x = (tono[:, None] + rng.standard_normal((len(t), 2)) * 0.004
         + 0.003 * np.sin(2 * np.pi * 50 * t)[:, None] - 0.03).astype(np.float32)
    x[rng.choice(np.arange(fs, len(t) - fs), 100, replace=False)] += 0.4
    entero = np.array(lv.limpiar(x, fs, p=calla, bloque_s=1000)[0])
    trozos = np.array(lv.limpiar(x, fs, p=calla, bloque_s=30)[0])
    with tempfile.TemporaryDirectory(prefix="limpieza_", ignore_cleanup_errors=True) as d:
        ruta = os.path.join(d, "x.f32")
        x.tofile(ruta)
        xm = np.memmap(ruta, np.float32, "r", shape=x.shape)
        lienzo = lambda forma: np.memmap(tempfile.mktemp(suffix=".f32", dir=d), np.float32, "w+", shape=forma)
        y = lv.limpiar(xm, fs, p=calla, lienzo=lienzo, bloque_s=30)[0]
        en_disco = np.array(y)
        del xm, y
    if np.abs(trozos - entero).max() > 1e-4:
        fallos.append(f"por trozos difiere de una vez hasta {np.abs(trozos - entero).max():.1e}")
    if np.abs(en_disco - trozos).max() > 1e-6:
        fallos.append(f"en disco difiere de en la RAM hasta {np.abs(en_disco - trozos).max():.1e}")
    pausa = (uniform_filter1d(suena * 1.0, int(0.4 * fs)) == 0) & (t > 1)      # sin los 0,2 s junto al tono
    baja = 10 * np.log10(np.var(x[pausa]) / np.var(entero[pausa]))
    if baja < 10:
        fallos.append(f"el ruido de las pausas solo baja {baja:.1f} dB")
    y, av = lv.limpiar(np.zeros((10 * fs, 6), np.float32), fs, p=calla)
    if y.shape[1] != 6 or not any("más de 2 canales" in a for a in av):
        fallos.append(f"un 5.1 no da su aviso: {av}")
    out.append(("limpieza_por_trozos", "la limpieza del ruido de la cinta por trozos casa con la de una vez", fallos))
    # canales y kb/s del audio de salida (1.4.3, lo pidió un compañero del usuario): un mono pasa a 2.0 igual en los dos
    # lados; un 5.1, con cada canal donde toca (los delanteros enteros, el central y los de los lados a -3 dB, sin el
    # subgrave) y sin saturar; «igual» no toca los canales; los kb/s pedidos van a los admitidos; y sin cortes se
    # recodifica solo si lo pedido no es lo que ya tiene
    import json
    fallos, fs = [], 48000
    t = np.arange(3 * fs) / fs

    def leer_salida(ruta):
        r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_name,channels,bit_rate", "-of",
                            "json", ruta], capture_output=True, text=True)
        st = json.loads(r.stdout)["streams"][0]
        raw = subprocess.run(["ffmpeg", "-v", "error", "-i", ruta, "-f", "f32le", "-"], capture_output=True).stdout
        return st, np.frombuffer(raw, np.float32).reshape(-1, int(st["channels"]))

    def amplitud(x, f):
        return 2 * abs(np.fft.rfft(x[fs // 2:fs // 2 + 2 * fs])[int(f * 2)]) / (2 * fs)   # bin de 0,5 Hz, 2 s
    with tempfile.TemporaryDirectory(prefix="canales_") as d:
        mono = (0.5 * np.sin(2 * np.pi * 440 * t))[:, None].astype(np.float32)
        r = sd.codificar(mono, fs, "mono", "flac", None, os.path.join(d, "mono.mka"), "2.0")
        st, y = leer_salida(os.path.join(d, "mono.mka"))
        if st["channels"] != 2 or r != "1.0 → 2.0":
            fallos.append(f"mono: {st['channels']} canales, «{r}»")
        elif np.abs(y[:, 0] - y[:, 1]).max() > 2e-4 or abs(amplitud(y[:, 0], 440) - 0.5) > 0.01:
            fallos.append(f"mono: los dos lados no llevan el mono entero ({amplitud(y[:, 0], 440):.3f} de 0,5)")
        frecs = (300, 500, 700, 50, 900, 1100)          # FL FR FC LFE SL SR
        x51 = np.stack([0.3 * np.sin(2 * np.pi * f * t) for f in frecs], 1).astype(np.float32)
        r = sd.codificar(x51, fs, "5.1(side)", "flac", None, os.path.join(d, "x51.mka"), "2.0")
        st, y = leer_salida(os.path.join(d, "x51.mka"))
        espera = {0: {300: 0.3, 700: 0.212, 900: 0.212, 500: 0, 1100: 0, 50: 0},
                  1: {500: 0.3, 700: 0.212, 1100: 0.212, 300: 0, 900: 0, 50: 0}}
        if st["channels"] != 2 or r != "5.1 → 2.0":
            fallos.append(f"5.1: {st['channels']} canales, «{r}»")
        else:
            for lado, tabla in espera.items():
                for f, a in tabla.items():
                    if abs(amplitud(y[:, lado], f) - a) > 0.01:
                        fallos.append(f"5.1: {'izquierdo' if lado == 0 else 'derecho'} con {amplitud(y[:, lado], f):.3f} "
                                      f"de {f} Hz, se esperaba {a}")
        fuerte = np.stack([0.9 * np.sin(2 * np.pi * 440 * t)] * 6, 1).astype(np.float32)
        r = sd.codificar(fuerte, fs, "5.1", "flac", None, os.path.join(d, "fuerte.mka"), "2.0")
        st, y = leer_salida(os.path.join(d, "fuerte.mka"))
        if "bajado" not in r or np.abs(y).max() > 1.0:
            fallos.append(f"5.1 fuerte: pico {np.abs(y).max():.3f}, «{r}»")
        r = sd.codificar(x51, fs, "5.1(side)", "ac3", 448000, os.path.join(d, "igual.mka"), "igual")
        st, _ = leer_salida(os.path.join(d, "igual.mka"))
        if st["channels"] != 6 or r:
            fallos.append(f"«igual» deja {st['channels']} canales, «{r}»")
    for f_, k, ch, tasa_, quiere in (("ac3", 200, 2, 48000, 192000), ("ac3", 900, 6, 48000, 640000),
                                     ("opus", 510, 1, 48000, 256000), ("aac", 512, 1, 44100, 256000),
                                     ("flac", 192, 2, 48000, None)):
        if sd.kbps_elegido(f_, k, ch, tasa_) != quiere:
            fallos.append(f"{k} kb/s en {f_} con {ch} canales da {sd.kbps_elegido(f_, k, ch, tasa_)}, no {quiere}")
    st = {"codec_name": "ac3", "channels": 6, "bit_rate": "448000", "sample_rate": "48000"}
    for canales, kbps, formato, quiere in (("2.0", None, "ac3", "pasado a 2.0"), ("igual", None, "ac3", None),
                                           ("igual", 448, "ac3", None), ("igual", 192, "ac3", "AC3 192 kb/s"),
                                           ("igual", 192, "flac", None)):
        m = sd.motivo_recodificar(canales, kbps, formato, st, "")
        if (m is None) != (quiere is None) or (quiere and quiere not in m):
            fallos.append(f"sin cortes, {canales} y {kbps} kb/s en {formato}: «{m}»")
    out.append(("canales_y_kbps", "1.0 y 5.1 pasan bien a 2.0, sin saturar; los kb/s pedidos van a los admitidos",
                fallos))
    # con guía, la pista doblada se contrasta con el original (1.4.4, Diagnóstico asesinato S06): un trozo 120 ms tarde
    # se corrige con dos cortes en sus silencios; a la par no se toca; sin relación no se inventa nada; un pico ancho (una
    # envolvente) no es ambiguo y varios iguales (música con ritmo) sí
    fallos = []
    AR = sd.AR
    rng = np.random.default_rng(1)
    n = 300 * AR
    from scipy.signal import butter as _butter, sosfilt as _sosfilt
    me = _sosfilt(_butter(4, 200, "low", fs=AR, output="sos"), rng.standard_normal(n)) * 3
    me *= np.repeat(rng.uniform(0.2, 1.0, n // AR + 1), AR)[:n]
    golpes = np.zeros(n)
    golpes[rng.integers(0, n, 400)] = 1
    me += np.convolve(golpes, np.exp(-np.arange(400) / 60) * rng.standard_normal(400), "same")
    voz = lambda s: _sosfilt(_butter(4, [300, 3400], "band", fs=AR, output="sos"),
                             np.random.default_rng(s).standard_normal(n)) * 0.8
    y = (me + voz(2)).astype(np.float32)
    x = (me + voz(3)).astype(np.float32)
    d = int(0.120 * AR)
    x[100 * AR:200 * AR] = x[100 * AR - d:200 * AR - d].copy()
    for t_ in (100, 200):
        x[int((t_ - 0.4) * AR):int((t_ + 0.4) * AR)] = 0
    db_x = sd.niveles_db(x.reshape(-1, 1), AR)
    L, cs, inf = sd.contrastar_doblada(x, y, [0.0], [], 300.0, lambda: db_x)
    if inf["estado"] != "corregido" or len(L) != 3 or abs(L[1] + 0.120) > 0.003 or abs(L[0]) > 0.003 \
            or abs(L[2]) > 0.003:
        fallos.append(f"trozo 120 ms tarde: {inf['estado']}, L {[round(v * 1000) for v in L]} ms")
    elif any(abs(c["c"] - t_) > 0.5 for c, t_ in zip(cs, (100, 200))):
        fallos.append(f"los cortes van en {[round(c['c'], 2) for c in cs]} s, no en los silencios de 100 y 200")
    else:
        v = sd.verificar_contraste(x, y, L, cs, 300.0)
        if not v["n"] or v["p90"] > 3:
            fallos.append(f"verificación con el castellano: {v.get('p90')} ms ({v['n']} ventanas)")
    if sd.contrastar_doblada(y.copy(), y, [0.0], [], 300.0, lambda: db_x)[2]["estado"] != "igual":
        fallos.append("a la par: no sale «igual»")
    otro = (np.random.default_rng(9).standard_normal(n) * 0.3).astype(np.float32)
    if sd.contrastar_doblada(otro, y, [0.0], [], 300.0, lambda: db_x)[2]["estado"] != "sin_medida":
        fallos.append("un audio sin relación no sale «sin_medida»")
    k = np.arange(-600, 601)
    if sd.ambigua(np.exp(-(k / 15.0) ** 2)):
        fallos.append("un pico ancho se da por ambiguo")
    if not sd.ambigua(0.5 + 0.5 * np.cos(2 * np.pi * k / 30) * np.exp(-(k / 300.0) ** 2)):
        fallos.append("picos iguales cada 30 ms no se dan por ambiguos")
    # 1.4.5: un tramo corto (10 s, sin ventana entera) que va 100 ms tarde se mide con una a su medida; estricto (medido
    # con la imagen), un tramo sin medida se queda donde está; y la corrección que proponen los avisos se puede leer
    xc = x.copy()
    xc[100 * AR:200 * AR] = y[100 * AR:200 * AR]                # (ya sin el trozo tarde de antes)
    for t_ in (100, 200):
        xc[int((t_ - 0.4) * AR):int((t_ + 0.4) * AR)] = 0
    d2 = int(0.100 * AR)
    xc[150 * AR:160 * AR] = y[150 * AR - d2:160 * AR - d2]       # 1:50-1:60 del doblaje, 100 ms tarde
    cortes_c = [dict(c=150.0, q0=149.9, q1=150.1, suelo=-90.0), dict(c=160.0, q0=159.9, q1=160.1, suelo=-90.0)]
    db_c = sd.niveles_db(xc.reshape(-1, 1), AR)
    Lc, _, infc = sd.contrastar_doblada(xc, y, [0.0, 0.0, 0.0], cortes_c, 300.0, lambda: db_c)
    if infc["estado"] != "corregido" or abs(Lc[1] + 0.100) > 0.005:
        fallos.append(f"tramo corto 100 ms tarde: {infc['estado']}, L {[round(v * 1000) for v in Lc]} ms")
    # estricto: el primer tramo va 120 ms tarde y el segundo no tiene nada que compartir (casi solo «voz»): sin estricto
    # va como el de al lado; estricto (medido con la imagen), se queda donde lo pone la imagen
    x0 = (me + voz(3)).astype(np.float32)                       # (el doblaje sin ningún trozo desplazado)
    pocas = x0.copy()
    pocas[:150 * AR] = np.concatenate([np.zeros(d, np.float32), x0[:150 * AR - d]])    # 0-150 s, 120 ms tarde
    # (otros graves: con los mismos más flojos, la correlación, que no mira el volumen, sí lo mediría)
    otros = _sosfilt(_butter(4, 200, "low", fs=AR, output="sos"), np.random.default_rng(5).standard_normal(n)) * 3
    pocas[150 * AR:] = (otros[150 * AR:] + voz(3)[150 * AR:]).astype(np.float32)
    pocas[int(149.6 * AR):int(150.4 * AR)] = 0
    db_p = sd.niveles_db(pocas.reshape(-1, 1), AR)
    corte_p = [dict(c=150.0, q0=149.6, q1=150.4, suelo=-120.0)]
    L_no = sd.contrastar_doblada(pocas, y, [0.0, 0.0], corte_p, 300.0, lambda: db_p)[0]
    L_es = sd.contrastar_doblada(pocas, y, [0.0, 0.0], corte_p, 300.0, lambda: db_p, estricto=True)[0]
    if len(L_no) != 1 or abs(L_no[0] + 0.120) > 0.005:
        fallos.append(f"sin estricto, el tramo sin medida no va como el de al lado: L {[round(v * 1000) for v in L_no]}")
    if len(L_es) != 2 or abs(L_es[0] + 0.120) > 0.005 or abs(L_es[1]) > 1e-9:
        fallos.append(f"estricto, el tramo sin medida no se queda donde estaba: L {[round(v * 1000) for v in L_es]}")
    sug = sd.avisos_descolocados([(99.3, 108.6, 1.5, 4, 4)])[0]
    m = re.search(r"«(.+)»", sug)
    try:
        leida = sd.leer_correcciones(m[1]) if m else None
    except ValueError:
        leida = None
    if not leida or abs(leida[0][2] - 1.5) > 1e-6 or leida[0][0] > 99.3 or leida[0][1] < 108.6:
        fallos.append(f"la corrección sugerida no se lee bien: «{m[1] if m else sug}» -> {leida}")
    # el repaso del recorrido: 3 ventanas seguidas de acuerdo (aunque dos sean flojas) y apartadas 30 ms o más hacen
    # trozo aparte; 2, no; y el aviso de un corte dudoso solo si el salto se notaría (40 ms o más)
    pk = np.array([-138.0] * 4 + [-14.0, -15.0, -13.0] + [-138.0] * 4)
    fz = np.array([0.6] * 4 + [0.22, 0.25, 0.35] + [0.6] * 4)
    tr = sd.apartar_seguidas([dict(w0=0, w1=10, d=-0.138, apoyo=[0, 1, 2, 3, 7, 8, 9, 10])], pk, fz)
    if [round(t["d"] * 1000) for t in tr] != [-138, -14, -138]:
        fallos.append(f"repaso: 3 ventanas a -14 dentro de -138 dan {[round(t['d'] * 1000) for t in tr]}")
    pk2, fz2 = pk.copy(), fz.copy()
    fz2[4] = 0.1
    if len(sd.apartar_seguidas([dict(w0=0, w1=10, d=-0.138, apoyo=list(range(11)))], pk2, fz2)) != 1:
        fallos.append("repaso: con solo 2 ventanas a -14 se parte el trozo")
    duda = dict(dudas=[(130.0, 186.0, 137.8)])
    if not sd.avisos_dudas(duda) or "entre 2:10" not in sd.avisos_dudas(duda)[0]:
        fallos.append(f"aviso de corte dudoso: {sd.avisos_dudas(duda)}")
    out.append(("contraste_con_el_original", "con guía, la pista doblada se contrasta con el original y se corrige "
                                             "por trozos solo si hace falta (y los tramos cortos; estricto con la "
                                             "imagen; la corrección sugerida se puede usar)", fallos))
    # el montaje con bloques en otro orden (Top Dog, 1.4.9): el doblaje A C B D de un original A B C D, con los desfases
    # medidos, sale A B C D sin quitar ni rellenar nada; y si al doblaje le faltan 3 s entre B y C, solo esos 3 s van
    # con el original. En orden, lo de siempre: lo que sobra se quita y lo que falta se rellena
    fs = 8000
    rng = np.random.default_rng(4)
    trozo = lambda s: (rng.standard_normal((int(s * fs), 2)) * 0.1).astype(np.float32)
    A, B, C, D = trozo(10), trozo(10), trozo(10), trozo(10)
    es = np.concatenate([A, C, B, D])
    orig = (rng.standard_normal((60 * fs, 2)) * 0.1).astype(np.float32)
    original = lambda tramos: [orig[a:b] for a, b in tramos]
    cortes_m = [dict(c=c, q0=c - 0.1, q1=c + 0.1, suelo=-50.0) for c in (10.0, 20.0, 30.0)]
    fallos = []
    if [sd.es_reordenado(cortes_m, [0.0, 10.0, -10.0, 0.0], 40.0, i) for i in range(3)] != [False, True, False]:
        fallos.append("el bloque que vuelve atrás no se ve como bloque en otro orden")
    out_m, _, rell = sd.montar(es, fs, 0.0, [0.0, 10.0, -10.0, 0.0], cortes_m, 40.0, 0, original)
    F = int(sd.FADE_S * fs)
    dif = np.abs(out_m - np.concatenate([A, B, C, D])).max(1)
    lejos = [i for i in np.where(dif > 1e-6)[0] if min(abs(i - q) for q in range(0, 40 * fs + 1, 10 * fs)) > F]
    if lejos or rell:
        fallos.append(f"A C B D no sale A B C D: {len(lejos)} muestras distintas, rellenos {rell}")
    _, _, rell = sd.montar(es, fs, 0.0, [0.0, 13.0, -10.0, 3.0], cortes_m, 43.0, 0, original)
    if [(round(a / fs, 3), round(b / fs, 3)) for _, a, b, _ in rell] != [(20.0, 23.0)]:
        fallos.append(f"con 3 s que faltan entre B y C, rellenos {[(a / fs, b / fs) for _, a, b, _ in rell]}")
    cortes_o = [dict(c=10.0, q0=9.0, q1=11.0, suelo=-50.0)]
    if sd.limites(cortes_o, [0.0, -1.0], 40.0) != ([0.0, 10.5], [9.5, 40.0]):
        fallos.append(f"en orden, 1 s que sobra: {sd.limites(cortes_o, [0.0, -1.0], 40.0)}")
    out.append(("montaje_en_otro_orden", "bloques en otro orden: no se quita ni se rellena nada (en orden, lo de "
                                         "siempre)", fallos))
    # la comprobación de los empalmes de los rellenos (1.4.6): un relleno de 20-30 s; si el corte va 1 s tarde, lo de
    # justo antes del relleno es lo de después del hueco. También con la lateral callada, solo con la mezcla
    rng = np.random.default_rng(5)
    en = rng.standard_normal(60 * sd.AR).astype(np.float32)
    mal = en.copy()
    mal[19 * sd.AR:20 * sd.AR] = en[29 * sd.AR:30 * sd.AR]
    tarde = en.copy()
    tarde[30 * sd.AR:31 * sd.AR] = en[20 * sd.AR:21 * sd.AR]
    trozos = lambda x: (lambda i0, n: x[i0:i0 + n])
    fallos = []
    if sd.empalmes_dudosos(en, en, [(20.0, 30.0)]):
        fallos.append("avisa de un empalme que está bien")
    for nombre, x, lado, lat, mezcla in (("tarde", mal, "antes", mal, None), ("pronto", tarde, "después", tarde, None),
                                         ("tarde, con la lateral callada", mal, "antes", np.zeros_like(en),
                                          (trozos(mal), trozos(en)))):
        e = sd.empalmes_dudosos(lat, en if mezcla is None else rng.standard_normal(len(en)).astype(np.float32),
                                [(20.0, 30.0)], mezcla)
        if len(e) != 1 or e[0][2] != lado:
            fallos.append(f"empalme {nombre}: {e}")
        elif not any("el empalme del relleno" in a and sd.para_revisar(a) for a in sd.avisos_empalmes(e)):
            fallos.append(f"empalme {nombre}: el aviso no es para revisar: {sd.avisos_empalmes(e)}")
    out.append(("empalme_del_relleno", "un relleno con el empalme 1 s tarde o pronto se avisa, también donde la "
                                       "lateral calla", fallos))
    # el contraste con las voces (1.4.8, Aquellos maravillosos 70 3x04): habla fabricada (frases con tono de voz, sílabas
    # y pausas) y otro ruido de fondo en el doblaje; su primer minuto, 300 ms tarde. Tiene que partir el tramo en la pausa
    # de después de la última frase desplazada (61,86-62,90 s), y no tocar lo que ya mide la onda ni lo que va a la par
    dur = 150.0
    tt_ = np.arange(int(dur * sd.AR)) / sd.AR

    def frases(desplaza):
        out_, r_, s_ = np.zeros(len(tt_), np.float32), np.random.default_rng(11), 0.5
        while s_ < dur - 4:
            d_, f0 = r_.uniform(0.8, 2.5), r_.uniform(110, 220)
            i0, n_ = int(desplaza(s_) * sd.AR), int(d_ * sd.AR)
            t_ = np.arange(n_) / sd.AR
            onda = sum(np.sin(2 * np.pi * f0 * k * t_ + k) / k for k in range(1, 9))
            out_[i0:i0 + n_] += (onda * (0.55 + 0.45 * np.sin(2 * np.pi * 4 * t_))).astype(np.float32)
            s_ += d_ + r_.uniform(0.4, 1.5)
        return out_
    rng = np.random.default_rng(7)
    en = frases(lambda s: s) + 0.05 * rng.standard_normal(len(tt_)).astype(np.float32)
    fondo = 0.05 * rng.standard_normal(len(tt_)).astype(np.float32)
    bien, mal = frases(lambda s: s) + fondo, frases(lambda s: s + 0.3 if s < 60 else s) + fondo
    fallos = []
    for nombre, x, prot, esperado in (("a la par", bien, (), False), ("el primer minuto 300 ms tarde", mal, (), True),
                                      ("lo mismo, donde ya mide la onda", mal, ((10.0, 25.0),), False)):
        _, nc, mov, nuevos, _ = sd.contrastar_voces(x, en, [0.0], [], dur,
                                                    lambda: sd.niveles_db(x.reshape(-1, 1), sd.AR), prot)
        if not esperado and mov:
            fallos.append(f"{nombre}: lo mueve {[(round(a, 1), round(b, 1), round(d * 1000)) for a, b, d, _ in mov]}")
        elif esperado and (len(mov) != 1 or abs(mov[0][2] + 0.3) > 0.02 or nuevos != 1
                           or not 61.86 <= nc[0]["c"] <= 62.90):
            fallos.append(f"{nombre}: {[(round(a, 2), round(b, 2), round(d * 1000)) for a, b, d, _ in mov]}, "
                          f"cortes nuevos {nuevos}" + (f" en {nc[0]['c']:.2f} s" if nc else ""))
    out.append(("contraste_con_las_voces", "sin sonido en común, las voces dicen si el doblaje va desfasado de su imagen "
                                           "y desde dónde (cortado en la pausa justa); lo que mide la onda no se toca",
                fallos))
    # las voces con música fuerte (1.4.11, repaso de puntos débiles): habla real (Vaya Semanita) igual en los dos, a la
    # par, con una canción real (la cabecera de Sandokan) al doble de volumen que en el doblaje va 0,4 s más tarde (la
    # música vuelta a poner): la envolvente sigue a la música y la 1.4.10 lo «corregía» -400 ms. No se toca (y se
    # anota). Y el doblaje entero, música incluida, 0,25 s tarde con la música al mismo volumen: eso sí se corrige
    fallos = []
    try:
        def clip(nombre, desde, largo):
            r = subprocess.run(["ffmpeg", "-v", "error", "-ss", str(desde), "-t", str(largo), "-i",
                                os.path.join(carpeta, nombre), "-vn", "-ac", "1", "-ar", str(sd.AR), "-f", "f32le", "-"],
                               capture_output=True)
            return np.frombuffer(r.stdout, np.float32).copy()
        dur = 45.0
        n_ = int(dur * sd.AR)
        habla = clip(OTRO_DIALOGO, 20, dur)[:n_]
        musica = clip("Sandokan - El tigre de Malasia Opening Español.mp4", 1, dur + 1)
        if len(habla) < n_ or len(musica) < n_ + sd.AR // 2:
            raise RuntimeError("no se han podido leer los clips")
        musica *= np.sqrt(np.mean(habla ** 2)) / (np.sqrt(np.mean(musica ** 2)) + 1e-9)
        rng = np.random.default_rng(3)
        ruido = lambda: 0.01 * rng.standard_normal(n_).astype(np.float32)
        sh = int(0.4 * sd.AR)
        x, en = habla + 2 * musica[:n_] + ruido(), habla + 2 * musica[sh:sh + n_] + ruido()
        _, _, mov, _, desc = sd.contrastar_voces(x, en, [0.0], [], dur, lambda: sd.niveles_db(x.reshape(-1, 1), sd.AR))
        if mov:
            fallos.append(f"música movida, voces a la par: lo mueve "
                          f"{[(round(a, 1), round(b, 1), round(d * 1000)) for a, b, d, _ in mov]}")
        elif not desc:
            fallos.append("música movida, voces a la par: no se anota lo que la voz no sostiene")
        sh = int(0.25 * sd.AR)
        todo = habla + musica[sh:sh + n_]
        x, en = np.concatenate([np.zeros(sh, np.float32), todo[:-sh]]) + ruido(), todo + ruido()
        _, _, mov, _, _ = sd.contrastar_voces(x, en, [0.0], [], dur, lambda: sd.niveles_db(x.reshape(-1, 1), sd.AR))
        if len(mov) != 1 or abs(mov[0][2] + 0.25) > 0.02:
            fallos.append(f"el doblaje entero 250 ms tarde: {[(round(a, 1), round(b, 1), round(d * 1000)) for a, b, d, _ in mov]}")
    except Exception as e:
        fallos.append(f"no se pudo probar: {e}")
    out.append(("voces_con_musica", "con música fuerte movida y las voces a la par no se toca nada; el doblaje entero "
                                    "desfasado, sí", fallos))
    # el principio con el sonido (1.4.8, Aquellos maravillosos 70 3x04: la cortinilla sonaba dos veces): el doblaje empieza
    # con 1 s de silencio y la misma cortinilla (que acaba en un silencio corto), y a su escena le faltan 2 s; la imagen
    # lo ha puesto todo con el desfase de la escena (+1 s). La cortinilla tiene que ir a -1 s, con el corte entre las dos
    rng = np.random.default_rng(3)
    en = rng.standard_normal(int(60 * sd.AR)).astype(np.float32)
    en[int(5.4 * sd.AR):int(6.0 * sd.AR)] *= 0.01
    dob = np.concatenate([np.zeros(sd.AR, np.float32), en[:6 * sd.AR], en[8 * sd.AR:]])
    fallos = []
    _, nc, partes = sd.extremos_por_sonido(dob, en, [1.0], [], len(dob) / sd.AR,
                                           lambda: sd.niveles_db(dob.reshape(-1, 1), sd.AR))
    if (len(partes) != 1 or partes[0][0] != "Principio" or abs(partes[0][3] + 2.0) > 0.01
            or not 6.3 <= nc[0]["c"] <= 7.1):
        fallos.append(f"principio: {[(l, round(a, 2), round(b, 2), round(d, 3)) for l, a, b, d, _ in partes]}")
    _, _, partes = sd.extremos_por_sonido(en, en, [0.0], [], len(en) / sd.AR, lambda: sd.niveles_db(en.reshape(-1, 1), sd.AR))
    if partes:
        fallos.append(f"con el mismo audio a la par mueve {partes}")
    out.append(("principio_con_el_sonido", "medido con la imagen, la cortinilla del principio va donde la pone su sonido "
                                           "(no suena dos veces), cortada antes de la escena", fallos))
    # los golpes con huecos (1.4.10, Top Dog 24:48-26:54: golpes a ratos, todos a +300 ms, con medio minuto de diálogo sin
    # golpes en medio; solo se corregían los trozos con tres ventanas seguidas). Tres tramos; en el del medio los golpes
    # del doblaje van 300 ms adelantados al principio y al final, y en su mitad no hay ninguno: se mueve entero
    fs_g = sd.GOLPES_FS
    rng = np.random.default_rng(11)
    dur_g = 120.0
    y = (0.01 * rng.standard_normal(int(dur_g * fs_g))).astype(np.float32)
    x = (0.01 * rng.standard_normal(int(dur_g * fs_g))).astype(np.float32)     # (cada uno con su fondo)
    t_g = 1.0
    while t_g < dur_g - 1:
        if not 45.0 <= t_g < 75.0:          # (el diálogo: sin golpes)
            golpe = (rng.standard_normal(int(0.006 * fs_g)) * np.hanning(int(0.006 * fs_g))).astype(np.float32)
            j = int(t_g * fs_g)
            y[j:j + len(golpe)] += golpe
            k = int((t_g - 0.3 if 30.0 <= t_g < 90.0 else t_g) * fs_g)
            x[k:k + len(golpe)] += golpe
        t_g += rng.uniform(0.25, 0.9)
    cortes_g = [dict(c=30.0, q0=30.0, q1=30.0, suelo=-60.0), dict(c=90.0, q0=90.0, q1=90.0, suelo=-60.0)]
    nL, nc, mov, nuevos = sd.contrastar_golpes(x, y, [0.0, 0.0, 0.0], cortes_g, dur_g,
                                               lambda: sd.niveles_db(x.reshape(-1, 1), fs_g), (), fs_g)
    fallos = []
    if (len(mov) != 1 or abs(mov[0][0] - 30.0) > 0.01 or abs(mov[0][1] - 90.0) > 0.01 or abs(mov[0][2] - 0.3) > 0.02
            or nuevos != 0 or len(nL) != 3 or abs(nL[0]) > 1e-9 or abs(nL[2]) > 1e-9):
        fallos.append(f"mueve {[(round(a, 2), round(b, 2), round(d * 1000)) for a, b, d, _ in mov]}, cortes nuevos "
                      f"{nuevos}, desfases {[round(v, 3) for v in nL]}")
    out.append(("golpes_con_huecos", "los golpes de un tramo cuentan juntos aunque haya un rato sin golpes en medio: se "
                                     "mueve entero, y lo de al lado no", fallos))
    # lo poco desplazado junto a una racha (1.4.11, Locomundo de Tex Avery 1x60: 0:43-1:01 a -48 ms entre -74 y -144 se
    # quedaba en 0, una isla con dos cortes): un tramo con los golpes del doblaje 74 ms tarde (0-30 s), 40 ms (30-50 s) y
    # 144 ms (50-100 s). Lo del medio va con lo de antes: un solo corte, a ±1,5 s de los 50 s (con lo que mide cada lado
    # junto al corte: con la mediana de todo lo de antes caía en 45 s)
    rng = np.random.default_rng(12)
    dur_g = 100.0
    y = (0.01 * rng.standard_normal(int(dur_g * fs_g))).astype(np.float32)
    x = (0.01 * rng.standard_normal(int(dur_g * fs_g))).astype(np.float32)
    t_g = 1.0
    while t_g < dur_g - 1:
        golpe = (rng.standard_normal(int(0.006 * fs_g)) * np.hanning(int(0.006 * fs_g))).astype(np.float32)
        y[int(t_g * fs_g):int(t_g * fs_g) + len(golpe)] += golpe
        k = int((t_g + (0.074 if t_g < 30.0 else 0.040 if t_g < 50.0 else 0.144)) * fs_g)
        x[k:k + len(golpe)] += golpe
        t_g += rng.uniform(0.25, 0.9)
    nL, nc, mov, nuevos = sd.contrastar_golpes(x, y, [0.0], [], dur_g,
                                               lambda: sd.niveles_db(x.reshape(-1, 1), fs_g), (), fs_g)
    fallos = []
    if (len(mov) != 2 or abs(mov[0][0]) > 0.01 or abs(mov[0][2] + 0.074) > 0.01 or abs(mov[1][2] + 0.144) > 0.01
            or not 48.5 <= mov[0][1] <= 51.5 or nuevos != 1):
        fallos.append(f"mueve {[(round(a, 2), round(b, 2), round(d * 1000)) for a, b, d, _ in mov]}, cortes nuevos "
                      f"{nuevos}")
    out.append(("golpes_poco_junto", "lo que se aparta poco junto a una corrección va con ella (sin isla en 0 ni corte de "
                                     "más)", fallos))
    # el corte en un hueco sin golpes (1.4.11, Locomundo 1x60 con 300 ms metidos: caía al principio del hueco, 8 s antes):
    # -74 ms con golpes en 0-40 s, -144 ms en 60-100 s y sin golpes en medio (el cambio, en 50 s). En la mitad del hueco
    # (la 1.4.10: 56,1 s y 41,9 s según el ruido)
    fallos = []
    for semilla in (12, 14):
        rng = np.random.default_rng(semilla)
        y = (0.01 * rng.standard_normal(int(dur_g * fs_g))).astype(np.float32)
        x = (0.01 * rng.standard_normal(int(dur_g * fs_g))).astype(np.float32)
        t_g = 1.0
        while t_g < dur_g - 1:
            if not 40.0 <= t_g < 60.0:
                golpe = (rng.standard_normal(int(0.006 * fs_g)) * np.hanning(int(0.006 * fs_g))).astype(np.float32)
                y[int(t_g * fs_g):int(t_g * fs_g) + len(golpe)] += golpe
                k = int((t_g + (0.074 if t_g < 50.0 else 0.144)) * fs_g)
                x[k:k + len(golpe)] += golpe
            t_g += rng.uniform(0.25, 0.9)
        nL, nc, mov, nuevos = sd.contrastar_golpes(x, y, [0.0], [], dur_g,
                                                   lambda: sd.niveles_db(x.reshape(-1, 1), fs_g), (), fs_g)
        if len(mov) != 2 or not 48.0 <= mov[0][1] <= 52.0 or nuevos != 1:
            fallos.append(f"ruido {semilla}: mueve {[(round(a, 2), round(b, 2), round(d * 1000)) for a, b, d, _ in mov]}, "
                          f"cortes nuevos {nuevos}")
    out.append(("golpes_corte_en_hueco", "entre dos desplazamientos con un hueco sin golpes, el corte va en la mitad del "
                                         "hueco", fallos))
    # una ventana suelta que no va con nada no frena (1.4.11, Locomundo 1x60 con 300 ms metidos: una ventana a +565 ms
    # entre una racha a -448 y otra a -111 dejaba 16 s en 0 con dos cortes). Con lo que miden las ventanas puesto a mano:
    # -448 ms en 0-45 s, una sola a +565 en 50 s y -111 ms en 56-90 s: un corte, sin nada en 0 entre las dos. (Con ruido
    # en vez de golpes, dónde caen los cortes es cosa del ruido y la 1.4.10 también sale bien aquí: lo que demuestra el
    # arreglo es la copia de Locomundo con fallos metidos; esto guarda que no vuelva)
    fallos = []
    medir_ = sd.medir_golpes
    try:
        for nombre, suelta, esperado in (("suelta a +565 ms", 0.565, 1),):
            def falso(gx, gy, t, L, suelta=suelta):
                return -0.448 if t < 45.0 else -0.111 if 56.0 <= t < 90.0 else suelta if abs(t - 50.0) < 0.5 else None
            sd.medir_golpes = falso
            ruido_g = (0.01 * np.random.default_rng(1).standard_normal(int(100 * fs_g))).astype(np.float32)
            nL, nc, mov, nuevos = sd.contrastar_golpes(ruido_g, ruido_g, [0.0], [], 100.0,
                                                       lambda: sd.niveles_db(ruido_g.reshape(-1, 1), fs_g), (), fs_g)
            if nuevos != esperado or (esperado == 1 and [round(d, 3) for _, _, d, _ in mov] != [-0.448, -0.111]):
                fallos.append(f"{nombre}: mueve {[(round(a, 2), round(b, 2), round(d * 1000)) for a, b, d, _ in mov]}, "
                              f"cortes nuevos {nuevos} (tenían que ser {esperado})")
    finally:
        sd.medir_golpes = medir_
    out.append(("golpes_suelta", "una ventana suelta que no va con nada no hace de barrera (una que mide 0, sí)",
                fallos))
    # golpes fiables (1.4.10, Top Dog): una explosión colocada distinto en la mezcla del doblaje arrastraba las ventanas
    # que la contenían (66:43-67:01, +517 ms), y la rejilla de 10 ms decidía sola entre dos picos donde los golpes eran
    # flojos (70:09-70:26: +150 con la del doblaje, +1 con la del resultado). Doblaje bien colocado con un golpe muy
    # fuerte 500 ms más tarde: no se mueve nada; y el mismo audio, con el desfase a media trama o a un cuarto, mide igual
    rng = np.random.default_rng(13)
    y = (0.01 * rng.standard_normal(int(dur_g * fs_g))).astype(np.float32)
    x = (0.01 * rng.standard_normal(int(dur_g * fs_g))).astype(np.float32)
    t_g = 1.0
    while t_g < dur_g - 1:
        golpe = (rng.standard_normal(int(0.006 * fs_g)) * np.hanning(int(0.006 * fs_g))).astype(np.float32)
        a_g = rng.uniform(0.15, 0.4)
        if not 45.0 <= t_g < 75.0:          # (alrededor de la explosión, diálogo: ningún otro golpe)
            y[int(t_g * fs_g):int(t_g * fs_g) + len(golpe)] += a_g * golpe
            x[int(t_g * fs_g):int(t_g * fs_g) + len(golpe)] += a_g * golpe
        t_g += rng.uniform(0.4, 1.2)
    fuerte = (rng.standard_normal(int(0.03 * fs_g)) * np.hanning(int(0.03 * fs_g))).astype(np.float32) * 6.0
    y[int(60.0 * fs_g):int(60.0 * fs_g) + len(fuerte)] += fuerte
    x[int(60.5 * fs_g):int(60.5 * fs_g) + len(fuerte)] += fuerte
    fallos = []
    _, _, mov, _ = sd.contrastar_golpes(x, y, [0.0], [], dur_g, lambda: sd.niveles_db(x.reshape(-1, 1), fs_g), (), fs_g)
    if mov:
        fallos.append(f"un solo golpe desplazado mueve {[(round(a, 1), round(b, 1), round(d * 1000)) for a, b, d, _ in mov]}")
    medidas = []
    for frac in (0.0, 0.25, 0.5, 0.75):        # (el desfase, a esa fracción de trama de 10 ms)
        dl = int(round((3.0 + frac * 0.01) * fs_g))
        gx_ = sd.senal_golpes(np.concatenate([np.zeros(dl, np.float32), y]), fs_g)
        gy_ = sd.senal_golpes(y, fs_g)
        medidas.append([sd.medir_golpes(gx_, gy_, t + dl / fs_g, -dl / fs_g) for t in (20.0, 40.0, 80.0)])
    for m_ in medidas[1:]:
        if any((u is None) != (v is None) or (u is not None and abs(u - v) > 0.003) for u, v in zip(m_, medidas[0])):
            fallos.append(f"con el desfase a media trama o a un cuarto mide distinto: {medidas}")
            break
    if any(v is None or abs(v) > 0.003 for v in medidas[0]):
        fallos.append(f"el mismo audio no mide 0: {medidas[0]}")
    out.append(("golpes_fiables", "un solo golpe desplazado no mueve nada, y lo medido no depende de dónde caiga la "
                                  "rejilla de 10 ms", fallos))
    # las frases enteras en los bordes (1.4.10, Top Dog, la cabecera): un recorte de 1,8 s centrado en el corte partía dos
    # frases; tiene que ir donde sus dos bordes caen en pausas de la voz (lo de antes y lo de después, donde iban)
    fs_v = 16000
    tt_v = np.arange(int(30 * fs_v)) / fs_v

    def voces(tramos):
        z = (0.003 * np.random.default_rng(5).standard_normal(len(tt_v))).astype(np.float32)
        for a_, b_ in tramos:
            m_ = (tt_v >= a_) & (tt_v < b_)
            t_ = tt_v[m_] - a_
            z[m_] += (0.3 * sum(np.sin(2 * np.pi * 160 * k * t_) / k for k in range(1, 9))
                      * (0.6 + 0.4 * np.sin(2 * np.pi * 4 * t_))).astype(np.float32)
        return z.reshape(-1, 1)
    es_v = voces([(10.0, 12.0), (12.6, 13.4), (14.6, 16.0)])
    db_v = sd.niveles_db(es_v, fs_v)
    fallos = []
    c_v = [dict(c=12.3, q0=12.2, q1=12.4, suelo=-40.0)]
    sd.recortes_en_pausas(es_v, fs_v, c_v, [0.0, -1.8], 30.0, db_v)
    s_v = c_v[0]["c"] - 0.9
    if not (12.03 <= s_v <= 12.57 and 13.43 <= s_v + 1.8 <= 14.57):
        fallos.append(f"el recorte va en {s_v:.2f}-{s_v + 1.8:.2f} s (tenía que empezar tras la frase de 10-12 s y "
                      "acabar entre 13,4 y 14,6 s)")
    # un trozo de voz corto que sigue enseguida en lo que se quita es una frase partida (el «¿Por» de «¿Por qué?»): de
    # las dos formas de quitar 2,5 s con los bordes en pausas, la que no lo deja colgando
    es_p = voces([(10.0, 11.5), (11.85, 12.05), (12.4, 13.0), (13.3, 13.95), (15.0, 16.0)])
    c_p = [dict(c=12.25 + 1.25, q0=12.1, q1=12.4, suelo=-40.0, reordenado=False)]
    sd.recortes_en_pausas(es_p, fs_v, c_p, [0.0, -2.5], 30.0, sd.niveles_db(es_p, fs_v))
    s_p = c_p[0]["c"] - 1.25
    if not (11.5 <= s_p <= 11.85 and 13.95 <= s_p + 2.5 <= 15.0):
        fallos.append(f"con una frase partida, el recorte va en {s_p:.2f}-{s_p + 2.5:.2f} s (tenía que empezar entre "
                      "11,5 y 11,85 s, sin dejar suelto el trozo de 11,85-12,05 s)")
    c_v = [dict(c=14.0, q0=13.5, q1=14.5, suelo=-60.0)]          # (ya en una pausa: no se toca)
    sd.recortes_en_pausas(es_v, fs_v, c_v, [0.0, -0.5], 30.0, db_v)
    if abs(c_v[0]["c"] - 14.0) > 1e-9:
        fallos.append(f"un recorte que ya cae en una pausa se mueve a {c_v[0]['c']:.2f} s")
    # lo que no se coloca (la imagen acaba en 7,5 s y vuelve en 15 s) empieza tras la frase que cruza 7,5 s y acaba antes
    # de la que cruza 15 s
    es_z = voces([(5.0, 8.0), (14.6, 17.0)])
    zonas_v = [dict(d0=7.5, d1=15.0)]
    sd.bordes_de_zonas(es_z, fs_v, zonas_v, [0.0], [], 30.0)
    if not (8.03 <= zonas_v[0]["d0"] <= 8.5 and 14.0 <= zonas_v[0]["d1"] <= 14.57):
        fallos.append(f"lo que no se coloca va de {zonas_v[0]['d0']:.2f} a {zonas_v[0]['d1']:.2f} s (tenía que ir de "
                      "tras la frase que acaba en 8 s a antes de la que empieza en 14,6 s)")
    out.append(("frases_enteras", "un recorte va donde sus dos bordes caen en pausas de la voz, y lo que no se coloca, "
                                  "del final de una frase al principio de otra", fallos))
    # el recorte, dentro de donde la medida pone el salto (1.4.11, repaso de puntos débiles) salvo que ahí parta una frase
    # (1.4.13, El último superviviente 1x01; el usuario: ninguna frase partida, ni en castellano ni en inglés): la imagen
    # dice que sobra 1 s entre dos cambios de plano (12,0 y 13,3 s) y ahí dentro no hay dónde quitarlo sin partir la
    # frase de 12,4-14,5 s. A 1 s antes hay dos pausas justas, pero eso sería quitar entera la frase de 11,3-11,9 s, que
    # el original tiene (la 1.4.10 lo hacía): eso nunca. Va en la pausa de después de esa frase (la imagen, ese rato, 1 s
    # desplazada): no se quita ninguna frase ni se parte. Y con el margen del audio, igual
    fallos = []
    es_e = voces([(9.0, 10.8), (11.3, 11.9), (12.4, 14.5)])
    db_e = sd.niveles_db(es_e, fs_v)
    c_e = [sd.punto_entre(db_e, 12.0, 13.3, -1.0)]
    sd.recortes_en_pausas(es_e, fs_v, c_e, [0.0, -1.0], 30.0, db_e)
    q0_e, q1_e = c_e[0]["c"] - 0.5, c_e[0]["c"] + 0.5
    if not 14.5 <= q0_e <= 15.0:
        fallos.append(f"lo que se quita va de {q0_e:.2f} a {q1_e:.2f} s (tenía que ir en la pausa de después de la frase "
                      "de 12,4-14,5 s: sin partirla ni quitar la de 11,3-11,9 s)")
    c_a = [dict(sd.punto_silencio(db_e, 12.6, 0.1), entre=(11.95, 13.35))]
    sd.recortes_en_pausas(es_e, fs_v, c_a, [0.0, -1.0], 30.0, db_e)
    if not 14.5 <= c_a[0]["c"] - 0.5 <= 15.0:
        fallos.append(f"con el margen del audio, lo que se quita va de {c_a[0]['c'] - 0.5:.2f} a {c_a[0]['c'] + 0.5:.2f} s")
    # y si dentro hay dónde quitarlo limpio, ahí, aunque fuera haya pausas más largas
    es_l = voces([(9.0, 10.8), (11.3, 11.9), (12.0, 12.3), (13.6, 14.5)])
    db_l = sd.niveles_db(es_l, fs_v)
    c_l = [sd.punto_entre(db_l, 12.0, 14.0, -1.0)]
    sd.recortes_en_pausas(es_l, fs_v, c_l, [0.0, -1.0], 30.0, db_l)
    if not (12.0 - 1e-6 <= c_l[0]["c"] - 0.5 and c_l[0]["c"] + 0.5 <= 14.0 + 1e-6):
        fallos.append(f"con sitio limpio dentro, lo que se quita va de {c_l[0]['c'] - 0.5:.2f} a "
                      f"{c_l[0]['c'] + 0.5:.2f} s, fuera de los cambios de plano (12,0-14,0 s)")
    out.append(("recorte_en_su_sitio", "un recorte no sale de donde la medida pone el salto salvo para no partir una "
                                       "frase, y nunca se lleva una frase que el original tiene", fallos))
    # (1.4.12) dos trozos del doblaje en el mismo sitio del original (El último superviviente 1x02, lo de antes de las
    # pausas): imagen y sonido fabricados (fotogramas al azar, 10 por segundo, y ruido), con 30 s de 150-180 del original
    # metidos en el 60 del doblaje. Medido mal a propósito: el avance encima de su escena (+90) y 90-120 con un desfase
    # donde la imagen no está (-10, no -30). 90-120 vuelve a -30 (paso 1), el avance no se coloca (paso 2) y el recorte
    # de 30 s va en 60-90. Medido como lo dejaba el audio en la prueba avance_escena (el avance con el tramo de antes), lo
    # mismo (paso 3). Y bien medido no se toca nada
    fallos = []
    rng = np.random.default_rng(7)
    fo = rng.integers(0, 256, (240 * 10, 48, 64), dtype=np.uint8)
    au = rng.standard_normal(240 * sd.AR).astype(np.float32)
    partes_r = [(0, 60), (150, 180), (60, 240)]
    fd = np.concatenate([fo[x * 10:y * 10] for x, y in partes_r])
    ad = np.concatenate([au[x * sd.AR:y * sd.AR] for x, y in partes_r])
    img_r = ((np.arange(len(fd)) / 10, fd), (np.arange(len(fo)) / 10, fo))
    for nombre_r, segs_r in (("con el avance colocado", [[0.0, 60.0, 0.0], [60.0, 90.0, 90.0], [90.0, 120.0, -10.0],
                                                          [120.0, 270.0, -30.0]]),
                             ("con el avance en el tramo de antes", [[0.0, 90.0, 0.0], [90.0, 270.0, -30.0]])):
        msgs = []
        try:
            nuevos_r, entre_r, av_r = sd.repeticiones_en_audio([list(s) for s in segs_r], {}, 0.0, None, 0.0, img_r, ad,
                                                               au, msgs.append)
        except Exception as e:
            fallos.append(f"{nombre_r}: revienta ({e})")
            continue
        bien = (len(nuevos_r) == 2 and abs(nuevos_r[0][1] - 60) < 0.3 and abs(nuevos_r[0][2]) < 0.01
                and abs(nuevos_r[1][0] - 90) < 0.3 and abs(nuevos_r[1][2] + 30) < 0.01 and 0 in entre_r
                and abs(entre_r[0][0] - 60) < 0.3 and abs(entre_r[0][1] - 90) < 0.3
                and any("no está en el original" in x for x in av_r))
        if not bien:
            fallos.append(f"{nombre_r}: sale {[[round(x, 2) for x in s] for s in nuevos_r]}, huecos "
                          f"{ {i: (round(v[0], 2), round(v[1], 2)) for i, v in entre_r.items()} }, avisos {av_r}")
        dice = [x[:27] for x in msgs]
        if len(segs_r) == 4 and not ("Desfase con la imagen: 1:30" in dice and "Repetición: 1:00.00-1:30.00" in dice):
            fallos.append(f"{nombre_r}: no lo dice el informe ({msgs})")
    # (bien medido: al doblaje le faltan 60-90 del original, y eso no se toca)
    segs_b = [[0.0, 60.0, 0.0], [60.0, 210.0, 30.0]]
    fd_b, ad_b = np.concatenate([fo[:600], fo[900:]]), np.concatenate([au[:60 * sd.AR], au[90 * sd.AR:]])
    img_b = ((np.arange(len(fd_b)) / 10, fd_b), img_r[1])
    if sd.repeticiones_en_audio(segs_b, {}, 0.0, None, 0.0, img_b, ad_b, au, lambda *_: None)[0] is not segs_b:
        fallos.append("bien medido, cambia algo")
    out.append(("repeticiones", "dos trozos del doblaje en el mismo sitio del original: se queda el que dice la imagen "
                                "(o el largo) y lo que no está en el original va en el recorte", fallos))
    # un nombre sin definir solo revienta al pasar por esa línea (así se paró la tanda de «solo subtítulos» de la GUI
    # tras el primer episodio, 23-10-2026): se buscan en todos los archivos del programa sin ejecutarlos
    fallos = [f"{os.path.basename(f)}, línea {ln} ({func}): «{nombre}» no existe"
              for f in ("sincronizar_doblaje.py", "Sincronizar_Doblaje_Gui.py", "limpiar_vhs.py",
                        "probar_sincronizador.py", "actualizador.py", "actualizador_ventana.py")
              if os.path.exists(os.path.join(AQUI, f))
              for ln, func, nombre in nombres_sin_definir(os.path.join(AQUI, f))]
    out.append(("nombres_definidos", "ninguna función usa una variable que no existe", fallos))
    return out


FUNCIONES = (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)


def _mismo_ambito(nodo):
    """Los nodos que cuelgan de un ámbito sin entrar en las funciones y clases de dentro (que son otro ámbito)."""
    for h in ast.iter_child_nodes(nodo):
        yield h
        if not isinstance(h, FUNCIONES + (ast.ClassDef,)):
            yield from _mismo_ambito(h)


def _ligados(nodo):
    """Los nombres que crea un ámbito: argumentos, asignaciones, imports, def, except … as, global, for, :=."""
    out = set()
    if isinstance(nodo, FUNCIONES):
        a = nodo.args
        out |= {x.arg for x in a.posonlyargs + a.args + a.kwonlyargs + [a.vararg, a.kwarg] if x}
    for n in _mismo_ambito(nodo):
        if isinstance(n, ast.Name) and isinstance(n.ctx, (ast.Store, ast.Del)):
            out.add(n.id)
        elif isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            out.add(n.name)
        elif isinstance(n, (ast.Import, ast.ImportFrom)):
            out |= {(x.asname or x.name).split(".")[0] for x in n.names}
        elif isinstance(n, ast.ExceptHandler) and n.name:
            out.add(n.name)
        elif isinstance(n, (ast.Global, ast.Nonlocal)):
            out |= set(n.names)
        elif isinstance(n, ast.comprehension):
            out |= {t.id for t in ast.walk(n.target) if isinstance(t, ast.Name)}
        elif isinstance(n, ast.NamedExpr):
            out.add(n.target.id)
    return out


def nombres_sin_definir(ruta):
    """[(línea, función, nombre)] que una función lee y no existe ni en ella, ni en las que la contienen, ni en el
    módulo, ni en Python. (Lo de una clase no se ve desde sus métodos, como en Python.)"""
    arbol = ast.parse(open(ruta, encoding="utf-8").read())
    fallos = set()

    def revisar(nodo, visibles):
        vis = visibles | _ligados(nodo)
        for n in _mismo_ambito(nodo):
            if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load) and n.id not in vis:
                fallos.add((n.lineno, getattr(nodo, "name", "lambda"), n.id))
        funciones(nodo, vis)

    def funciones(nodo, vis):
        for n in _mismo_ambito(nodo):
            if isinstance(n, FUNCIONES):
                revisar(n, vis)
            elif isinstance(n, ast.ClassDef):
                funciones(n, vis)

    funciones(arbol, _ligados(arbol) | set(dir(builtins)) | {"__file__"})
    return sorted(fallos)


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--carpeta", default=CARPETA)
    ap.add_argument("--solo", default="", help="casos separados por comas")
    ap.add_argument("--conservar", action="store_true", help="no borrar los archivos fabricados")
    args = ap.parse_args()
    solo = {x.strip() for x in args.solo.split(",") if x.strip()}
    tmp = tempfile.mkdtemp(prefix="pruebas_sincro_")
    resultados, t_total = [], time.time()
    try:
        for nombre, que, fallos in pruebas_sueltas(args.carpeta):
            if not solo or nombre in solo:
                resultados.append((nombre, que, fallos, 0.0))
        for nombre, que, fabricar, comprobaciones in casos(args.carpeta, tmp):
            if solo and nombre not in solo:
                continue
            t0 = time.time()
            try:
                fabricado = fabricar()          # (doblaje, original) u, opcional, opciones del motor
                dob, ori = fabricado[:2]
                extra = list(fabricado[2]) if len(fabricado) > 2 else []
                salida = os.path.join(tmp, nombre + "_SYNC.mka")
                r = subprocess.run([sys.executable, MOTOR, dob, ori, "-o", salida] + extra, capture_output=True,
                                   text=True, encoding="utf-8", errors="replace", cwd=tmp)
                informe = os.path.splitext(salida)[0] + "_informe.txt"
                texto = open(informe, encoding="utf-8").read() if os.path.exists(informe) else ""
                # el informe si lo hay (la salida repite lo mismo); de la salida, el error (con error no hay informe)
                res = leer(texto or r.stdout)
                res["error"] = res["error"] or next((x for x in r.stdout.splitlines() if x.startswith("ERROR")), None)
                if r.returncode and not res["error"]:
                    res["error"] = f"terminó con código {r.returncode}: {r.stderr.strip()[-300:]}"
                fallos = [x for comprobar in comprobaciones for x in comprobar(res)]
            except Exception as e:
                fallos = [f"no se pudo probar: {e}"]
            resultados.append((nombre, que, fallos, time.time() - t0))
            print(f"{'OK   ' if not fallos else 'FALLO'} {nombre:18s} {time.time() - t0:5.0f} s  {que}"
                  + "".join(f"\n        - {x}" for x in fallos), flush=True)
    finally:
        if args.conservar:
            print(f"Archivos de las pruebas: {tmp}")
        else:
            shutil.rmtree(tmp, ignore_errors=True)
    malos = [x for x in resultados if x[2]]
    for nombre, que, fallos, _ in resultados:
        if not _ and not fallos:
            print(f"OK    {nombre:18s}    -   {que}")
        elif not _:
            print(f"FALLO {nombre:18s}    -   {que}" + "".join(f"\n        - {x}" for x in fallos))
    print(f"\n{len(resultados) - len(malos)} de {len(resultados)} pruebas bien"
          + (f"; FALLAN: {', '.join(x[0] for x in malos)}" if malos else "") + f" ({time.time() - t_total:.0f} s)")
    sys.exit(1 if malos else 0)


if __name__ == "__main__":
    main()
