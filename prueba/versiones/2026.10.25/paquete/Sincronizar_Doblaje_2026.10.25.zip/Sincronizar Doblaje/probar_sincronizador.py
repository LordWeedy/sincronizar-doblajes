"""Batería de pruebas del sincronizador, con la respuesta conocida: cada caso se fabrica a partir de vídeos cortos (de
G:\\cosas varias\\Intros y cosas random), se sincroniza con sincronizar_doblaje.py tal cual y se compara su informe con
lo que tiene que salir. Se pasa después de cada cambio del programa: si algo que funcionaba se rompe, sale FALLO.
Pedido del usuario (21-10-2026): «la robustez para no romper lo que ya funcionaba».

Uso:  python probar_sincronizador.py [--carpeta CARPETA] [--solo caso1,caso2] [--conservar]
Tarda unos minutos (vídeos de 1-4 min en SD). Los archivos fabricados van a una carpeta temporal que se borra al final
(con --conservar se deja, para mirar un fallo). Termina con código 1 si algún caso falla."""
import argparse, ast, builtins, os, re, shutil, subprocess, sys, tempfile, time

VERSION = '2026.10.25'
AQUI = os.path.dirname(os.path.abspath(__file__))
MOTOR = os.path.join(AQUI, "sincronizar_doblaje.py")
CARPETA = r"G:\cosas varias\Intros y cosas random"
BASE = "TVE 1 (Continuidad).mp4"            # 3:41, 640x480, 25 fps
CORTO = "Cocodrilos al rescate.mp4"         # 1:00
COLOR = "Motorratones de Marte.mp4"         # 1:01, 1080p HEVC con datos de color mal puestos («trc:reserved»)
PAL = 1001 / 960


def ffmpeg(*args):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-v", "error", "-y", *args], capture_output=True, text=True,
                       errors="replace")
    if r.returncode:
        raise RuntimeError(f"ffmpeg: {r.stderr.strip()[-300:]}")


def tasa(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=sample_rate",
                        "-of", "csv=p=0", path], capture_output=True, text=True)
    return int(r.stdout.strip() or 48000)


def segundos(mmss):
    m, s = mmss.split(":")
    return int(m) * 60 + float(s)


def leer(texto):
    """Lo que interesa del informe (o de la salida, si no hay informe): error, inicio (ms, negativo si se recorta),
    cortes [(s, ms con signo)], velocidad, verificación, avisos."""
    r = dict(texto=texto, error=None, inicio=None, cortes=[], velocidad="", verif=None, avisos=[])
    en_avisos = False
    for linea in texto.splitlines():
        if linea.startswith("ERROR"):
            r["error"] = linea
        elif (m := re.match(r"^Inicio: (recortados|añadidos) (\d+) ms", linea)):
            r["inicio"] = int(m[2]) * (-1 if m[1] == "recortados" else 1)
        elif (m := re.match(r"^Corte\s+(\S+)\s+(inserta|recorta)\s+(\d+) ms", linea)):
            r["cortes"].append((segundos(m[1]), int(m[3]) * (-1 if m[2] == "recorta" else 1)))
        elif linea.startswith("Velocidad"):
            r["velocidad"] += linea + "\n"
        elif (m := re.match(r"^Verificación.*desviación típica ([\d.]+) ms, p90 ([\d.]+) ms", linea)):
            r["verif"] = (float(m[1]), float(m[2]))
        elif linea.startswith("Avisos:"):
            en_avisos = True
        elif en_avisos and linea.startswith("  - "):
            r["avisos"].append(linea[4:])
        else:
            en_avisos = False
    r["revisar"] = [a for a in r["avisos"] if a.startswith("[revisar] ")]
    return r


# --- comprobaciones (cada una devuelve una lista de fallos, vacía si todo va bien)
def sin_error(r):
    return [f"error: {r['error']}"] if r["error"] else []


def inicio(ms, tol):
    return lambda r: [] if r["inicio"] is not None and abs(r["inicio"] - ms) <= tol else \
        [f"inicio {r['inicio']} ms, se esperaba {ms:+d} ±{tol}"]


def cortes(n):
    return lambda r: [] if len(r["cortes"]) == n else [f"{len(r['cortes'])} cortes {r['cortes']}, se esperaban {n}"]


def un_corte(ms, tol, desde, hasta):
    def f(r):
        if len(r["cortes"]) != 1:
            return [f"{len(r['cortes'])} cortes {r['cortes']}, se esperaba uno de {ms:+d} ms"]
        t, d = r["cortes"][0]
        return ([] if abs(d - ms) <= tol else [f"el corte es de {d:+d} ms, se esperaba {ms:+d} ±{tol}"]) + \
               ([] if desde <= t <= hasta else [f"el corte va en {t:.2f} s, se esperaba entre {desde} y {hasta}"])
    return f


def contiene(texto, donde="texto"):
    return lambda r: [] if texto in r[donde] else [f"falta «{texto}»"]


def no_contiene(texto):
    return lambda r: [f"sale «{texto}»"] if texto in r["texto"] else []


def nada_que_revisar(r):
    return [f"avisa «{a}»" for a in r["revisar"]]


def verificacion(max_ms):
    return lambda r: [] if r["verif"] and r["verif"][0] <= max_ms else [f"verificación {r['verif']}, máx. {max_ms} ms"]


def error_con(texto):
    return lambda r: [] if r["error"] and texto in r["error"] else [f"se esperaba el error «{texto}», salió {r['error']}"]


# --- los casos: (nombre, qué comprueba, cómo se fabrica el doblaje -> (doblaje, original), comprobaciones)
def casos(c, tmp):
    base, corto, color = (os.path.join(c, x) for x in (BASE, CORTO, COLOR))
    sr = tasa(base)
    t = lambda nombre: os.path.join(tmp, nombre)

    def limpio():
        ffmpeg("-i", base, "-map", "0:a:0", "-ac", "2", "-c:a", "flac", t("limpio.mka"))
        return t("limpio.mka"), base

    def desfase():
        ffmpeg("-i", base, "-map", "0:a:0", "-ac", "2", "-af", "adelay=1500|1500", "-c:a", "flac", t("desfase.mka"))
        return t("desfase.mka"), base

    def sobra():
        ffmpeg("-i", base, "-filter_complex", "[0:a]atrim=0:60,asetpts=PTS-STARTPTS[a1];[0:a]atrim=58,"
               "asetpts=PTS-STARTPTS[a2];[a1][a2]concat=n=2:v=0:a=1[a]", "-map", "[a]", "-ac", "2", "-c:a", "flac",
               t("sobra.mka"))
        return t("sobra.mka"), base

    def falta():
        ffmpeg("-i", base, "-filter_complex", "[0:a]atrim=0:90,asetpts=PTS-STARTPTS[a1];[0:a]atrim=91,"
               "asetpts=PTS-STARTPTS[a2];[a1][a2]concat=n=2:v=0:a=1[a]", "-map", "[a]", "-ac", "2", "-c:a", "flac",
               t("falta.mka"))
        return t("falta.mka"), base

    def pal():
        ffmpeg("-i", base, "-map", "0:a:0", "-ac", "2", "-af", f"asetrate={sr}*1001/960,aresample={sr}", "-c:a", "flac",
               t("pal.mka"))
        return t("pal.mka"), base

    def pal_tono():
        ffmpeg("-i", base, "-map", "0:a:0", "-ac", "2", "-af", f"atempo={PAL:.10f}", "-c:a", "flac", t("pal_tono.mka"))
        return t("pal_tono.mka"), base

    def corto_pal():
        ffmpeg("-i", corto, "-map", "0:a:0", "-ac", "2", "-af",
               f"asetrate={tasa(corto)}*1001/960,aresample={tasa(corto)}", "-c:a", "flac", t("corto_pal.mka"))
        return t("corto_pal.mka"), corto

    def imagen_desplazada():
        ffmpeg("-itsoffset", "0.5", "-i", base, "-i", base, "-map", "0:v:0", "-map", "1:a:0", "-c", "copy",
               t("imagen_desplazada.mkv"))
        return t("imagen_desplazada.mkv"), base

    def con_imagen():
        ffmpeg("-i", base, "-f", "lavfi", "-i", "anoisesrc=d=230:c=pink:r=48000", "-filter_complex",
               "[0:v]trim=0:63,setpts=PTS-STARTPTS[v1];[0:v]trim=60,setpts=PTS-STARTPTS[v2];[v1][v2]concat=n=2:v=1:a=0[v]",
               "-map", "[v]", "-map", "1:a:0", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-c:a", "aac",
               "-shortest", t("con_imagen.mp4"))
        return t("con_imagen.mp4"), base

    def color_raro():
        ffmpeg("-i", color, "-f", "lavfi", "-i", "anoisesrc=d=70:c=pink:r=48000", "-map", "0:v:0", "-map", "1:a:0",
               "-c:v", "copy", "-c:a", "aac", "-shortest", t("color.mkv"))
        return t("color.mkv"), color

    def destellos():
        # 15 s de destellos al principio (imagen normal e invertida cada 0,16 s, como la cabecera de Becker), en la
        # RAW y en el doblaje; al doblaje le faltan sus primeros 1,5 s (hay que añadírselos) y su audio no se parece
        # (se mide con la imagen)
        ffmpeg("-i", base, "-vf", r"negate=enable='lt(mod(t\,0.32)\,0.16)*lt(t\,15)'", "-c:v", "libx264",
               "-preset", "ultrafast", "-crf", "23", "-c:a", "copy", t("destellos_raw.mp4"))
        ffmpeg("-ss", "1.5", "-i", t("destellos_raw.mp4"), "-f", "lavfi", "-i", "anoisesrc=d=230:c=pink:r=48000",
               "-map", "0:v:0", "-map", "1:a:0", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-c:a", "aac",
               "-shortest", t("destellos.mp4"))
        return t("destellos.mp4"), t("destellos_raw.mp4")

    def ruido():
        ffmpeg("-f", "lavfi", "-i", "anoisesrc=d=221:c=pink:r=48000", "-ac", "2", "-c:a", "flac", t("ruido.mka"))
        return t("ruido.mka"), base

    return [
        ("limpio", "el mismo audio: ni cortes ni nada que revisar", limpio,
         [sin_error, inicio(0, 5), cortes(0), verificacion(5), nada_que_revisar]),
        ("desfase", "1,5 s tarde en todo el episodio", desfase,
         [sin_error, inicio(-1500, 10), cortes(0), nada_que_revisar]),
        ("sobra_2s", "2 s repetidos en el 1:00: un recorte ahí", sobra,
         [sin_error, inicio(0, 10), un_corte(-2000, 40, 57, 63), nada_que_revisar]),
        ("falta_1s", "le falta 1 s en el 1:30: un relleno ahí", falta,
         [sin_error, inicio(0, 10), un_corte(1000, 40, 88, 92), nada_que_revisar]),
        ("pal", "PAL, el tono subido", pal,
         [sin_error, contiene("4,3 %", "velocidad"), inicio(0, 15), cortes(0), nada_que_revisar]),
        ("pal_tono", "PAL con el tono corregido (se mide con la envolvente)", pal_tono,
         [sin_error, contiene("4,3 %", "velocidad"), contiene("tono corregido", "velocidad"), inicio(0, 25), cortes(0)]),
        ("corto_pal", "un vídeo de 1 min a velocidad PAL", corto_pal,
         [sin_error, contiene("4,3 %", "velocidad"), cortes(0)]),
        ("imagen_desplazada", "la imagen del doblaje 0,5 s desplazada de su sonido: se sigue al sonido", imagen_desplazada,
         [sin_error, contiene("imagen va +500 ms"), inicio(0, 5), cortes(0), nada_que_revisar]),
        ("con_imagen", "sin audio que encaje: con la imagen, 3 s repetidos en el 1:03", con_imagen,
         [sin_error, contiene("Señal de análisis: vídeo"), un_corte(-3000, 80, 58, 68)]),
        ("color_raro", "un vídeo con los datos de color mal puestos se lee", color_raro,
         [sin_error, no_contiene("no se ha podido leer el vídeo"), contiene("Señal de análisis: vídeo")]),
        ("destellos", "15 s de destellos al principio: no cuentan, sin cortes ahí", destellos,
         [sin_error, contiene("Destellos"), inicio(1500, 60), cortes(0)]),
        ("ruido", "un audio sin relación: error, sin inventarse nada", ruido,
         [error_con("apenas hay coincidencias")]),
    ]


def pruebas_sueltas():
    """Comprobaciones de funciones sueltas del motor, sin fabricar nada: [(nombre, fallos)]."""
    sys.path.insert(0, AQUI)
    import numpy as np
    import sincronizar_doblaje as sd
    out = []
    muestra = ("frame:0    pts:0       pts_time:0\ntimecode=00:00:00:00\nlavfi.scd.mafd=0.000\nlavfi.scd.score=0.000\n"
               "frame:1    pts:42      pts_time:0.042\nlavfi.scd.mafd=0.632\nlavfi.scd.score=0.632\n")
    n = len(sd.RE_FOTOGRAMA.findall(muestra))
    out.append(("patron_fotogramas", "las líneas de ffmpeg con código de tiempo se leen",
                [] if n == 2 else [f"lee {n} fotogramas de 2"]))
    c = sd.ncc_curve(np.ones(100, np.float32), np.ones(50, np.float32))
    out.append(("ncc_corto", "buscar un trozo más largo que la señal no revienta",
                [] if c is None else ["no devuelve None"]))
    av = ["corte 1:00.00: sin silencio claro, conviene escucharlo",
          "1:00-2:00: 12 cambios de plano seguidos del doblaje no encajan con el original; puede estar descolocado"]
    clase = [sd.para_revisar(a) for a in av]
    out.append(("clases_de_aviso", "los avisos se separan en «revisar» y «escuchar»",
                [] if clase == [False, True] else [f"clasificados {clase}"]))
    # el nombre del audio sincronizado: el nuevo, y los de antes se siguen reconociendo (no se repite lo ya hecho)
    fallos = []
    with tempfile.TemporaryDirectory(prefix="nombres_") as d:
        dob = os.path.join(d, "Serie 1x01.avi")
        nuevo = sd.ruta_salida(dob, "es-ES")
        if os.path.basename(nuevo) != "Serie 1x01_[es-ES]_SYNC.mka":
            fallos.append(f"nombre nuevo: {os.path.basename(nuevo)}")
        for viejo, idioma in (("Serie 1x01_[spa]_SYNC_ENG.mka", "es-ES"), ("Serie 1x01_[spa]_SYNC_ENG.flac", "es-ES"),
                              ("Serie 1x01_[spa]_SYNC_ENG.mka", "es-419")):
            open(os.path.join(d, viejo), "w").close()
            r = os.path.basename(sd.ruta_salida(dob, idioma))
            if r != viejo:
                fallos.append(f"con {viejo} ya hecho ({idioma}) da {r}")
            os.remove(os.path.join(d, viejo))
        otra = os.path.join(d, "salida")
        os.makedirs(otra)
        open(os.path.join(otra, "Serie 1x01_[spa]_SYNC_ENG.mka"), "w").close()
        if os.path.dirname(sd.ruta_salida(dob, "es-ES", otra)) != otra or \
                not sd.ruta_salida(dob, "es-ES", otra).endswith("_SYNC_ENG.mka"):
            fallos.append("con carpeta de salida no encuentra el de antes")
    out.append(("nombre_salida", "«…_[es-ES]_SYNC.mka», y los «…_[spa]_SYNC_ENG» de antes se reconocen", fallos))
    # la pista de la RAW con la que se mide (y se rellena): por idioma y, si no decide, por el título (el DVDRemux de
    # Becker: ucraniano «MVO» primero, inglés «Original» después, doblaje .avi sin idioma)
    pista = lambda n, idioma="", titulo="": {"_n": n, "index": n, "codec_name": "ac3", "channels": 2,
                                            "tags": {k: v for k, v in (("language", idioma), ("title", titulo)) if v}}
    casos_pista = [  # (pistas de la RAW, pistas del doblaje, la que tiene que salir)
        ([pista(1, "ukr", "MVO | Comedy Central"), pista(2, "eng", "Original")], [pista(1)], 2),
        ([pista(1, "rus", "Закадровый"), pista(2, "eng")], [pista(1)], 2),
        ([pista(1, "eng", "Commentary"), pista(2, "eng", "English")], [pista(1)], 2),
        ([pista(1, "dan"), pista(2, "eng")], [pista(1, "spa"), pista(2, "eng")], 2),      # por idioma
        ([pista(1, "spa", "Castellano"), pista(2, "eng", "V.O.")], [pista(1)], 2),
        ([pista(1, "ukr"), pista(2, "eng")], [pista(1)], 1),                               # nada lo dice: la primera
        ([pista(1, "eng", "Original")], [pista(1)], 1),
    ]
    fallos, antes = [], sd.pistas_audio
    try:
        for ori, dob, bien in casos_pista:
            sd.pistas_audio = lambda ruta, ori=ori, dob=dob: ori if ruta == "raw" else dob
            sale = sd.elegir_original("raw", "doblaje", "spa", p=lambda *a: None)["_n"]
            if sale != bien:
                fallos.append(f"con {[sd.describir_pista(s) for s in ori]} elige la {sale}, no la {bien}")
    finally:
        sd.pistas_audio = antes
    out.append(("pista_original", "de la RAW se mide con la versión original, no con voces superpuestas", fallos))
    # un nombre sin definir solo revienta al pasar por esa línea (así se paró la tanda de «solo subtítulos» de la GUI
    # tras el primer episodio, 23-10-2026): se buscan en todos los archivos del programa sin ejecutarlos
    fallos = [f"{os.path.basename(f)}, línea {ln} ({func}): «{nombre}» no existe"
              for f in ("sincronizar_doblaje.py", "Sincronizar_Doblaje_Gui.py", "limpiar_vhs.py",
                        "probar_sincronizador.py", "actualizador.py", "actualizador_ventana.py")
              if os.path.exists(os.path.join(AQUI, f))
              for ln, func, nombre in nombres_sin_definir(os.path.join(AQUI, f))]
    out.append(("nombres_definidos", "ninguna función usa una variable que no existe", fallos))
    return out


FUNCIONES = (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)


def _mismo_ambito(nodo):
    """Los nodos que cuelgan de un ámbito sin entrar en las funciones y clases de dentro (que son otro ámbito)."""
    for h in ast.iter_child_nodes(nodo):
        yield h
        if not isinstance(h, FUNCIONES + (ast.ClassDef,)):
            yield from _mismo_ambito(h)


def _ligados(nodo):
    """Los nombres que crea un ámbito: argumentos, asignaciones, imports, def, except … as, global, for, :=."""
    out = set()
    if isinstance(nodo, FUNCIONES):
        a = nodo.args
        out |= {x.arg for x in a.posonlyargs + a.args + a.kwonlyargs + [a.vararg, a.kwarg] if x}
    for n in _mismo_ambito(nodo):
        if isinstance(n, ast.Name) and isinstance(n.ctx, (ast.Store, ast.Del)):
            out.add(n.id)
        elif isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            out.add(n.name)
        elif isinstance(n, (ast.Import, ast.ImportFrom)):
            out |= {(x.asname or x.name).split(".")[0] for x in n.names}
        elif isinstance(n, ast.ExceptHandler) and n.name:
            out.add(n.name)
        elif isinstance(n, (ast.Global, ast.Nonlocal)):
            out |= set(n.names)
        elif isinstance(n, ast.comprehension):
            out |= {t.id for t in ast.walk(n.target) if isinstance(t, ast.Name)}
        elif isinstance(n, ast.NamedExpr):
            out.add(n.target.id)
    return out


def nombres_sin_definir(ruta):
    """[(línea, función, nombre)] que una función lee y no existe ni en ella, ni en las que la contienen, ni en el
    módulo, ni en Python. (Lo de una clase no se ve desde sus métodos, como en Python.)"""
    arbol = ast.parse(open(ruta, encoding="utf-8").read())
    fallos = set()

    def revisar(nodo, visibles):
        vis = visibles | _ligados(nodo)
        for n in _mismo_ambito(nodo):
            if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load) and n.id not in vis:
                fallos.add((n.lineno, getattr(nodo, "name", "lambda"), n.id))
        funciones(nodo, vis)

    def funciones(nodo, vis):
        for n in _mismo_ambito(nodo):
            if isinstance(n, FUNCIONES):
                revisar(n, vis)
            elif isinstance(n, ast.ClassDef):
                funciones(n, vis)

    funciones(arbol, _ligados(arbol) | set(dir(builtins)) | {"__file__"})
    return sorted(fallos)


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--carpeta", default=CARPETA)
    ap.add_argument("--solo", default="", help="casos separados por comas")
    ap.add_argument("--conservar", action="store_true", help="no borrar los archivos fabricados")
    args = ap.parse_args()
    solo = {x.strip() for x in args.solo.split(",") if x.strip()}
    tmp = tempfile.mkdtemp(prefix="pruebas_sincro_")
    resultados, t_total = [], time.time()
    try:
        for nombre, que, fallos in pruebas_sueltas():
            if not solo or nombre in solo:
                resultados.append((nombre, que, fallos, 0.0))
        for nombre, que, fabricar, comprobaciones in casos(args.carpeta, tmp):
            if solo and nombre not in solo:
                continue
            t0 = time.time()
            try:
                dob, ori = fabricar()
                salida = os.path.join(tmp, nombre + "_SYNC.mka")
                r = subprocess.run([sys.executable, MOTOR, dob, ori, "-o", salida], capture_output=True, text=True,
                                   encoding="utf-8", errors="replace", cwd=tmp)
                informe = os.path.splitext(salida)[0] + "_informe.txt"
                texto = open(informe, encoding="utf-8").read() if os.path.exists(informe) else ""
                # el informe si lo hay (la salida repite lo mismo); de la salida, el error (con error no hay informe)
                res = leer(texto or r.stdout)
                res["error"] = res["error"] or next((x for x in r.stdout.splitlines() if x.startswith("ERROR")), None)
                if r.returncode and not res["error"]:
                    res["error"] = f"terminó con código {r.returncode}: {r.stderr.strip()[-300:]}"
                fallos = [x for comprobar in comprobaciones for x in comprobar(res)]
            except Exception as e:
                fallos = [f"no se pudo probar: {e}"]
            resultados.append((nombre, que, fallos, time.time() - t0))
            print(f"{'OK   ' if not fallos else 'FALLO'} {nombre:18s} {time.time() - t0:5.0f} s  {que}"
                  + "".join(f"\n        - {x}" for x in fallos), flush=True)
    finally:
        if args.conservar:
            print(f"Archivos de las pruebas: {tmp}")
        else:
            shutil.rmtree(tmp, ignore_errors=True)
    malos = [x for x in resultados if x[2]]
    for nombre, que, fallos, _ in resultados:
        if not _ and not fallos:
            print(f"OK    {nombre:18s}    -   {que}")
        elif not _:
            print(f"FALLO {nombre:18s}    -   {que}" + "".join(f"\n        - {x}" for x in fallos))
    print(f"\n{len(resultados) - len(malos)} de {len(resultados)} pruebas bien"
          + (f"; FALLAN: {', '.join(x[0] for x in malos)}" if malos else "") + f" ({time.time() - t_total:.0f} s)")
    sys.exit(1 if malos else 0)


if __name__ == "__main__":
    main()
