#!/usr/bin/env python3
"""
sincronizar_doblaje.py - Sincroniza una pista doblada con la pista original de un vídeo.

Se guía por la música y los efectos (canal lateral L-R, donde casi no hay diálogo),
no por el diálogo. Detecta dónde cambia el desfase (cortinillas en negro, cortes de
escena con frames de más o de menos), corta en el punto más silencioso del doblaje,
inserta relleno (silencio o el propio ruido de fondo del doblaje) o recorta y aplica el
retraso que tenga la pista original dentro de su MKV, de modo que el resultado se muxea
con delay 0. Si el doblaje va a otra velocidad (PAL, 23,976 frente a 24, el reloj de una
grabación), el doblaje no se estira: se adapta el original al muxear.

Si el doblaje se mezcló con otra música u otras risas y su audio apenas se parece al original,
y los dos archivos son vídeos, se mide con los cambios de plano (iguales en las dos versiones):
precisión de fotograma, y el audio queda como iba con su propio vídeo.

Uso:
  python sincronizar_doblaje.py DOBLAJE ORIGINAL [-o SALIDA] [--subs SUBTITULO.srt]
                                [--pista N] [--guia N] [--pista-original N] [--medir auto|audio|video]
  python sincronizar_doblaje.py --lote CARPETA_DOBLAJES CARPETA_ORIGINALES

ORIGINAL puede ser el MKV (se usa su versión original: si trae varias pistas, la del idioma que
también está en el doblaje, o la primera; y su retraso) o un audio suelto.
DOBLAJE puede ser un audio o un vídeo. Si trae varias pistas y una de ellas es la versión
original (ripeos duales; se sabe por el idioma o, si no lo tiene, por el parecido), se usa de
guía: se mide con ella, que coincide casi exactamente con el original, y los cortes se aplican
a la pista doblada (la del idioma del muxeado, si hay varias).
En modo lote se emparejan por episodio (6x05 <-> S06E05) y no se sobrescribe nada que exista.
Los subtítulos (el .srt suelto y los de texto que traiga el doblaje) pueden estar hechos para el
doblaje, para el original o para otra versión (otra velocidad, otro desfase, otro montaje): se
averigua comparando cuándo hay subtítulo con cuándo se habla en cada uno, se corrigen sus erratas
de tiempos (cifras mal tecleadas, duraciones imposibles, solapes, bloques desplazados) y se llevan
al resultado. En modo lote se usa el .srt que tenga el mismo nombre que el MKV. Se guardan junto
al audio sincronizado con su mismo nombre.
Con --limpiar (doblajes de VHS), la pista que se sincroniza se limpia al cargarla para montarla (limpiar_vhs.py, en
esta misma carpeta): continua, cortes de la captura, chasquidos, zumbido y siseo; los silencios de los cortes y el
relleno con el original ya se buscan en el audio limpio.
Requiere ffmpeg/ffprobe en el PATH y numpy + scipy.
"""
import argparse, atexit, base64, difflib, glob, json, os, re, shutil, subprocess, sys, tempfile, threading, time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction
import numpy as np
from scipy.ndimage import (binary_dilation, gaussian_filter1d, label, maximum_filter, median_filter,
                           uniform_filter1d, zoom)
from scipy.signal import butter, fftconvolve, resample_poly, sosfilt, sosfiltfilt
import limpiar_vhs

VERSION = '1.4.5'
AR = 8000            # frecuencia de análisis
MIN_JUMP = 0.060     # saltos menores se ignoran (~1,5 frames PAL)
# Las tareas independientes (los dos vídeos, las velocidades candidatas, las dos señales del seguimiento, los tramos
# de Viterbi) van en hilos: las correlaciones de numpy/scipy y los ffmpeg sueltan el GIL. Pedido del usuario
# (13-10-2026: usaba un 30-40 % de un i5 de 4 núcleos); medido en su equipo: 1,7-3 veces más rápido cada tarea y
# los mismos resultados.
HILOS = max(1, min(4, os.cpu_count() or 1))


def en_paralelo(funcion, elementos, hilos=HILOS):
    """[funcion(x) for x in elementos], repartido en hilos y en el mismo orden."""
    elementos = list(elementos)
    if hilos <= 1 or len(elementos) <= 1:
        return [funcion(x) for x in elementos]
    with ThreadPoolExecutor(min(hilos, len(elementos))) as ex:
        return list(ex.map(funcion, elementos))
MIN_SEG = 5.0        # segmentos más cortos se consideran ruido del detector
PEN = 3.0            # penalización Viterbi por cambiar de nivel
MAX_EXC = 60.0       # un desfase que se aparta más de MIN_EXC y vuelve al de antes en menos de
MIN_EXC = 0.5        # MAX_EXC segundos es música recolocada en la mezcla del doblaje, no montaje
FADE_S = 0.008
AUDIO_EXT = (".ac3", ".eac3", ".dts", ".flac", ".wav", ".mka", ".aac", ".m4a", ".mp3", ".thd")
# las lecturas con ffprobe/ffmpeg no abren ventana de consola cuando se lanza desde la GUI
SIN_VENTANA = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
# ffmpeg descargado por la GUI en la primera ejecución (carpeta "ffmpeg" junto a este script)
FFMPEG_LOCAL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ffmpeg")
if os.path.isfile(os.path.join(FFMPEG_LOCAL, "ffmpeg.exe")) and FFMPEG_LOCAL not in os.environ.get("PATH", ""):
    os.environ["PATH"] = FFMPEG_LOCAL + os.pathsep + os.environ.get("PATH", "")

if sys.stdout is not None:          # con pythonw (la GUI) no hay consola
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


# ---------------------------------------------------------------- E/S

def pistas_audio(path):
    """Pistas de audio del archivo; '_n' es su número entre las pistas de audio (1, 2...)."""
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                        "stream=index,codec_type,codec_name,start_time,channels,channel_layout,bit_rate,sample_rate"
                        ":stream_tags=language,title", "-of", "json", path],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", check=True, **SIN_VENTANA)
    st = [s for s in json.loads(r.stdout)["streams"] if s["codec_type"] == "audio"]
    for n, s in enumerate(st, 1):
        s["_n"] = n
    return st


def probe_audio(path, n=0):
    st = pistas_audio(path)
    if not st:
        raise RuntimeError(f"no hay audio en {path}")
    if n >= len(st):
        raise RuntimeError(f"{os.path.basename(path)} solo tiene {len(st)} pista(s) de audio")
    return st[n]


def titulo_pista(s):
    return ((s.get("tags") or {}).get("title") or "").strip()


def describir_pista(s):
    idioma, titulo = (s.get("tags") or {}).get("language"), titulo_pista(s)
    return (f"{s['_n']}: {s['codec_name']} {s.get('channels')}ch" + (f" [{idioma}]" if idioma else "")
            + (f" «{titulo}»" if titulo else ""))


# el título de una pista que dice que es la versión original, o que no lo es (doblaje, voces superpuestas —MVO, DVO,
# AVO, las de las ediciones rusas y ucranianas—, comentarios)
TITULO_ORIGINAL = re.compile(r"\boriginal\b|\bv\.?\s?o\b\.?|\bversi[oó]n original|\bo\.?v\b\.?", re.I)
TITULO_DOBLADA = re.compile(r"\b[mdapl]vo\b|voice.?over|\bdub|doblaj|\bcomment|comentari|multi.?voice|закадров|"
                            r"дубляж|дубльован|многоголос|багатоголос", re.I)


ISO_2 = {"es": "spa", "en": "eng", "ca": "cat", "gl": "glg", "eu": "baq", "fr": "fre", "de": "ger", "it": "ita",
         "pt": "por", "ja": "jpn", "da": "dan", "sv": "swe", "no": "nor", "nb": "nor", "nn": "nor", "fi": "fin",
         "nl": "dut", "pl": "pol", "ru": "rus", "zh": "chi", "ko": "kor", "cs": "cze", "hu": "hun", "el": "gre",
         "tr": "tur", "ar": "ara", "he": "heb", "hi": "hin", "ro": "rum", "uk": "ukr"}
ISO_B = {"fra": "fre", "deu": "ger", "nld": "dut", "zho": "chi", "ces": "cze", "ell": "gre", "fas": "per",
         "ron": "rum", "slk": "slo", "sqi": "alb", "hye": "arm", "eus": "baq", "mya": "bur", "kat": "geo",
         "isl": "ice", "mkd": "mac", "mri": "mao", "msa": "may", "bod": "tib", "cym": "wel", "nob": "nor", "nno": "nor"}


def idioma_valido(codigo):
    """La etiqueta de idioma tal cual si es un código de idioma («spa», «es-ES»); '' si no lo es: vacía, «und» o
    basura como «???» (así sale en ffprobe la de algunos MKV; La pelu del señor Pan 3x14: la versión original con
    «???» se tomaba por un doblaje en otro idioma, sin guía, y se intentaba sincronizar como otra pista doblada)."""
    c = (codigo or "").strip()
    return c if re.fullmatch(r"[A-Za-z]{2,3}([-_][A-Za-z0-9]{1,8})*", c) and c.lower() != "und" else ""


def idioma_iso(codigo):
    """Idioma normalizado a ISO 639-2/B ('' si no se sabe): es-ES -> spa, fra -> fre. «qaa» es la versión original
    en las emisiones de TDT."""
    c = idioma_valido(codigo).lower().replace("_", "-").split("-")[0]
    c = ISO_B.get(ISO_2.get(c, c), ISO_2.get(c, c))
    return c if len(c) == 3 and c not in ("und", "mul", "zxx", "mis") else ""


def elegir_original(en_path, es_path, objetivo, p=print):
    """La pista del original con la que se mide: si trae varias (una edición nórdica: danés, inglés, noruego,
    sueco), la del idioma que también está en el doblaje sin ser el del doblaje (su versión original); si no se
    puede saber, la primera. El danés de Barbie compartía la música y los efectos 5.1 con el castellano y el
    portugués del DVD: parecían la versión original y se sincronizó el inglés como si fuera el castellano."""
    st = pistas_audio(en_path)
    if not st:
        raise RuntimeError(f"no hay audio en {en_path}")
    if len(st) == 1:
        return st[0]
    del_doblaje = {idioma_iso(idioma_pista(s)) for s in pistas_audio(es_path)} - {""}
    doblada = lambda s: bool(TITULO_DOBLADA.search(titulo_pista(s)))
    for s in st:
        l = idioma_iso(idioma_pista(s))
        if l and l != objetivo and (l in del_doblaje or l == "qaa") and not doblada(s):
            p(f"Pista del original: {describir_pista(s)} (el doblaje también la trae en ese idioma: es la versión "
              f"original)")
            return s
    # sin idioma que lo decida, el título. El DVDRemux de Becker (23-10-2026) traía primero el ucraniano «MVO | Comedy
    # Central» y después el inglés «Original», y el .avi del doblaje sin idioma: se medía, y se rellenaba lo que le
    # faltara al castellano, con el ucraniano
    originales = [s for s in st if TITULO_ORIGINAL.search(titulo_pista(s)) and not doblada(s)]
    if len(originales) == 1:
        p(f"Pista del original: {describir_pista(originales[0])} (su título dice que es la versión original)")
        return originales[0]
    resto = [s for s in st if not doblada(s)]
    if resto and len(resto) < len(st):
        p(f"Pista del original: {describir_pista(resto[0])} (la primera que no dice ser un doblaje, voces "
          f"superpuestas o comentarios)")
        return resto[0]
    p(f"Pista del original: {describir_pista(st[0])} (la primera: ni por el idioma ni por el título se sabe cuál es la "
      f"versión original)")
    return st[0]


# los huecos en las marcas de tiempo del audio (paquetes perdidos en una grabación de TV) se leen como silencio, igual
# que al reproducir; sin esto el audio de después del hueco se adelantaba lo que durase el hueco
HUECOS = "aresample=async=1:min_hard_comp=0.01"


def cargar(path, st, sr, ch):
    cmd = ["ffmpeg", "-v", "error", "-i", path, "-map", f"0:{st['index']}", "-af", HUECOS,
           "-ac", str(ch), "-ar", str(sr), "-f", "f32le", "-"]
    raw = subprocess.run(cmd, capture_output=True, check=True, **SIN_VENTANA).stdout
    return np.frombuffer(raw, np.float32).reshape(-1, ch)


def cargar_sin_tono(path, st, sr, vel):
    """El original en mono a sr llevado a la velocidad vel sin cambiar el tono (atempo), o None si ffmpeg falla."""
    cmd = ["ffmpeg", "-v", "error", "-i", path, "-map", f"0:{st['index']}", "-af", f"{HUECOS},atempo={float(vel):.10f}",
           "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"]
    r = subprocess.run(cmd, capture_output=True, **SIN_VENTANA)
    return np.frombuffer(r.stdout, np.float32).copy() if r.returncode == 0 and len(r.stdout) else None


def cargar_pista(path, st, sr, ch, carpeta=None, desplazar=0):
    """Como cargar(), con `desplazar` muestras de silencio añadidas al principio (negativo: quitadas). Con carpeta,
    a un archivo temporal que se lee según hace falta (np.memmap), sin tenerlo entero en la RAM: Barbie (84 min,
    5.1) son 5,8 GB, el doble con el montaje, y con 7,4 GB de RAM Windows tiraba del disco y tardaba más de 30 min."""
    if carpeta is None:
        x = cargar(path, st, sr, ch)
        if desplazar > 0:
            return np.concatenate([np.zeros((desplazar, ch), np.float32), x])
        return x[-desplazar:] if desplazar < 0 else x
    ruta = tempfile.mktemp(suffix=".f32", dir=carpeta)
    proceso = subprocess.Popen(["ffmpeg", "-v", "error", "-i", path, "-map", f"0:{st['index']}", "-af", HUECOS,
                                "-ac", str(ch), "-ar", str(sr), "-f", "f32le", "-"], stdout=subprocess.PIPE,
                               stderr=subprocess.DEVNULL, **SIN_VENTANA)
    quitar = max(-desplazar, 0) * ch * 4
    with open(ruta, "wb") as f:
        f.write(bytes(max(desplazar, 0) * ch * 4))
        while raw := proceso.stdout.read(1 << 22):
            if quitar:
                q = min(quitar, len(raw))
                raw, quitar = raw[q:], quitar - q
            f.write(raw)
    if proceso.wait() != 0:
        raise RuntimeError(f"ffmpeg no ha podido leer el audio de {os.path.basename(path)}")
    n = os.path.getsize(ruta) // (4 * ch)
    return np.memmap(ruta, np.float32, "r", shape=(n, ch)) if n else np.zeros((0, ch), np.float32)


def lienzo(carpeta):
    """Dónde se monta el audio: en la RAM o, con carpeta, en un archivo temporal (np.memmap, empieza a ceros)."""
    if carpeta is None:
        return None
    return lambda forma: np.memmap(tempfile.mktemp(suffix=".f32", dir=carpeta), np.float32, "w+", shape=forma)


EN_DISCO = 1 << 30      # el audio a calidad completa que ocupe más que esto (1 GB) se trabaja en disco


def carpeta_temporal(bytes_):
    """Carpeta temporal para el audio que no conviene tener en la RAM (None si cabe). Se borra al acabar el proceso;
    las de un proceso cortado (Cancelar en la GUI), en la siguiente ejecución."""
    if bytes_ <= EN_DISCO:
        return None
    for vieja in glob.glob(os.path.join(tempfile.gettempdir(), "sincronizar_*")):
        try:                            # las de un proceso en marcha tienen archivos abiertos y no se dejan borrar
            if time.time() - os.path.getmtime(vieja) > 600:
                shutil.rmtree(vieja, ignore_errors=True)
        except OSError:
            pass
    carpeta = tempfile.mkdtemp(prefix="sincronizar_")
    atexit.register(shutil.rmtree, carpeta, True)
    return carpeta


def niveles_db(x, fs):
    """Nivel en dB de cada trama de 10 ms (la media de los canales), por bloques de 60 s (x puede estar en disco)."""
    F = fs // 100
    n = len(x) // F
    db = np.empty(n, np.float32)
    for i in range(0, n, 6000):
        j = min(i + 6000, n)
        m = np.asarray(x[i * F:j * F], np.float32).mean(1)
        db[i:j] = 20 * np.log10(np.sqrt((m.reshape(-1, F) ** 2).mean(1)) + 1e-7)
    return db


# Formato del audio doblado cuando hay que recodificarlo (cortes o rellenos; o sin ellos, si se pide): FLAC de serie
# (el usuario no quiere perder calidad); la GUI deja elegir. formato: (codificador de ffmpeg, nombre en el informe)
FORMATOS = {"flac": ("flac", "FLAC"), "aac": ("aac", "AAC"), "ac3": ("ac3", "AC3"), "opus": ("libopus", "Opus"),
            "eac3": ("eac3", "E-AC3")}
# kb/s automáticos si el doblaje no venía ya en ese formato (si venía, los suyos), según los canales
KBPS = {"ac3": {1: 96, 2: 224, 6: 320}, "eac3": {1: 96, 2: 224, 6: 640}, "aac": {1: 96, 2: 192, 6: 320},
        "opus": {1: 64, 2: 160, 6: 320}}
KBPS_MAX = {"ac3": 640, "eac3": 1536, "aac": 576, "opus": 510}
# Canales del audio doblado de salida (1.4.3; lo pidió un compañero del usuario): "igual" (los del doblaje, como
# siempre) o "2.0": un mono va igual a los dos lados y un 5.1 (o cualquier otro) se mezcla a estéreo (matriz_estereo)
CANALES_SALIDA = ("igual", "2.0")
# kb/s que se pueden pedir a mano en cada formato (la GUI ofrece estos; lo pedido se lleva al admitido más cercano)
KBPS_ELEGIBLES = {"aac": (96, 128, 160, 192, 224, 256, 320, 384, 448, 512),
                  "ac3": (96, 128, 160, 192, 224, 256, 320, 384, 448, 512, 576, 640),
                  "eac3": (96, 128, 160, 192, 224, 256, 320, 384, 448, 512, 576, 640, 768, 1024, 1536),
                  "opus": (64, 96, 128, 160, 192, 256, 320, 384, 448, 510)}
# disposiciones de canales por si «ffmpeg -layouts» no responde, y la de serie para cada número de canales
DISPOSICIONES_BASE = {"mono": ["FC"], "stereo": ["FL", "FR"], "2.1": ["FL", "FR", "LFE"], "3.0": ["FL", "FR", "FC"],
                      "4.0": ["FL", "FR", "FC", "BC"], "quad": ["FL", "FR", "BL", "BR"],
                      "5.0": ["FL", "FR", "FC", "BL", "BR"], "5.0(side)": ["FL", "FR", "FC", "SL", "SR"],
                      "5.1": ["FL", "FR", "FC", "LFE", "BL", "BR"], "5.1(side)": ["FL", "FR", "FC", "LFE", "SL", "SR"],
                      "6.1": ["FL", "FR", "FC", "LFE", "BC", "SL", "SR"],
                      "7.1": ["FL", "FR", "FC", "LFE", "BL", "BR", "SL", "SR"]}
DISPOSICION_DE_SERIE = {1: "mono", 2: "stereo", 3: "2.1", 4: "4.0", 5: "5.0", 6: "5.1", 7: "6.1", 8: "7.1"}
_DISPOSICIONES = None


def kbps_elegido(formato, kbps, ch, fs):
    """b/s para unos kb/s pedidos a mano (None si el formato no lleva kb/s): el valor de KBPS_ELEGIBLES más cercano sin
    pasar de lo que admite el codificador con esos canales (AAC: 6144 bits por canal y trama de 1024 muestras; Opus:
    256 kb/s por canal; y el tope de KBPS_MAX)."""
    opciones = KBPS_ELEGIBLES.get(formato)
    if not opciones or not kbps:
        return None
    tope = min({"aac": 6144 * fs / 1024 / 1000 * ch, "opus": 256 * ch}.get(formato, KBPS_MAX[formato]),
               KBPS_MAX[formato])
    validas = [k for k in opciones if k <= tope] or [opciones[0]]
    return 1000 * min(validas, key=lambda k: (abs(k - kbps), -k))


def nombres_canales(layout, ch):
    """Los canales de una disposición de ffmpeg («5.1(side)» -> FL FR FC LFE SL SR), leídas una vez de «ffmpeg
    -layouts». Si no se conoce o no cuadra con ch, la de serie para ese número de canales; None si tampoco."""
    global _DISPOSICIONES
    if _DISPOSICIONES is None:
        _DISPOSICIONES = dict(DISPOSICIONES_BASE)
        try:
            r = subprocess.run(["ffmpeg", "-hide_banner", "-layouts"], capture_output=True, text=True,
                               encoding="utf-8", errors="replace", **SIN_VENTANA)
            estandar = False
            for linea in r.stdout.splitlines():
                if linea.startswith("Standard channel layouts"):
                    estandar = True
                elif estandar and (m := re.match(r"^(\S+)\s+([A-Z0-9]+(?:\+[A-Z0-9]+)*)\s*$", linea)):
                    _DISPOSICIONES[m[1]] = m[2].split("+")
        except OSError:
            pass
    for nombre in (layout, DISPOSICION_DE_SERIE.get(ch)):
        n = _DISPOSICIONES.get(nombre)
        if n and len(n) == ch:
            return n
    return None


def matriz_estereo(nombres):
    """Matriz (canales x 2) para pasar a estéreo, como la mezcla habitual de un 5.1 a 2.0: los delanteros enteros a
    su lado; el central a -3 dB (0,707) en los dos; los de los lados, detrás o arriba a -3 dB en el suyo; los
    centrales de detrás o de arriba a -6 dB en los dos; el subgrave fuera. Un mono va entero a los dos lados."""
    if nombres == ["FC"]:
        return np.array([[1.0, 1.0]], np.float32)
    M = np.zeros((len(nombres), 2), np.float32)
    for i, n in enumerate(nombres):
        if n in ("LFE", "LFE2"):
            continue
        if n in ("FL", "DL", "BIL"):
            M[i, 0] = 1.0
        elif n in ("FR", "DR", "BIR"):
            M[i, 1] = 1.0
        elif n == "FC":
            M[i] = 0.7071
        elif n == "FLC":
            M[i, 0] = 0.7071
        elif n == "FRC":
            M[i, 1] = 0.7071
        elif n.endswith("C"):           # BC, TC, TFC, TBC, BFC
            M[i] = 0.5
        elif n.endswith("L"):
            M[i, 0] = 0.7071
        elif n.endswith("R"):
            M[i, 1] = 0.7071
    return M


def nombre_disposicion(layout, ch):
    """«1.0», «2.0», «5.1»... para el informe."""
    return {"mono": "1.0", "stereo": "2.0"}.get(layout, (layout or f"{ch} canales").replace("(side)", "")
                                                 .replace("(back)", ""))


def bitrate_salida(formato, st, path, canales="igual", kbps=None):
    """b/s con que se codifica el audio doblado (None en FLAC): los pedidos (kbps_elegido) o los automáticos
    (kbps_auto: los del doblaje si ya iba en ese formato y con los mismos canales; si no, los de la tabla para los
    canales de salida)."""
    ch, fs = int(st.get("channels") or 2), int(st.get("sample_rate") or 48000)
    ch_out = 2 if canales == "2.0" else ch
    if kbps and formato in KBPS_ELEGIBLES:
        return kbps_elegido(formato, kbps, ch_out, fs)
    mismo = st.get("codec_name") == formato and ch_out == ch
    br = bitrate_stream(path, st) if formato in KBPS and mismo else None
    return kbps_auto(formato, ch_out, st if mismo else None, br)


def motivo_recodificar(canales, kbps, formato, st, path):
    """Sin cortes el doblaje puede ir intacto, pero no si se han pedido canales o kb/s que no son los suyos: entonces
    se recodifica sin preguntar. El motivo, para el informe, o None."""
    ch = int(st.get("channels") or 2)
    if canales == "2.0" and ch != 2:
        return "pasado a 2.0 como se ha pedido"
    if kbps and formato in KBPS_ELEGIBLES:
        quiere = kbps_elegido(formato, kbps, ch, int(st.get("sample_rate") or 48000))
        tiene = bitrate_stream(path, st) if st.get("codec_name") == formato else None
        if not tiene or abs(tiene - quiere) > 0.05 * quiere:
            return f"en {texto_formato(formato, quiere)} como se ha pedido"
    return None


def kbps_auto(formato, ch, st=None, bitrate=None):
    """Bitrate (b/s) para recodificar en `formato` (None en FLAC): el del audio del doblaje si ya iba en ese
    formato (el que traiga ffprobe o el medido en `bitrate`, bitrate_stream); si no, uno alto para esos canales
    (KBPS; con otros canales, en proporción)."""
    if formato not in KBPS:
        return None
    if st and st.get("codec_name") == formato and (bitrate or st.get("bit_rate")):
        return int(bitrate or st["bit_rate"])
    t = KBPS[formato]
    return 1000 * (t[ch] if ch in t else min(round(t[2] / 2 * ch), KBPS_MAX[formato]))


def bitrate_stream(path, st, segundos=60.0):
    """b/s de una pista de audio: los que traiga ffprobe o, si el contenedor no los apunta (lo normal en MKV), los
    medidos copiando un minuto de la pista sin decodificarla (desde el segundo 30), entre lo que dure de verdad la
    copia. None si no se puede (archivo más corto): quien llame usa entonces la tabla por canales. Idea de Lowitle
    (su versión 1.0.1); ffmpeg 8 escribe «audio:472KiB» y no «kB», y con solo «kB» no se medía nunca."""
    if st.get("bit_rate"):
        return int(st["bit_rate"])
    r = subprocess.run(["ffmpeg", "-v", "info", "-ss", "30", "-t", str(segundos), "-i", path, "-map", f"0:{st['index']}",
                        "-c", "copy", "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", **SIN_VENTANA)
    err = r.stderr or ""
    m = re.search(r"audio:\s*(\d+)\s*(?:KiB|kB)", err)
    t = re.findall(r"time=(\d+):(\d\d):(\d\d(?:\.\d+)?)", err)    # el último es el de la copia entera
    seg = int(t[-1][0]) * 3600 + int(t[-1][1]) * 60 + float(t[-1][2]) if t else 0.0
    return round(int(m.group(1)) * 1024 * 8 / seg) if m and seg > 1 else None


def texto_formato(formato, bitrate=None):
    """«FLAC», «AC3 224 kb/s»..."""
    return FORMATOS.get(formato, (formato, formato.upper()))[1] + (f" {round(bitrate / 1000)} kb/s" if bitrate else "")


_MKA_APUNTA_AC3 = None


def mka_apunta_retardo_ac3():
    """¿El ffmpeg de este equipo apunta en el .mka las 256 muestras de relleno del codificador AC3 (CodecDelay), que
    se descuentan al reproducir, también tras mkvmerge? FFmpeg 8 sí (medido 08-10-2026: el AC3 compensado a mano salía
    5,3 ms adelantado); los de antes no. Se mira una vez codificando 0,2 s de silencio."""
    global _MKA_APUNTA_AC3
    if _MKA_APUNTA_AC3 is None:
        _MKA_APUNTA_AC3 = False
        with tempfile.TemporaryDirectory(prefix="ac3_") as d:
            ruta = os.path.join(d, "p.mka")
            r = subprocess.run(["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-t", "0.2",
                                "-c:a", "ac3", ruta], capture_output=True, **SIN_VENTANA)
            if r.returncode == 0:
                r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=initial_padding", "-of",
                                    "csv=p=0", ruta], capture_output=True, text=True, **SIN_VENTANA)
                _MKA_APUNTA_AC3 = r.stdout.strip() not in ("", "0", "N/A")
    return _MKA_APUNTA_AC3


def codificar(out, fs, layout, codec, bitrate, path, canales="igual"):
    """out (muestras float32) a `path` en el formato `codec` (clave de FORMATOS) y `bitrate` b/s.
    canales: "2.0" pasa a estéreo lo que no lo sea (matriz_estereo); si la mezcla saturaría, se baja todo lo justo
    (como la limpieza). Devuelve el cambio de canales para el informe («5.1 → 2.0», con los dB si se ha bajado) o ""."""
    M, g, cambio = None, 1.0, ""
    if canales == "2.0" and out.shape[1] != 2:
        nombres = nombres_canales(layout, out.shape[1])
        if nombres is None:
            raise RuntimeError(f"no se sabe pasar a 2.0 un audio de {out.shape[1]} canales ({layout})")
        M = matriz_estereo(nombres)
        pico = 0.0
        for i in range(0, len(out), fs * 60):
            blk = np.asarray(out[i:i + fs * 60], np.float32) @ M
            pico = max(pico, float(np.abs(blk).max(initial=0.0)))
        if pico > 0.999:
            g = 0.989 / pico
        cambio = (f"{nombre_disposicion(layout, out.shape[1])} → 2.0"
                  + (f", bajado {-20 * np.log10(g):.1f} dB para que no sature".replace(".", ",") if g < 1 else ""))
        layout = "stereo"
    ch = 2 if M is not None else out.shape[1]
    # el codificador AC3 de ffmpeg adelanta 256 muestras de relleno (5,3 ms a 48 kHz): si el .mka no lo apunta para
    # descontarlo al reproducir (ffmpeg antiguo, o un .ac3 suelto), se compensan quitándolas del principio y
    # manteniendo la duración. El AAC (1024) y el Opus (312) sí lo apuntan, también tras mkvmerge (medido: 0,00 ms)
    quitar = min(256, len(out)) if codec in ("ac3", "eac3") and not (
        path.lower().endswith(".mka") and mka_apunta_retardo_ac3()) else 0
    cmd = ["ffmpeg", "-v", "error", "-n", "-f", "f32le", "-ar", str(fs), "-ch_layout", layout,
           "-i", "-", "-c:a", FORMATOS.get(codec, (codec,))[0]]
    if codec == "flac":
        # siempre a 16 bits con tramado (decisión del usuario, como sus FLAC de Vegas): a 24 los 8 bits de más solo
        # guardaban el ruido de redondeo del decodificador y el archivo pesaba más del doble (1284 frente a 563 kb/s)
        cmd += ["-af", "aresample=osf=s16:dither_method=triangular"]
    elif codec in ("aac", "opus") and "(side)" in layout:
        # el 5.1 de un AC3 de DVD sale como «5.1(side)»: libopus no lo admite (no escribe nada) y el AAC lo deja sin
        # disposición; es el mismo 5.1 con los traseros con otro nombre
        cmd += ["-af", "channelmap=channel_layout=" + layout.replace("(side)", "")]
    if bitrate and codec != "flac":
        cmd += ["-b:a", str(bitrate)]
    cmd.append(path)
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    step = fs * 10
    try:
        for i in range(quitar, len(out), step):
            blk = np.asarray(out[i:i + step], np.float32)
            if M is not None:
                blk = (blk @ M) * np.float32(g)
            p.stdin.write(np.ascontiguousarray(blk, np.float32).tobytes())
        p.stdin.write(bytes(quitar * ch * 4))
        p.stdin.close()
    except OSError:
        # ffmpeg se cerró antes de tiempo (no pudo crear el archivo: un nombre con «?» salía como «Broken pipe»)
        p.wait()
        raise RuntimeError(f"ffmpeg se ha cerrado al codificar {os.path.basename(path)} (código {p.returncode}): "
                           "¿se puede crear ese archivo ahí?")
    if p.wait() != 0:
        raise RuntimeError("ffmpeg falló al codificar")
    return cambio


# ---------------------------------------------------------------- medida

def ncc_curve(a, b):
    """Correlación normalizada de a (corto) a lo largo de b (largo), o None. (Si a es más largo que b, None: antes
    fftconvolve los intercambiaba y fallaba con «operands could not be broadcast», con un vídeo de un minuto.)"""
    if len(a) > len(b) or not len(a):
        return None
    a = a - a.mean()
    na = np.linalg.norm(a)
    if na < 1e-6:
        return None
    c = fftconvolve(b, a[::-1], mode="valid")
    b2 = np.concatenate([[0.0], np.cumsum(b.astype(np.float64) ** 2)])
    nb = np.sqrt(np.maximum(b2[len(a):] - b2[:-len(a)], 1e-12))
    return c / (na * nb)


def desfase_inicial(a, b, primero=False):
    """Se busca en ±30 s; si ahí no hay nada claro (p. ej. al doblaje le falta una intro de un minuto), en
    ±150 s; y si tampoco, en todo el original, aceptando solo una coincidencia clara (una película con
    minutos de más o de menos al principio: Indomables, +188 s).
    primero: en ±30 s, el de la primera ventana que encaje con claridad, no el de la mejor (para empezar el
    seguimiento, que va desde el principio: con trozos que faltan el desfase cambia a lo largo del episodio; La pelu
    del señor Pan 3x18: +1,01 s en el minuto 1 y +28,4 s en el 10, y empezando en +28,4 los primeros 78 s se quedaban
    con coincidencias casuales de la música). Sin él, la mejor (para saber cuánto se parece una pista)."""
    best = desfase_inicial_en(a, b, 30, primero)
    if best[1] >= 0.4:
        return best
    best = max(best, desfase_inicial_en(a, b, 150, True), key=lambda x: x[1])
    if best[1] >= 0.4:
        return best
    lejos = desfase_lejos(a, b)
    return lejos if lejos[1] >= 0.5 else best


# ---------------------------------------------------------------- velocidad (fps distintos)
# Si el doblaje va a otra velocidad (PAL: 25 fps frente a 23,976, un 4,3 % más rápido y más agudo), no se toca
# el castellano: se adapta el original a él (el vídeo sin recodificar, sus audios recodificados, sus subtítulos
# y capítulos reescalados). vel = velocidad del doblaje / la del original.
VELOCIDADES = [Fraction(1001, 960), Fraction(25, 24), Fraction(1001, 1000),        # 25/23,976 25/24 24/23,976
               Fraction(960, 1001), Fraction(24, 25), Fraction(1000, 1001)]
NOMBRES_FPS = {Fraction(1001, 960): ("25", "23,976"), Fraction(25, 24): ("25", "24"),
               Fraction(1001, 1000): ("24", "23,976")}


def texto_velocidad(vel, es_path=None, en_path=None):
    """«el doblaje va un 4,3 % más rápido (25 fps frente a 23,976)»: los fps de los vídeos si se conocen;
    si no, la conversión habitual a la que corresponde."""
    lado = "rápido" if vel > 1 else "lento"
    nombres = NOMBRES_FPS.get(vel) or tuple(reversed(NOMBRES_FPS.get(1 / vel, ())))
    if not nombres:         # no es un cambio de fps: el reloj de una grabación, una deriva medida, una cinta
        d = abs(float(vel) - 1)
        if d >= 0.001:
            return f"el doblaje va un {d * 100:.2f} % más {lado} que el original".replace(".", ",")
        return (f"el doblaje va {d * 1e6:.0f} ppm más {lado} que el original "
                f"({d * 3600:.2f} s por hora)".replace(".", ","))
    a, b = nombres
    fa, fb = (fps_video(es_path), fps_video(en_path)) if es_path and en_path else (None, None)
    num = lambda f: f"{float(f):.3f}".rstrip("0").rstrip(".").replace(".", ",")
    fps = f"{num(fa)} fps frente a {num(fb)}" if fa and fb and fa != fb else f"como {a} fps frente a {b}"
    pct = f"{abs(float(vel) - 1) * 100:.1f}".replace(".", ",")
    return f"el doblaje va un {pct} % más {lado} que el original ({fps})"


def velocidad_final(medida, en_len):
    """La proporción con la que se adapta el original a una velocidad medida (Fraction): una conversión habitual
    (o la misma velocidad) si encaja; si no, la fracción más sencilla que deje menos de DERIVA_REPARTIR_MS / 2 en
    todo el episodio. Con denominador <= 192000 el audio del original se acelera sin redondeos (filtro_velocidad)."""
    tol = DERIVA_REPARTIR_MS / 2000 / en_len
    for v in [Fraction(1)] + VELOCIDADES:
        if abs(float(medida / v) - 1) <= tol:
            return v
    for n in (1000, 3000, 10000, 30000, 100000, 192000):
        v = medida.limit_denominator(n)
        if abs(float(medida / v) - 1) <= tol:
            break
    return v


def filtro_velocidad(sr, vel, salida):
    """Filtro de ffmpeg que acelera una pista de sr Hz en la proporción vel (más rápida y más aguda, como una
    emisión PAL) y la deja a `salida` Hz. asetrate solo admite frecuencias enteras (con una expresión redondea: con
    1000/1001 se desvía 1,35 ms en 18 min): se pasa antes por un múltiplo del denominador y la proporción es exacta."""
    v = Fraction(vel)
    m = -(-sr // v.denominator)
    r1, r2 = v.denominator * m, v.numerator * m
    return (f"asetrate={r2}" if r1 == sr else f"aresample={r1},asetrate={r2}") + f",aresample={salida}"


def acelerar(x, vel):
    """El original a la velocidad del doblaje (vel > 1: el doblaje va más rápido y el original se acorta)."""
    if vel == 1:
        return x
    if max(vel.numerator, vel.denominator) <= 50000:
        return resample_poly(x, vel.denominator, vel.numerator, axis=0).astype(np.float32)
    # números grandes (una velocidad afinada): el filtro de resample_poly sería enorme; interpolación lineal por
    # bloques, que para medir y verificar basta
    v, n = float(vel), int(len(x) / float(vel))
    out = np.empty((n,) + x.shape[1:], np.float32)
    for i in range(0, n, 1 << 20):
        t = np.arange(i, min(i + (1 << 20), n)) * v
        j = np.minimum(t.astype(np.int64), len(x) - 2)
        w = (t - j).astype(np.float32).reshape((-1,) + (1,) * (x.ndim - 1))
        out[i:i + len(t)] = x[j] * (1 - w) + x[j + 1] * w
    return out


def fps_video(path):
    """Fotogramas por segundo del vídeo (Fraction) o None."""
    idx = pista_video(path)
    if idx is None:
        return None
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", str(idx), "-show_entries",
                        "stream=r_frame_rate,avg_frame_rate", "-of", "json", path],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", **SIN_VENTANA)
    s = (json.loads(r.stdout or "{}").get("streams") or [{}])[0]
    for clave in ("avg_frame_rate", "r_frame_rate"):
        try:
            f = Fraction(s.get(clave) or "0")
            if 5 < f < 200:
                return f
        except (ValueError, ZeroDivisionError):
            pass
    return None


def fps_variable(path):
    """¿El vídeo va a fotogramas por segundo variables? Se mira cuánto dura cada fotograma en tres trozos de 20 s
    (al 10, 50 y 90 %): con fps constante todos duran lo mismo (±1,5 ms: las marcas de un MKV van en ms)."""
    idx = pista_video(path)
    if idx is None:
        return False
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", **SIN_VENTANA)
    try:
        dur = float(r.stdout.strip())
    except ValueError:
        return False
    d = []
    for f in (0.1, 0.5, 0.9):
        r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", str(idx), "-read_intervals",
                            f"{dur * f:.1f}%+20", "-show_entries", "packet=pts_time", "-of", "csv=p=0", path],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", **SIN_VENTANA)
        pts = sorted(float(x) for x in r.stdout.split() if x.replace(".", "", 1).replace("-", "", 1).isdigit())
        d += [b - a for a, b in zip(pts, pts[1:]) if b > a]
    if len(d) < 20:
        return False
    d = np.array(d)
    return bool(np.mean(np.abs(d - np.median(d)) > 0.0015) > 0.02)


def velocidad_por_fps(es_path, en_path):
    """La conversión habitual que corresponde a los fps de los dos vídeos (una pista, no una certeza: con
    telecine el fps cambia y la velocidad no), o None."""
    a, b = fps_video(es_path), fps_video(en_path)
    if not a or not b:
        return None
    return next((v for v in VELOCIDADES if abs(float(a / b) / float(v) - 1) < 0.0005), None)


def detectar_velocidad(es_path, en_path, en8, pistas, p, audios=None):
    """Velocidad del doblaje frente al original (Fraction; 1 = la misma), probada con el audio: con la
    velocidad buena alguna pista del doblaje (la versión original si la trae, o la música) encaja con
    claridad. Devuelve (vel, audio a 8 kHz de cada pista del doblaje, que se reutiliza, si solo encaja con la
    envolvente: el doblaje tiene el tono corregido y se mide con envolvente_ar).
    audios: esas pistas ya leídas (se leen a la vez que el original), o None para leerlas aquí."""
    if audios is None:
        audios = [cargar(es_path, s, AR, 2) for s in pistas]
    # se prueba con la mezcla (L+R) y con el lateral (L-R): el diálogo va en el centro y en el lateral queda la música
    # y los efectos comunes; con voces distintas la mezcla puede no parecerse nada (Buzz Lightyear 1x48: mezcla
    # 0,04-0,38, lateral 0,44-0,78 a 25/23,976; solo con la mezcla no se encontraba la velocidad, se medía todo con la
    # imagen y salía peor: cabecera mal y escalones de 80 ms). En una pista mono el lateral es cero y no cuenta.
    senales = (lambda x: x[:, 0] + x[:, 1], lambda x: x[:, 0] - x[:, 1])
    pares = [(f(en8), [f(a) for a in audios]) for f in senales]        # (original, pistas del doblaje)
    v = buscar_velocidad(es_path, en_path, en8, audios, pares, p)
    if v is None:
        # nada encaja: quizá uno de los dos archivos tiene los canales izquierdo y derecho cambiados, y su lateral
        # va con el signo al revés (la correlación sale negativa y no se ve). Se prueba la lateral invertida
        # (solo la misma velocidad y las conversiones habituales: con las dos rarezas a la vez no merece la pena el
        # barrido, que es lo lento cuando el audio no se parece nada y se acaba midiendo con la imagen)
        v = buscar_velocidad(es_path, en_path, en8, audios, [(pares[1][0], [-m for m in pares[1][1]])], p, True)
    v, con_envolvente = v or (Fraction(1), False)
    return v, audios, con_envolvente


def encaja_velocidad(med, base, env=False):
    """med: (mejor parecido de una ventana que confirma otra en el mismo desfase, ventanas en el mismo desfase, su
    parecido medio, ventanas que hay, mejor ventana suelta), de buscar_velocidad. Encaja con claridad (una ventana >=
    0,5, confirmada por otra) o, aunque el parecido sea flojo, varias ventanas separadas por minutos caen en el mismo
    desfase (una casualidad no se repite así) muy por encima de la velocidad descartada (base). Con la envolvente,
    ENV_CONFIRMADA y ENV_MEDIA (sin relación ya da 0,2-0,3)."""
    c, n, media, total, _ = med
    uno, varias, margen = (ENV_CONFIRMADA, ENV_MEDIA, 0.15) if env else (0.5, 0.2, 0.1)
    return (c >= uno and c >= base + 0.2) or (n >= min(3, max(2, total)) and media >= varias
                                              and media >= base + margen)


def base_envolvente(m1e):
    """Lo que encaja con la envolvente a la misma velocidad, para que otra velocidad tenga que superarlo: lo que
    confirman al menos dos ventanas (nunca menos que dos audios sin relación). Una ventana suelta no: la envolvente
    tolera un 4 % de velocidad de más en un trozo de música lenta (La pelu del señor Pan 3x21: una ventana a 0,80 a la
    misma velocidad, sin otra que la confirmara, impedía la PAL, con 0,94-0,98 confirmadas)."""
    c, n, media, _, _ = m1e
    return max(c, media if n >= 2 else 0.0, ENV_RUIDO)


def buscar_velocidad(es_path, en_path, en8, audios, pares, p, invertida=False):
    """La velocidad con la que alguna señal del doblaje encaja con la del original (pares: [(original, [pistas del
    doblaje])]) y si solo encaja con la envolvente: (vel, con_envolvente), o None. invertida: con la lateral
    invertida (el informe lo dice y no se hace el barrido)."""
    nota = " con la lateral invertida (canales cambiados en uno de los archivos)" if invertida else ""
    tono = ("; el doblaje tiene el tono corregido (su onda no coincide con la del original): se mide con la "
            "envolvente del sonido")
    env_doblaje = {}

    def medida(v, env=False):
        """(mejor parecido de una ventana que confirma otra en el mismo desfase, ventanas que dan el mismo desfase, su
        parecido medio, ventanas que hay, mejor parecido de una ventana suelta). env: con las envolventes (solo hacen
        falta los primeros minutos: las ventanas van hasta el minuto 10, ±150 s)."""
        if env:
            if not env_doblaje:
                env_doblaje.update({(i, j): envolvente_ar(m[:800 * AR]) for i, (_, ds) in enumerate(pares)
                                    for j, m in enumerate(ds)})
            vs = []
            for i, (e, ds) in enumerate(pares):
                eo = envolvente_ar(acelerar(e[:int(950 * AR * float(v))], v))
                vs += [ventanas_desfase(env_doblaje[(i, j)], eo, 150) for j in range(len(ds))]
        else:
            # (del original solo hace falta hasta el minuto 13: las ventanas van del 1 al 10, ±150 s; acelerarlo
            # entero, por cada velocidad, era lo mismo pero mucho más lento y con más memoria en una película)
            vs = [ventanas_desfase(m, acelerar(e[:int(800 * AR * float(v))], v), 150) for e, ds in pares for m in ds]
        suelta = max((c for w in vs for _, c in w), default=-1.0)
        # una ventana sola no basta si hay más con las que comprobarla: otra en el mismo desfase (±50 ms), aunque sea
        # floja (>= 0,2); con dos ventanas o menos (un archivo corto), como antes
        confirmada = max((c for w in vs for j, (L, c) in enumerate(w)
                          if len(w) < 3 or any(i != j and abs(L2 - L) <= 0.05 and c2 >= 0.2
                                               for i, (L2, c2) in enumerate(w))), default=-1.0)
        n, media, _ = max((coherencia(w) for w in vs), default=(0, 0.0, 0.0))
        return confirmada, n, media, max((len(w) for w in vs), default=0), suelta

    vale = encaja_velocidad
    m1 = medida(Fraction(1))
    base = m1[4]
    if vale(m1, -1.0):
        if invertida:
            p(f"Velocidad: la misma que el original{nota}")
        return Fraction(1), False
    pista = velocidad_por_fps(es_path, en_path) or Fraction(len(en8), max(1, max(len(a) for a in audios)))
    mejor = None
    candidatas = sorted(VELOCIDADES, key=lambda v: abs(v - pista))
    for v, med in zip(candidatas, en_paralelo(medida, candidatas)):       # todas a la vez; se elige igual que antes
        if vale(med, base) and (mejor is None or (med[1], med[2]) > (mejor[1][1], mejor[1][2])):
            mejor = (v, med, False)
    if mejor is None and not invertida:
        # ¿la onda no puede coincidir? Con la envolvente: a la misma velocidad (un audio estirado y vuelto a encoger sin
        # cambiar el tono: «Voy a brillar», DVD-Rip a 23,976 de un DVD PAL, 0,02-0,06 con la onda y 0,89/0,43/0,63 con
        # la envolvente en el mismo desfase; antes se buscaba cualquier velocidad, lo más lento, para nada) y en las dos
        # conversiones más cercanas a la de los fps, solo de PAL (con 24/23,976, un 0,1 %, la onda ya encajaría)
        m1e = medida(Fraction(1), True)
        if vale(m1e, ENV_RUIDO, True):
            mejor = (Fraction(1), m1e, True)
        for v in candidatas[:2]:
            if abs(v - 1) > 0.01:
                med = medida(v, True)
                if vale(med, base_envolvente(m1e), True) and (mejor is None or (med[1], med[2]) >
                                                               (mejor[1][1], mejor[1][2])):
                    mejor = (v, med, True)
    if mejor:
        v, (c, n, media, _, _), con_envolvente = mejor
        if v == 1:
            p(f"Velocidad: la misma que el original; el audio del doblaje está procesado (su onda no coincide con la "
              f"del original: estirado sin cambiar el tono): se mide con la envolvente del sonido (confianza "
              f"{max(c, media):.2f}, {n} ventanas en el mismo desfase){nota}")
            return v, True
        p(f"Velocidad: {texto_velocidad(v, es_path, en_path)}; se adapta el original al doblaje "
          f"(confianza {max(c, media):.2f}, {n} ventanas en el mismo desfase; a la misma velocidad {base:.2f}){nota}"
          + (tono if con_envolvente else ""))
        return v, con_envolvente
    if invertida:
        return None
    # ninguna conversión de fps habitual: cualquier velocidad entre -10 % y +10 % (una captura de VHS lenta, una
    # transferencia de cinta, un audio de 44,1 kHz tomado por 48: +8,8 %), con los golpes de sonido; solo si alguna
    # pista encaja con claridad
    p("Velocidad: no encaja a la misma velocidad ni con ninguna conversión habitual; se busca cualquier otra...")
    candidatos = sorted(((e, m) for e, ds in pares for m in ds), key=lambda x: -desfase_inicial_en(x[1], x[0], 30)[1])
    for e, m in candidatos:
        e_en = envolvente(e)
        t_en = np.arange(len(e_en), dtype=np.float64)
        y_de_v = lambda v: np.interp(np.arange(int(len(e_en) / v)) * v, t_en, e_en).astype(np.float32)
        v, conf = barrido_velocidad(envolvente(m), y_de_v)
        if conf < 0.5:
            continue
        v = Fraction(v).limit_denominator(20000)
        med = medida(v)
        c = max(med[0], med[2])
        if vale(med, base):
            p(f"Velocidad: {texto_velocidad(v, es_path, en_path)} (no es una conversión de fps habitual); se adapta "
              f"el original al doblaje (confianza {c:.2f}, a la misma velocidad {base:.2f}){nota}")
            return v, False
    return None


FR_ENV = 100            # tramas por segundo de las señales de golpes (envolvente del audio, cambios de plano)


def envolvente(x, fs=AR):
    """Los golpes del sonido (subidas de energía en tramas de 10 ms), para medir la velocidad sin que importe el tono
    ni el desfase: con una velocidad distinta el audio cambia de tono y la correlación directa ya no encaja."""
    F = fs // FR_ENV
    e = np.log10(np.sqrt((x[:len(x) // F * F].astype(np.float64).reshape(-1, F) ** 2).mean(1)) + 1e-4)
    d = gaussian_filter1d(np.maximum(np.diff(e, prepend=e[:1]), 0), 1.0)
    return (d - d.mean()).astype(np.float32)


# Doblajes con el tono corregido (muchos DVD PAL: acelerados al 4 % sin que suba el tono). Su onda no coincide nunca con
# la del original, ni remuestreado (el tono, un 4 % más alto) ni acelerado sin cambiar el tono (dos aceleraciones
# hechas por separado no dan la misma onda): un doblaje fabricado así a partir del propio original daba 0,02-0,29, y el
# latino del Kojak 4x24, 0,02-0,06, así que la velocidad no salía y se medía con la imagen. La envolvente de amplitud no
# depende de la fase ni del tono: el fabricado, 0,98-0,99 (al ±10 ms); el 4x24, 0,63/0,92/0,34 en el mismo desfase;
# dos audios sin relación, 0,2-0,3 (por eso sus umbrales son más altos)
ENV_CONFIRMADA, ENV_MEDIA = 0.6, 0.45
ENV_MISMO_SONIDO = 0.9     # parecido mediano de la envolvente para medir con ella si también hay imagen
ENV_RUIDO = 0.25           # lo que da la envolvente de dos audios sin relación (para la misma velocidad)


ENV_ESTABLE = 0.010        # s: p90 de lo que cambia el desfase de una ventana de seguir() a la siguiente


def envolvente_precisa(pts):
    """¿La medida con la envolvente (pts de seguir) es de fiar sin la imagen? Si el parecido mediano es el del mismo
    sonido o, aunque sea algo menor, casi todo encaja (GUIA_SIN_IMAGEN) y el desfase apenas se mueve de una ventana a
    la siguiente (con otra mezcla el diálogo lo hace saltar: Kojak 4x24 latino, saltos de ida y vuelta de 0,18 s)."""
    if not len(pts):
        return False
    s = pts[:, 2]
    if float(np.median(s)) >= ENV_MISMO_SONIDO:
        return True
    buenos = pts[s > 0.4]
    if float((s > 0.4).mean()) < GUIA_SIN_IMAGEN or len(buenos) < 30:
        return False
    return float(np.percentile(np.abs(np.diff(buenos[:, 1])), 90)) <= ENV_ESTABLE


def envolvente_ar(x, trozo=60 * AR, margen=4 * AR):
    """La envolvente de amplitud del sonido (300-3000 Hz, suavizada a 25 Hz, sin su media de ±1 s), a AR, por trozos
    (la memoria de un episodio en float64 no hace falta)."""
    banda = butter(4, (300, 3000), btype="band", fs=AR, output="sos")
    suave = butter(2, 25, fs=AR, output="sos")
    x = np.asarray(x)
    out = np.empty(len(x), np.float32)
    for i in range(0, len(x), trozo):
        a, b = max(0, i - margen), min(len(x), i + trozo + margen)
        e = sosfiltfilt(suave, np.abs(sosfiltfilt(banda, np.asarray(x[a:b], np.float64))))
        n = min(trozo, len(x) - i)
        out[i:i + n] = e[i - a:i - a + n]
    return out - uniform_filter1d(out, 2 * AR)


def barrido_velocidad(x, y_de_v, lo=0.90, hi=1.10):
    """Velocidad v (doblaje / original) entre lo y hi con la que las señales de golpes encajan mejor: x la del
    doblaje; y_de_v(v) la del original acelerada v. Tres trozos del doblaje (al 15, 45 y 75 %) se buscan en todo el
    original: de 60 s cada 400 ppm y luego de 240 s cada 40 ppm alrededor de la mejor. Devuelve (v, confianza).
    Con la guía de Crash Canyon a 0,3 %, 1 %, -1,7 %, 2,5 %, PAL, 6 % y -7 %: error de 0 a 27 ppm, confianza 0,96."""
    n = len(x)

    def puntua(v, seg):
        y = y_de_v(v)
        cs = []
        for f in (0.15, 0.45, 0.75):
            t = x[int(f * n):int(f * n) + seg]
            c = ncc_curve(t, y) if len(t) == seg and len(y) > seg else None
            cs.append(float(c.max()) if c is not None and len(c) else 0.0)
        return float(np.mean(cs))

    seg = min(60 * FR_ENV, n // 4)
    vs = np.arange(lo, hi, 4e-4)
    v0 = float(vs[int(np.argmax([puntua(v, seg) for v in vs]))])
    seg = min(240 * FR_ENV, n // 4)
    vs = np.arange(v0 - 6e-4, v0 + 6e-4, 4e-5)
    sc = [puntua(v, seg) for v in vs]
    return float(vs[int(np.argmax(sc))]), max(sc)


def desfase_lejos(a, b, bloque=600):
    """El desfase de la primera ventana del doblaje que encaje con claridad en cualquier punto del original.
    Se recorre el original por bloques de `bloque` s para no gastar memoria con películas enteras."""
    W, B = 20 * AR, bloque * AR
    for t0 in (60, 180, 300, 420, 600):
        s = t0 * AR
        if s + W > len(a):
            break
        mejor = (0.0, -1.0)
        for lo in range(0, max(1, len(b) - W), B):
            trozo = b[lo:lo + B + W]
            if len(trozo) <= W:
                continue
            c = ncc_curve(a[s:s + W], trozo)
            if c is None or not len(c):
                continue
            i = int(np.argmax(c))
            if c[i] > mejor[1]:
                mejor = ((lo + i - s) / AR, float(c[i]))
        if mejor[1] >= 0.5:
            return mejor
    return (0.0, -1.0)


def ventanas_desfase(a, b, rango):
    """(desfase, parecido) de ventanas de 20 s del doblaje al minuto 1, 3, 5, 7 y 10, buscadas en ±rango s. Si no caben
    al menos tres (un doblaje de menos de 5:20), cinco repartidas por todo él, de hasta 20 s: en uno de un minuto no
    cabía ninguna y no se encontraba otra velocidad («apenas hay coincidencias»)."""
    dur = len(a) / AR
    fijas = [(t0, 20.0) for t0 in (60, 180, 300, 420, 600) if t0 + 20 <= dur]
    if len(fijas) < 3:
        w = min(20.0, dur / 6)
        fijas = [(dur * f - w / 2, w) for f in (0.15, 0.32, 0.5, 0.68, 0.85)] if w >= 2 else []
    out = []
    for t0, w in fijas:
        s, W, S = int(t0 * AR), int(w * AR), rango * AR
        lo, hi = max(0, s - S), min(len(b), s + W + S)
        c = ncc_curve(a[s:s + W], b[lo:hi])
        if c is None:
            continue
        i = int(np.argmax(c))
        out.append(((lo + i - s) / AR, float(c[i])))
    return out


def coherencia(ventanas):
    """(cuántas ventanas dan el mismo desfase, ±50 ms, su parecido medio, ese desfase)."""
    mejor = (0, 0.0, 0.0)
    for L, _ in ventanas:
        g = [(x, c) for x, c in ventanas if abs(x - L) <= 0.05]
        mejor = max(mejor, (len(g), float(np.mean([c for _, c in g])), float(np.median([x for x, _ in g]))))
    return mejor


def desfase_inicial_en(a, b, rango, primero=False):
    """primero: el de la primera ventana que encaje con claridad (en ±150 s puede haber más de un
    desfase en el episodio, y el seguimiento empieza por el principio)."""
    best = (0.0, -1.0)
    for t0 in (60, 180, 300, 420, 600):
        s, W, S = t0 * AR, 20 * AR, rango * AR
        if s + W > len(a):
            break
        lo, hi = max(0, s - S), min(len(b), s + W + S)
        c = ncc_curve(a[s:s + W], b[lo:hi])
        if c is None:
            continue
        i = int(np.argmax(c))
        if primero and c[i] >= 0.5:
            return (lo + i - s) / AR, float(c[i])
        if c[i] > best[1]:
            best = ((lo + i - s) / AR, float(c[i]))
    return best


def seguir(a, b, lag0):
    """Desfase (t_orig - t_doblaje) en ventanas de 6 s cada segundo. Si lleva 30 s sin coincidencias
    (p. ej. al doblaje le falta un trozo grande), cada 5 s se busca también en ±150 s."""
    WIN, STEP, SEARCH = 6 * AR, AR, 8 * AR

    def medir(t, lag, sr):
        lo, hi = int(max(0, t + lag - sr)), int(min(len(b), t + lag + WIN + sr))
        if hi - lo < WIN:
            return None
        c = ncc_curve(a[t:t + WIN], b[lo:hi])
        if c is None:
            return None
        i = int(np.argmax(c))
        return lo + i - t, float(c[i])

    pts, lag, ult = [], lag0 * AR, 0
    for t in range(0, len(a) - WIN, STEP):
        m = None
        if t - ult >= 30 * AR and (t // STEP) % 5 == 0:
            m = medir(t, lag, 150 * AR)
            if m and m[1] < 0.6:        # lejos solo vale una coincidencia clara
                m = None
        if m is None:
            m = medir(t, lag, SEARCH if t - ult < 90 * AR else 3 * SEARCH)
        if m is None:
            continue
        L, s = m
        if s > 0.4:
            lag, ult = L, t
        pts.append(((t + WIN / 2) / AR, L / AR, s))
    return np.array(pts)


def buscar_niveles(pts, k, tol=0.020, min_n=5, span=60.0):
    """Desfases que aparecen de forma coherente (>= min_n puntos en menos de `span` s)."""
    g = pts[pts[:, 2] > 0.25]
    t, v, s = g[:, 0], g[:, 1] - k * g[:, 0], g[:, 2]
    niveles = []
    for j in np.argsort(-s):
        c = float(np.median(v[np.abs(v - v[j]) < tol]))
        if any(abs(c - L) < MIN_JUMP for L in niveles):
            continue
        tt = np.sort(t[np.abs(v - c) < tol])
        if len(tt) and (np.searchsorted(tt, tt + span) - np.arange(len(tt))).max() >= min_n:
            niveles.append(c)
    return sorted(niveles)


def viterbi(a, b, niveles, k, fs=AR, win=2.0):
    """Asigna cada tramo de 0,25 s del doblaje a un nivel de desfase (a, b muestreadas a fs)."""
    HOP, WIN, FINE = fs // 4, int(win * fs), int(0.045 * fs)
    n = (len(a) - WIN) // HOP
    S = len(niveles)
    E = np.zeros((n, S))

    def bloque(f0):             # filas f0..f0+255 (cada fila es independiente: van por bloques en hilos)
        for f in range(f0, min(f0 + 256, n)):
            t = f * HOP
            x = a[t:t + WIN]
            if np.linalg.norm(x) < 1e-3:
                continue
            for j, L in enumerate(niveles):
                c = int(round(t + (L + k * t / fs) * fs))
                lo, hi = c - FINE, c + FINE + WIN
                if lo < 0 or hi > len(b):
                    continue
                cc = ncc_curve(x, b[lo:hi])
                if cc is not None:
                    E[f, j] = cc.max()

    en_paralelo(bloque, range(0, n, 256))
    dp, bp = E[0].copy(), np.zeros((n, S), np.int32)
    idx = np.arange(S)
    for f in range(1, n):
        j = int(np.argmax(dp)); sw = dp[j] - PEN > dp
        bp[f] = np.where(sw, j, idx)
        dp = np.where(sw, dp[j] - PEN, dp) + E[f]
    path = np.zeros(n, int); path[-1] = int(np.argmax(dp))
    for f in range(n - 1, 0, -1):
        path[f - 1] = bp[f, path[f]]
    # segmentos: [inicio, fin, nivel] en tiempo del doblaje
    tc = (np.arange(n) * HOP + WIN / 2) / fs
    segs, s0 = [], 0
    for f in range(1, n + 1):
        if f == n or path[f] != path[f - 1]:
            segs.append([tc[s0] - HOP / fs / 2, tc[f - 1] + HOP / fs / 2, niveles[path[s0]]])
            s0 = f
    # absorber segmentos diminutos en el vecino de nivel más parecido
    while len(segs) > 1:
        dur = [s[1] - s[0] for s in segs]
        i = int(np.argmin(dur))
        if dur[i] >= MIN_SEG:
            break
        cand = [j for j in (i - 1, i + 1) if 0 <= j < len(segs)]
        j = min(cand, key=lambda j: abs(segs[j][2] - segs[i][2]))
        segs[j][0], segs[j][1] = min(segs[j][0], segs[i][0]), max(segs[j][1], segs[i][1])
        del segs[i]
        segs = fusionar_iguales(segs)
    return segs


def fusionar_iguales(segs):
    """Une tramos seguidos con casi el mismo desfase. Se compara cada tramo con su vecino, no con
    el primero de la cadena: -298, -259, -354 ms es un salto real de 95 ms, no un único nivel."""
    out = [segs[0]]
    for prev, s in zip(segs, segs[1:]):
        if abs(s[2] - prev[2]) < MIN_JUMP:
            out[-1][1] = s[1]
        else:
            out.append(s)
    return out


def excursiones(segs):
    """Tramos cortos cuyo desfase se aparta mucho y luego vuelve al de antes. Un cambio de montaje
    deja el desfase cambiado; esto es música o efectos colocados en otro sitio en la mezcla del
    doblaje, con el diálogo en su sitio, así que no hay que cortar."""
    return [(s[0], s[1], s[2] - p[2], s[2]) for p, s, n in zip(segs, segs[1:], segs[2:])
            if s[1] - s[0] < MAX_EXC and abs(p[2] - n[2]) < MIN_EXC / 2
            and min(abs(s[2] - p[2]), abs(s[2] - n[2])) > MIN_EXC]


def ajustar(pts, segs, k0, margen=3.5):
    """Deriva común k y desfase de cada segmento (mediana ponderada de puntos fiables). Se descartan
    los puntos a menos de `margen` s de un cambio: su ventana de medida lo abarca."""
    fronteras = np.array([s[1] for s in segs[:-1]])
    t, l, s = pts[:, 0], pts[:, 1], pts[:, 2]
    sid = np.searchsorted(fronteras, t)
    lejos = np.ones(len(t), bool) if not len(fronteras) else \
        np.min(np.abs(t[:, None] - fronteras[None, :]), 1) > margen
    nivel = np.array([segs[i][2] for i in sid])
    ok = lejos & (s > 0.2) & (np.abs(l - k0 * t - nivel) < 0.06)
    # deriva: regresión robusta con una ordenada por segmento
    fit = ok & (s > 0.35)
    k = k0
    if fit.sum() >= 30:
        cols = sorted(set(sid[fit]))
        X = np.zeros((fit.sum(), len(cols) + 1))
        X[np.arange(fit.sum()), [cols.index(i) for i in sid[fit]]] = 1
        X[:, -1] = t[fit]; y = l[fit]
        keep = np.ones(len(y), bool)
        for _ in range(4):
            coef, *_ = np.linalg.lstsq(X[keep], y[keep], rcond=None)
            r = np.abs(y - X @ coef)
            keep = r < max(3 * np.median(r[keep]), 0.004)
        k = float(coef[-1])
    L = []
    for i, sg in enumerate(segs):
        m = ok & (sid == i)
        if m.sum() < 3:
            L.append(sg[2]); continue
        v, w = l[m] - k * t[m], s[m]
        o = np.argsort(v); cw = np.cumsum(w[o])
        L.append(float(v[o][np.searchsorted(cw, cw[-1] / 2)]))
    return k, L, [int((ok & (sid == i)).sum()) for i in range(len(segs))]


def afinar_salto(a, b, t, La, Lb, k):
    """Instante exacto (s del doblaje) en que el desfase pasa de La a Lb cerca de t: primero con
    ventanas de 0,25 s en ±3 s y luego con ventanas de 0,1 s cada 5 ms en ±0,3 s."""
    t = salto_en(a, b, t, La, Lb, k, 3.0, 0.25, 0.02)
    return salto_fino(a, b, t, La, Lb, k)


def salto_fino(a, b, t, La, Lb, k, span=0.3):
    """Ajuste fino: tramas de 2,5 ms con el error normalizado frente a las dos predicciones, para que
    cada trama pese lo mismo suene fuerte o flojo (la correlación de ventanas largas se va hacia la
    parte fuerte). El desfase exacto de cada lado se mide con 1 s justo antes y justo después."""
    N, i0, i1 = int(0.0025 * AR), int((t - span) * AR), int((t + span) * AR)
    if i0 - AR < 0 or i1 + AR > len(a):
        return t

    def desfase(L, x0):                 # desfase entero (muestras) que mejor encaja en a[x0:x0+AR]
        c = int(round((L + k * t) * AR))
        if x0 + c - 10 < 0 or x0 + c + AR + 10 > len(b):
            return c
        cc = ncc_curve(a[x0:x0 + AR], b[x0 + c - 10:x0 + c + AR + 10])
        return c - 10 + int(np.argmax(cc)) if cc is not None else c

    cA, cB = desfase(La, i0 - AR), desfase(Lb, i1)
    if min(i0 + cA, i0 + cB) < 0 or max(i1 + cA, i1 + cB) > len(b):
        return t
    n = (i1 - i0) // N
    x = a[i0:i0 + n * N].reshape(n, N)

    def error(c):
        p_ = b[i0 + c:i0 + c + n * N].reshape(n, N)
        return ((x - p_) ** 2).sum(1) / ((x ** 2).sum(1) + (p_ ** 2).sum(1) + 1e-9)

    eA, eB = error(cA), error(cB)
    coste = np.concatenate([[0.0], np.cumsum(eA)]) + eB.sum() - np.concatenate([[0.0], np.cumsum(eB)])
    return (i0 + int(np.argmin(coste)) * N) / AR


def salto_en(a, b, t, La, Lb, k, span, win, hop):
    """Ventanas de `win` s cada `hop` s en t±span, comparadas con el original en los dos desfases;
    el salto es el punto que deja más coincidencias con La antes y con Lb después."""
    W, H, F = int(win * AR), int(hop * AR), int(0.01 * AR)
    x0s = list(range(max(0, int((t - span) * AR)), min(len(a) - W, int((t + span) * AR)), H))
    if len(x0s) < 3:
        return t
    E = np.zeros((len(x0s), 2))
    for n, x0 in enumerate(x0s):
        x = a[x0:x0 + W]
        if np.linalg.norm(x) < 1e-3:
            continue
        for j, L in enumerate((La, Lb)):
            c0 = int(round(x0 + (L + k * x0 / AR) * AR))
            if c0 - F >= 0 and c0 + W + F <= len(b):
                cc = ncc_curve(x, b[c0 - F:c0 + W + F])
                E[n, j] = cc.max() if cc is not None else 0.0
    antes = np.concatenate([[0.0], np.cumsum(E[:, 0])])
    despues = E[:, 1].sum() - np.concatenate([[0.0], np.cumsum(E[:, 1])])
    s = int(np.argmax(antes + despues))
    return (x0s[min(s, len(x0s) - 1)] + W / 2) / AR if 0 < s < len(x0s) else t


def empalme_video(cambios, k, La, Lb, lo, hi):
    """El cambio de plano del doblaje donde empalma lo que tenía con lo que falta: encaja en el
    original con los dos desfases. None si no lo hay."""
    tm, sm, te, se = cambios
    ref = te[se > 0.15]
    for t in (lo, hi):
        p_ = np.array([t * (1 + k) + La, t * (1 + k) + Lb])
        i = np.clip(np.searchsorted(ref, p_), 1, len(ref) - 1)
        if (np.minimum(np.abs(ref[i] - p_), np.abs(ref[i - 1] - p_)) < 2.5 * SIGMA).all():
            return t
    return None


def corte_exacto(db, t):
    """Un corte justo en t (sin buscar silencio), para empalmar con el audio original."""
    i = int(t * 100)
    return dict(c=t, q0=t, q1=t, suelo=float(db[max(i - 5, 0):i + 5].min()) if len(db) else -120.0, exacto=True)


def punto_silencio(db, t, span=2.5):
    """Centro del tramo silencioso más largo cerca de t (db: frames de 10 ms)."""
    a0, b0 = max(0, int((t - span) * 100)), min(len(db), int((t + span) * 100))
    w = np.convolve(db[a0:b0], np.ones(5) / 5, mode="same")
    q = w < w.min() + 6
    best, cur, bs = (0, 0), 0, 0
    for i, v in enumerate(q):
        cur = cur + 1 if v else 0
        if cur == 1:
            bs = i
        if cur > best[1] - best[0]:
            best = (bs, i + 1)
    return dict(c=(a0 + (best[0] + best[1]) / 2) / 100, q0=(a0 + best[0]) / 100,
                q1=(a0 + best[1]) / 100, suelo=float(w.min()))


# ---------------------------------------------------------------- montaje

def relleno(es, fs, n, q0, q1, fade, ramp):
    """n muestras del ruido de fondo del propio doblaje (o silencio si allí hay silencio digital)."""
    src = es[int(q0 * fs):int(q1 * fs)]
    out = np.zeros((n, es.shape[1]), np.float32)
    if len(src) < 4 * fade or np.abs(src).max() < 1e-4:
        return out
    pos = 0
    while pos < n:
        piece = src[:min(len(src), n - pos + fade)].copy()
        piece[:fade] *= ramp; piece[-fade:] *= ramp[::-1]
        e = min(n, pos + len(piece)); out[pos:e] += piece[:e - pos]
        pos += len(piece) - fade
    return out


def limites(cortes, L, dur):
    """Inicio y fin (tiempo del doblaje) de cada tramo que se conserva. Lo que sobra del doblaje en un corte se
    quita centrado en el silencio; si no cabe (el tramo de antes es más corto que medio recorte), se quita desde
    el principio de ese tramo, sin salirse del doblaje. (Antes un tramo podía quedar vacío o con el final
    negativo: película de 2 h con recortes de minutos -> «operands could not be broadcast».)"""
    starts, ends = [0.0], []
    for i, c in enumerate(cortes):
        quitar = max(0.0, L[i] - L[i + 1])
        e = min(max(c["c"] - quitar / 2, starts[-1]), dur)
        ends.append(e); starts.append(min(e + quitar, dur))
    ends.append(max(dur, starts[-1]))
    return starts, ends


def recorte_desplazado(c, L, i, ends):
    """El recorte del corte i no ha podido ir centrado en él."""
    return abs(ends[i] - (c["c"] - max(0.0, L[i] - L[i + 1]) / 2)) > 1e-6


def fundido(x, ramp, entrada=True, salida=True):
    """Fundidos de entrada y salida; en un trozo más corto que dos fundidos, se acortan (y en uno vacío, nada)."""
    n = min(len(ramp), len(x) // 2)
    if n:
        r = ramp if n == len(ramp) else np.linspace(0, 1, n, dtype=np.float32)[:, None]
        if entrada:
            x[:n] *= r
        if salida:
            x[-n:] *= r[::-1]
    return x


MIN_ORIGINAL = 1.0     # huecos de al menos esto se rellenan con el audio original (si se pide)
REF_NIVEL = 10.0       # segundos a cada lado de un hueco para igualar el volumen del original
# Con la velocidad variable (VHS) los cortes que insertan caen donde no hay silencio de verdad (el soplido de la cinta
# y música debajo) y relleno() repetía el principio de lo más flojo de alrededor: la cola de la palabra anterior o un
# golpe de música, que se oía repetido (Ninja Sasuke 2: 16 de los 20 puntos que anotó el compañero del usuario; los
# cortes que recortan, ni uno). Ahí el hueco se tapa alargando el doblaje de alrededor (alargar), sin repetir nada
MEDIO_PUENTE = 2.5     # s del doblaje a cada lado del corte que se alargan para tapar el hueco


def alargar(x, fs, extra):
    """x (muestras, canales) con `extra` muestras más (o menos, si es negativo), sin repetir ni cortar nada ni cambiar
    el tono (WSOLA: marcos de 40 ms con ventana de Hann a media superposición; cada uno se toma del sitio que mejor
    continúa el anterior, ±10 ms). El tiempo de más (o de menos) va sobre todo a las pausas: los tramos de 10 ms a menos
    de 6 dB del más flojo pesan 100 veces más que el resto, y ninguno pasa del cuádruple ni se queda en menos de un
    cuarto. Empieza y acaba como x."""
    n_in, ch = len(x), x.shape[1]
    n_out = n_in + extra
    N = int(0.04 * fs) // 2 * 2
    Hs, T, H = N // 2, int(0.01 * fs), int(0.01 * fs)
    if extra == 0 or n_in < 4 * N or n_out < 4 * N:
        return np.asarray(x[:n_out], np.float32)
    m = np.asarray(x, np.float32).mean(1)
    nb = n_in // H
    lv = 10 * np.log10((m[:nb * H].reshape(nb, H) ** 2).mean(1) + 1e-12)
    w = np.where(lv < lv.min() + 6, 1.0, 0.01)
    ex = extra * w / w.sum()
    s = 1 if extra > 0 else -1           # más (alargar) o menos (acortar)
    tope = 3 * H if extra > 0 else -0.75 * H        # nadie pasa del cuádruple ni se queda en menos de un cuarto
    for _ in range(8):                   # lo que pase del tope, a los demás
        sobra = (s * np.clip(s * (ex - tope), 0, None)).sum()
        libres = s * (ex - tope) < 0
        if abs(sobra) <= 1e-6 or not libres.any():
            break
        ex = tope + s * np.minimum(s * (ex - tope), 0)
        ex[libres] += sobra * w[libres] / w[libres].sum()
    t_in = np.append(np.arange(nb + 1) * H, n_in).astype(float)
    t_out = t_in + np.append(np.concatenate([[0.0], np.cumsum(ex)]), extra)
    if (np.diff(t_out) <= 0).any():      # no cabía: por igual en todo
        t_out = t_in * (n_out / n_in)
    ventana = np.hanning(N + 1)[:-1].astype(np.float32)
    y = np.zeros((n_out + N, ch), np.float32)
    norma = np.zeros(n_out + N, np.float32)
    m4 = m[::4]                          # la búsqueda, a un cuarto de muestras (sobra para alinear marcos)
    previo = 0
    for o in range(0, n_out - N, Hs):
        nominal = int(round(np.interp(o + N / 2, t_out, t_in) - N / 2))
        p_ = min(max(nominal, 0), n_in - N)
        if o and previo + Hs + N <= n_in:
            lo, hi = max(0, nominal - T) // 4, min(n_in - N, nominal + T) // 4
            ref = m4[(previo + Hs) // 4:(previo + Hs + N) // 4]
            if hi > lo and len(ref):
                c = np.correlate(m4[lo:hi + len(ref)], ref, mode="valid")
                p_ = min(max(4 * (lo + int(np.argmax(c))), 0), n_in - N)
                a0, a1 = max(p_ - 4, 0), min(p_ + 4, n_in - N)     # y a muestra entera, ±4 alrededor
                c = np.correlate(m[a0:a1 + N], m[previo + Hs:previo + Hs + N], mode="valid")
                p_ = a0 + int(np.argmax(c))
        y[o:o + N] += x[p_:p_ + N] * ventana[:, None]
        norma[o:o + N] += ventana
        previo = p_
    y[n_out - N:n_out] += x[n_in - N:] * ventana[:, None]       # el último marco, justo al final
    norma[n_out - N:n_out] += ventana
    return y[:n_out] / np.maximum(norma[:n_out], 1e-3)[:, None]


SILENCIO_DB = -50.0     # por debajo, un trozo cuenta como vacío aunque no sea plano (audio ya limpio de ruido)


def sin_contenido(es, fs, limite=20.0):
    """(s del principio, s del final) del doblaje sin contenido: ruido de la cinta o silencio, plano (Ninja Sasuke 2:
    2,8 s de soplido a -25 dB antes del episodio y 1,8 s después, que tapaban el final de la cabecera y el principio del
    ending del original). Plano: en trozos de 100 ms, a menos de 2 dB de su nivel (la mediana del 2.º al 6.º: el primero
    puede ser más flojo, como el -30 dB con que empieza el de Ninja Sasuke) o por debajo de SILENCIO_DB (ese soplido,
    limpio de ruido y continua, queda a -55/-63 dB y ya no es plano), y luego, en medio segundo, una subida de 6 dB
    o más. Se dejan 0,1 s antes de lo que suena. Como mucho `limite` s; 0 si no hay nada."""
    n = int(limite * fs)

    def plano(x):
        if len(x) < fs:
            return 0.0
        db = niveles_db(x, fs)
        db = np.maximum(db[:len(db) // 10 * 10].reshape(-1, 10).mean(1), -60.0)       # trozos de 100 ms
        base = float(np.median(db[1:6]))
        k = 1 if db[0] <= base + 2.0 or db[0] <= SILENCIO_DB else 0
        while k and k < len(db) and (abs(db[k] - base) <= 2.0 or db[k] <= SILENCIO_DB):
            k += 1
        if k < 5 or k >= len(db) - 1 or max(db[k:k + 5]) < base + 6:     # (puede subir poco a poco: medio segundo)
            return 0.0
        return max(0.0, k / 10 - 0.1)
    return plano(np.asarray(es[:n], np.float32)), plano(np.asarray(es[max(0, len(es) - n):], np.float32)[::-1])


def montar(es, fs, k, L, cortes, en_len, pre, original=None, lienzo=None, sin_doblaje=(), curva=None, puentes=(),
           p=None):
    """original: función que recibe tramos [(a, b)] en muestras de la pista original y devuelve esos
    trozos al formato del doblaje. Con ella, lo que le falta al doblaje (huecos de MIN_ORIGINAL s o
    más, y el principio y el final) se rellena con el audio original en vez de con silencio o ruido
    de fondo. lienzo: función que da el audio de salida vacío (en disco, si es grande); None = en la RAM.
    sin_doblaje: [(desde, hasta, t del doblaje)] en s del resultado donde el doblaje tiene otro montaje: lo que el
    montaje haya puesto ahí se quita (con fundidos) y va el audio original (o silencio, sin él).
    curva: velocidad variable con el castellano estirado ([(t del doblaje, desfase continuo)], estirado_deriva): en
    vez de la deriva k, cada tramo se remuestrea siguiendo la curva, con su nivel L[i].
    puentes: cortes cuyo hueco se tapa alargando el doblaje de alrededor (alargar) en vez de relleno(), o que en vez de
    quitar un trozo de golpe lo acortan.
    Con original, el ruido o silencio sin contenido del principio o del final del doblaje (sin_contenido) no tapa el
    original que va al lado; p: dónde se dice.
    Devuelve (audio, colocación de cada tramo, rellenos [(t doblaje, desde, hasta, dB)])."""
    ch = es.shape[1]
    fade = int(FADE_S * fs)
    ramp = np.linspace(0, 1, fade, dtype=np.float32)[:, None]
    total = pre + int(round(en_len * fs))
    out = lienzo((total, ch)) if lienzo else np.zeros((total, ch), np.float32)
    fr = Fraction(1 + k).limit_denominator(200000)
    starts, ends = limites(cortes, L, len(es) / fs)
    minimo = int(MIN_ORIGINAL * fs)

    def sumar(buf, pos):
        a0 = max(pos, 0); off = a0 - pos
        n = min(len(buf) - off, total - a0)
        if n > 0:
            out[a0:a0 + n] += buf[off:off + n]

    def poner(a_, n, dst, entrada, salida):
        """es[a_:a_ + n] en out[dst:], con sus fundidos (los de fundido()), por bloques de 60 s: el doblaje y el
        montaje pueden estar en disco."""
        nf = min(fade, n // 2)
        r = ramp if nf == fade else np.linspace(0, 1, nf, dtype=np.float32)[:, None]
        for o in range(0, n, max(60 * fs, 2 * fade)):
            blk = np.array(es[a_ + o:a_ + min(o + 60 * fs, n)], np.float32)
            e = o + len(blk)
            if nf and entrada and o < nf:
                blk[:min(nf, e) - o] *= r[o:min(nf, e)]
            if nf and salida and e > n - nf:
                s0 = max(n - nf, o)
                blk[s0 - o:] *= r[::-1][s0 - (n - nf):e - (n - nf)]
            sumar(blk, dst + o)

    def estirar(i, n, dst, entrada, salida):
        """El tramo i estirado siguiendo la curva en out[dst:dst + n], con sus fundidos, por bloques."""
        nf = min(fade, n // 2)
        r = ramp if nf == fade else np.linspace(0, 1, nf, dtype=np.float32)[:, None]
        for o, blk in estirar_bloques(es, fs, curva, L[i], dst, dst + n, pre):
            o -= dst
            e = o + len(blk)
            if nf and entrada and o < nf:
                blk[:min(nf, e) - o] *= r[o:min(nf, e)]
            if nf and salida and e > n - nf:
                s0 = max(n - nf, o)
                blk[s0 - o:] *= r[::-1][s0 - (n - nf):e - (n - nf)]
            sumar(blk, dst + o)

    # dónde cae en el resultado (s, sin pre) el instante t del doblaje dentro del tramo i
    en_res = ((lambda t, i: t * (1 + k) + L[i]) if curva is None else
              (lambda t, i: t + float(deriva_en(t, curva)) + L[i]))
    if original:
        # el doblaje puede empezar o acabar con ruido de la cinta o silencio: si al lado va el original, sigue hasta
        # donde el doblaje tiene algo (sin_contenido)
        ini, fin_ = sin_contenido(es, fs)
        if ini and en_res(starts[0], 0) * fs >= minimo and ini < ends[0] - starts[0] - 1.0:
            starts[0] += ini
            if p:
                p(f"Principio del doblaje: {ini:.1f} s sin contenido (ruido o silencio); sigue el audio original"
                  .replace(".", ","))
        if (fin_ and total - pre - en_res(ends[-1], len(L) - 1) * fs >= minimo
                and fin_ < ends[-1] - starts[-1] - 1.0):
            ends[-1] -= fin_
            if p:
                p(f"Final del doblaje: {fin_:.1f} s sin contenido (ruido o silencio); va el audio original"
                  .replace(".", ","))
    huecos = []                         # (desde, hasta, t del doblaje) en muestras de out
    dst0 = pre + int(round(en_res(starts[0], 0) * fs))
    if original and dst0 - pre >= minimo:
        huecos.append((pre, dst0, 0.0))
    colocacion = []
    for i in range(len(L)):
        a_, b_ = int(round(starts[i] * fs)), int(round(ends[i] * fs))
        dst = pre + int(round(en_res(starts[i], i) * fs))
        if curva is not None:
            n = pre + int(round(en_res(ends[i], i) * fs)) - dst
        else:
            n = b_ - a_ if fr == 1 else None
        if curva is None and fr != 1:   # la deriva ya no se aplica al doblaje (k = 0); queda por si acaso
            chunk = resample_poly(np.asarray(es[a_:b_]), fr.numerator, fr.denominator, axis=0).astype(np.float32)
            n = len(chunk)
        fin = dst + n
        final = original and i == len(L) - 1 and total - fin >= minimo
        entrada, salida = bool(i > 0 or huecos), bool(i < len(L) - 1 or final)
        if curva is not None:
            estirar(i, n, dst, entrada, salida)
        elif fr != 1:
            fundido(chunk, ramp, entrada=entrada, salida=salida)
            sumar(chunk, dst)
        else:
            poner(a_, n, dst, entrada, salida)
        colocacion.append(((dst - pre) / fs, (fin - pre) / fs))
        if final:
            huecos.append((fin, total, ends[i]))
        if i < len(L) - 1:
            gap = pre + int(round(en_res(starts[i + 1], i + 1) * fs)) - fin
            if original and gap >= minimo:
                huecos.append((fin, fin + gap, cortes[i]["c"]))
            elif gap > 0:
                f = relleno(es, fs, gap + 2 * fade, cortes[i]["q0"], cortes[i]["q1"], fade, ramp)
                f[:fade] *= ramp; f[-fade:] *= ramp[::-1]
                sumar(f, fin - fade)

    for i in puentes:
        # el corte i sin repetir ni cortar nada: lo que hay ahí (el final de un tramo, el relleno o el trozo que se
        # quita, y el principio del siguiente) se cambia por el doblaje de alrededor alargado o acortado (alargar),
        # fundido con lo de los lados: ±MEDIO_PUENTE s, o el triple del salto si es grande (así no pasa de un 15 %)
        if curva is not None or fr != 1 or i + 1 >= len(L) or starts[i + 1] < ends[i] - 1e-6:
            continue
        c0, c1 = ends[i], starts[i + 1]             # (en uno que recorta, entre los dos va lo que se quita)
        medio = max(MEDIO_PUENTE, 3 * abs(L[i + 1] - L[i]))
        izq, der = min(medio, c0 - starts[i] - 0.3), min(medio, ends[i + 1] - c1 - 0.3)
        a_, b_ = int(round((c0 - izq) * fs)), int(round((c1 + der) * fs))
        A = pre + int(round(colocacion[i][0] * fs)) + int(round((c0 - izq - starts[i]) * fs))
        B = pre + int(round(colocacion[i + 1][0] * fs)) + int(round(der * fs))
        if izq < 0.3 or der < 0.3 or A < 0 or B > total or B - A < 0.5 * (b_ - a_):
            continue
        y = alargar(np.asarray(es[a_:b_], np.float32), fs, (B - A) - (b_ - a_))
        F = min(int(0.05 * fs), len(y) // 4)        # fundidos de 50 ms: tapan entero el último marco de alargar
        r = np.linspace(0, 1, F, dtype=np.float32)[:, None]
        y[:F] = np.asarray(out[A:A + F], np.float32) * (1 - r) + y[:F] * r
        y[-F:] = y[-F:] * (1 - r) + np.asarray(out[B - F:B], np.float32) * r
        out[A:B] = y

    for z0, z1, t_dob in sin_doblaje:       # otro montaje: fuera lo que haya, con fundidos, y el original
        a, b = (int(np.clip(pre + round(z * fs), pre, total)) for z in (z0, z1))
        if b - a < fade:
            continue
        if a - fade >= 0:
            out[a - fade:a] *= ramp[::-1]
        if b + fade <= total:
            out[b:b + fade] *= ramp
        for o in range(a, b, 60 * fs):
            out[o:min(o + 60 * fs, b)] = 0
        if original:
            huecos.append((a, b, t_dob))
    if huecos:                              # los que se tocan (una zona y el hueco del principio), en uno
        unidos = []
        for a, b, t_dob in sorted(huecos):
            if unidos and a <= unidos[-1][1] + fade:
                unidos[-1] = (unidos[-1][0], max(unidos[-1][1], b), unidos[-1][2])
            else:
                unidos.append((a, b, t_dob))
        huecos = unidos

    rellenos = []
    if huecos:
        R = int(REF_NIVEL * fs)
        tramos = [(max(a - pre - R, 0), max(b - pre + R, 0)) for a, b, _ in sorted(huecos)]
        for (a, b, t_dob), (o0, _), x in zip(sorted(huecos), tramos, original(tramos)):
            en_x = lambda n: n - pre - o0                   # muestra de out -> índice en x
            if a <= pre or b >= total:
                # al principio o al final, solo si el original suena ahí de verdad (1 s o más por encima de -45 dB):
                # en Kojak 4x10 eran 1 s de silencio digital y 0,3 s del sonido que se adelanta a la imagen, que el
                # castellano también tiene y luego repetía
                tr = np.asarray(x[max(en_x(a), 0):max(en_x(b), 0)], np.float32)
                F, suena = fs // 100, 0.0
                nt = len(tr) // F
                if nt:
                    nivel = 20 * np.log10(np.sqrt((tr[:nt * F].reshape(nt, F, -1) ** 2).mean((1, 2))) + 1e-9)
                    suena = int((nivel > -45).sum()) * 0.01
                if suena < MIN_ORIGINAL:
                    if p:
                        p(f"{'Principio' if a <= pre else 'Final'}: el original apenas suena en esos "
                          f"{(b - a) / fs:.1f} s ({suena:.1f} s con sonido); no se rellena con él".replace(".", ","))
                    continue
            # volumen: el doblaje y el original en los REF_NIVEL s de alrededor (donde hay doblaje)
            ref = [(max(a - R, pre), a - fade), (b + fade, min(b + R, total))]
            ref_out = np.concatenate([out[p:q] for p, q in ref if q > p] or [np.zeros((0, ch))])
            ref_ori = np.concatenate([x[max(en_x(p), 0):max(en_x(q), 0)] for p, q in ref if q > p]
                                     or [np.zeros((0, ch))])
            r_out, r_ori = (float(np.sqrt(np.mean(z ** 2))) if len(z) else 0.0 for z in (ref_out, ref_ori))
            g = float(np.clip(r_out / r_ori, 0.5, 2.0)) if r_out > 1e-4 and r_ori > 1e-4 else 1.0
            # el trozo del original, con fundidos que se cruzan con los del doblaje
            p0, p1 = max(a - fade, pre), min(b + fade, total)
            f = x[max(en_x(p0), 0):max(en_x(p1), 0)] * g
            f = np.concatenate([f, np.zeros((max(p1 - p0 - len(f), 0), ch), np.float32)])
            fundido(f, ramp, entrada=p0 > pre, salida=p1 < total)
            sumar(f, p0)
            rellenos.append((t_dob, a, b, 20 * np.log10(g)))
    return out, colocacion, rellenos


def cargar_tramos(path, st, fs, ch, tramos, vel=Fraction(1)):
    """Trozos [(a, b)] (muestras desde el principio de la pista) de una pista al formato del doblaje,
    leyéndola de un tirón sin guardar el resto en memoria. vel: la pista acelerada en esa proporción
    (como el original adaptado a un doblaje PAL: más rápido y más agudo)."""
    fin = max(b for _, b in tramos)
    trozos = [np.zeros((b - a, ch), np.float32) for a, b in tramos]
    formato = (["-af", HUECOS, "-ar", str(fs)] if vel == 1 else
               ["-af", HUECOS + "," + filtro_velocidad(int(st["sample_rate"]), vel, fs)])
    proceso = subprocess.Popen(["ffmpeg", "-v", "error", "-i", path, "-map", f"0:{st['index']}", "-ac", str(ch)]
                               + formato + ["-f", "f32le", "-"], stdout=subprocess.PIPE, **SIN_VENTANA)
    pos, bloque = 0, fs * 10 * ch * 4
    try:
        while pos < fin:
            raw = proceso.stdout.read(bloque)
            if not raw:
                break
            x = np.frombuffer(raw[:len(raw) // (4 * ch) * 4 * ch], np.float32).reshape(-1, ch)
            for (a, b), t in zip(tramos, trozos):
                i0, i1 = max(a, pos), min(b, pos + len(x))
                if i0 < i1:
                    t[i0 - a:i1 - a] = x[i0 - pos:i1 - pos]
            pos += len(x)
    finally:
        proceso.kill()
        proceso.wait()
    return trozos


# ---------------------------------------------------------------- medida con el vídeo
# Si el doblaje se mezcló con otra música u otras risas, su audio apenas se parece al original,
# pero los cambios de plano son los mismos en las dos versiones: se mide con ellos.

VR = 100             # muestras por segundo de la señal de cambios de plano
SIGMA = 0.020        # tolerancia al emparejar cambios de plano (medio fotograma PAL)
PEN_V = 2.5          # coste de cambiar de desfase, en cambios de plano que encajan
MAX_RETROCESO = 2.0  # s que puede volver atrás el original entre dos tramos seguidos (más: el doblaje repetiría metraje)
MIN_CORTES_REPETICION, MIN_S_REPETICION = 15, 60.0   # dos tramos así de firmes: el doblaje repite de verdad
# (entre el tiempo y el corte puede haber otras líneas del mismo fotograma: «timecode=00:00:00:00» si el vídeo lleva
# código de tiempo, como el WEB de «Voy a brillar»; sin admitirlas no se leía ni un fotograma: «no se ha podido leer el
# vídeo», tras media hora)
RE_FOTOGRAMA = re.compile(r"pts_time:(-?[\d.]+)[^\n]*\n(?:(?!frame:)[^\n]*\n)*?lavfi\.scd\.mafd=([\d.]+)")


def pista_video(path):
    """Índice de la pista de vídeo (sin contar carátulas) o None."""
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v", "-show_entries",
                        "stream=index:stream_disposition=attached_pic", "-of", "json", path],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", check=True, **SIN_VENTANA)
    v = [s for s in json.loads(r.stdout).get("streams", []) if not (s.get("disposition") or {}).get("attached_pic")]
    return v[0]["index"] if v else None


# El vídeo solo se decodifica al medir con los cambios de plano y al leer los forzados. Con GPU, ffmpeg
# decodifica en la tarjeta; lo caro es devolver cada fotograma entero a la memoria, así que primero se prueba
# a reducirlo allí mismo y devolver solo la miniatura. Si la GPU falla, se prueba sin reducir y, al final,
# con la CPU. (Intel HD 530 con driver de 2018, original 1080p: CPU 68 s, dxva2 88 s, d3d11va sin reducir 265 s;
# Quick Sync y scale_d3d11 no funcionan con ese driver: ahí conviene la CPU.)
DECODIFICADORES = {
    # clave: (nombre, -hwaccel, formato de los fotogramas en la GPU, filtro que los reduce allí)
    "cpu": ("CPU", None, None, None),
    "auto": ("GPU (la que haya)", "auto", None, None),
    "nvidia": ("NVIDIA (CUDA)", "cuda", "cuda", "scale_cuda=w={w}:h={h}:format=nv12"),
    "intel": ("Intel (Quick Sync)", "qsv", "qsv", "vpp_qsv=w={w}:h={h}:format=nv12"),
    "amd": ("AMD (AMF)", "amf", "amf", "vpp_amf=w={w}:h={h}:format=nv12"),
    "d3d11": ("DirectX 11", "d3d11va", "d3d11", "scale_d3d11=width={w}:height={h}:format=nv12"),
    "d3d12": ("DirectX 12", "d3d12va", "d3d12", "scale_d3d12=w={w}:h={h}:format=nv12"),
    "dxva2": ("DXVA2", "dxva2", None, None),
}


def intentos_decodificar(deco, w=None, h=None):
    """Formas de decodificar, en orden de preferencia: (nombre, opciones de entrada, principio del filtro).
    Con w y h, la primera reduce el fotograma en la GPU. La última es siempre la CPU."""
    nombre, acel, fmt, reducir = DECODIFICADORES.get(deco or "cpu", DECODIFICADORES["cpu"])
    out = []
    if acel:
        if fmt and reducir and w:
            out.append((f"{nombre}, reduciendo en la GPU", ["-hwaccel", acel, "-hwaccel_output_format", fmt],
                        reducir.format(w=w, h=h) + ",hwdownload,format=nv12,"))
        out.append((nombre, ["-hwaccel", acel], ""))
    out.append(("CPU", [], ""))
    return out


def fotogramas_esperados(path, idx):
    """Duración x fotogramas por segundo (para notar si la GPU se salta fotogramas), o None."""
    try:
        r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", str(idx), "-show_entries",
                            "stream=avg_frame_rate:format=duration", "-of", "json", path],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", check=True, **SIN_VENTANA)
        j = json.loads(r.stdout)
        return float(Fraction(j["streams"][0]["avg_frame_rate"])) * float(j["format"]["duration"])
    except (subprocess.CalledProcessError, KeyError, IndexError, ValueError, ZeroDivisionError):
        return None


# Los datos de color se dejan como «desconocidos» antes de reducir la imagen: un vídeo con alguno mal puesto
# («trc:reserved») hacía que el ffmpeg actual se negara a pasarlo a gris («Unsupported input», sin un solo fotograma:
# «no se ha podido leer el vídeo»). Para el gris o el OCR solo cuenta el brillo: con un vídeo normal sale lo mismo
SIN_COLOR = "setparams=color_trc=unknown:color_primaries=unknown:colorspace=unknown,"


def cortes_video(path, idx, t0, deco="cpu", p=print, desde=None, hasta=None, miniaturas=None):
    """Cambios de plano: señal a VR Hz, tiempos e intensidades, en el tiempo de la pista de audio
    (t0 = inicio de esa pista en el contenedor). ffmpeg da la diferencia media entre fotogramas.
    deco: con qué se decodifica (clave de DECODIFICADORES); si la GPU falla, se usa la CPU.
    desde/hasta (s del contenedor): solo ese trozo del vídeo (los tiempos siguen siendo los del archivo).
    miniaturas: archivo donde guardar también, de paso, cada fotograma en gris de 64x48 (lo que ve el detector) y, en
    miniaturas + ".t.npy", sus tiempos (los de la pista de audio): para comparar el contenido (contenido_deriva)."""
    fin = SIN_COLOR + "scale=64:48:flags=area,format=gray,scdet=threshold=100,metadata=mode=print:file=-"
    trozo = desde is not None
    esperados = fotogramas_esperados(path, idx) if deco not in (None, "cpu") and not trozo else None
    rango = ["-ss", f"{max(0.0, desde):.3f}", "-t", f"{hasta - max(0.0, desde):.3f}"] if trozo else []
    for nombre, entrada, inicio in intentos_decodificar(deco, 256, 192):
        t_ini = time.time()
        if miniaturas:          # la misma decodificación, partida en dos: el detector y las miniaturas
            grafo = (f"[0:{idx}]{inicio}{SIN_COLOR}scale=64:48:flags=area,format=gray,split=2[a][b];"
                     f"[a]scdet=threshold=100,metadata=mode=print:file=-[c]")
            salidas = ["-filter_complex", grafo, "-map", "[c]", "-fps_mode", "passthrough", "-f", "null", "-",
                       "-map", "[b]", "-fps_mode", "passthrough", "-f", "rawvideo", "-y", miniaturas]
        else:
            salidas = ["-map", f"0:{idx}", "-an", "-sn", "-dn", "-fps_mode", "passthrough", "-vf", inicio + fin,
                       "-f", "null", "-"]
        r = subprocess.run(["ffmpeg", "-hide_banner", "-v", "error", "-nostats"] + entrada + rango + ["-copyts", "-i", path]
                           + salidas, capture_output=True, text=True, encoding="utf-8", errors="replace", **SIN_VENTANA)
        fr = np.array(RE_FOTOGRAMA.findall(r.stdout), float)
        if nombre == "CPU" or (r.returncode == 0 and len(fr) >= 100 and
                               (not esperados or len(fr) >= 0.97 * esperados)):
            break
        motivo = (" ".join(r.stderr.strip().splitlines()[-1:])[:150] if r.returncode
                  else f"solo {len(fr)} de ~{esperados:.0f} fotogramas" if esperados else "sin fotogramas")
        p(f"  {os.path.basename(path)}: no se ha podido decodificar con {nombre} ({motivo}); se prueba de otra forma")
    if deco not in (None, "cpu"):
        p(f"  {os.path.basename(path)}: vídeo decodificado con {nombre} en {time.time() - t_ini:.0f} s")
    if len(fr) < 100:
        raise RuntimeError(f"no se ha podido leer el vídeo de {os.path.basename(path)}")
    if miniaturas:              # un fotograma de miniatura por línea del detector, en el mismo orden
        np.save(miniaturas + ".t.npy", fr[:, 0] - t0)
    fr = fr[np.argsort(fr[:, 0], kind="stable")]
    t, d = fr[:, 0] - t0, fr[:, 1]
    s = np.maximum(d - median_filter(d, 9), 0)          # picos sobre el movimiento normal
    s = np.minimum(s / (np.percentile(s, 99.5) + 1e-9), 3.0)
    t, s = t[t >= 0], s[t >= 0]
    return senal_cortes(t, s), t, s


def senal_cortes(t, s):
    """Señal de cambios de plano a VR Hz (para correlar) a partir de sus tiempos e intensidades."""
    g = np.zeros(int(t.max() * VR) + 2, np.float32)
    np.maximum.at(g, np.round(t * VR).astype(int), s)
    return gaussian_filter1d(g, 2)


def pico(c, i):
    """Posición del máximo entre muestras (parábola)."""
    if 0 < i < len(c) - 1:
        den = c[i - 1] - 2 * c[i] + c[i + 1]
        if den < 0:
            return 0.5 * (c[i - 1] - c[i + 1]) / den
    return 0.0


# Un trozo con dos o tres cambios de plano encaja por casualidad en cualquier sitio del original con la misma
# separación (Kojak 2x24, doblaje PAL frente a un original a 30 fps: un minuto con 2 cortes daba 0,84 a la misma
# velocidad y ya no se probaba 25/23,976, que era la buena con 0,93). Para fiarse de un trozo, al menos estos cortes:
MIN_CORTES_MINUTO = 6        # en un minuto (desfase_video)
MIN_CORTES_BUSQUEDA = 4      # en 20 s, para buscarlo en todo el original (seguir_video)
PICO_SENAL = 0.1995          # altura de un corte de intensidad 1 en senal_cortes (gaussiana de sigma 2)


def n_cortes(g):
    """Cambios de plano en un trozo de la señal: sus picos, de los que se emparejan (intensidad > 0,3)."""
    c = g[1:-1]
    return int(((c > 0.3 * PICO_SENAL) & (c >= g[:-2]) & (c > g[2:])).sum())


def desfase_video(gm, ge):
    """Desfase del primer minuto que encaja con claridad (> 0,8) y que confirma, en el mismo desfase (±0,3 s), alguno
    de los tres siguientes que no se solapan con él, entre los que tienen al menos MIN_CORTES_MINUTO cambios de plano
    (si ninguno los tiene, entre todos). Un minuto suelto encaja por casualidad en cualquier sitio (Kojak 1x16: 0,85
    con un desfase de 38 minutos, y el seguimiento arrancaba allí). Si ninguno se confirma, como antes: el primero que
    encaje con claridad, o el mejor que haya."""
    W, best, primero = 60 * VR, (0.0, -1.0), None
    ventanas = list(range(0, len(gm) - W, 30 * VR))
    ventanas = [t0 for t0 in ventanas if n_cortes(gm[t0:t0 + W]) >= MIN_CORTES_MINUTO] or ventanas
    medidas = {}

    def medida(t0):
        if t0 not in medidas:
            c = ncc_curve(gm[t0:t0 + W], ge)
            medidas[t0] = None if c is None or not len(c) else ((int(np.argmax(c)) - t0) / VR, float(c.max()))
        return medidas[t0]

    for i, t0 in enumerate(ventanas):
        m = medida(t0)
        if m is None:
            continue
        if m[1] > best[1]:
            best = m
        if m[1] <= 0.8:
            continue
        primero = primero or m
        siguientes = [t1 for t1 in ventanas[i + 1:] if t1 >= t0 + W][:3]
        if any((m1 := medida(t1)) is not None and m1[1] >= 0.5 and abs(m1[0] - m[0]) <= 0.3 for t1 in siguientes):
            return m
    return primero or best


def ventanas_video(gm, ge, n=24):
    """(desfase, parecido) de hasta n minutos del doblaje repartidos por todo él (de los que tienen al menos
    MIN_CORTES_MINUTO cambios de plano; si no hay ninguno así, de todos), cada uno buscado en todo el original."""
    W = 60 * VR
    todas = list(range(0, len(gm) - W, 30 * VR))
    buenas = [t0 for t0 in todas if n_cortes(gm[t0:t0 + W]) >= MIN_CORTES_MINUTO] or todas
    if not buenas:
        return []
    out = []
    for t0 in sorted({buenas[int(round(i))] for i in np.linspace(0, len(buenas) - 1, min(n, len(buenas)))}):
        c = ncc_curve(gm[t0:t0 + W], ge)
        if c is None or not len(c):
            continue
        i = int(np.argmax(c))
        out.append(((i - t0) / VR, float(c[i])))
    return out


def coherencia_video(ventanas, tol=0.3):
    """(minutos que caen casi en el mismo desfase que el de al lado, la suma de sus parecidos). Una casualidad no se
    repite en el minuto siguiente; el desfase de verdad sí puede moverse despacio (una velocidad un poco distinta, que
    luego se mide como deriva) o de golpe en una cortinilla, y por eso cada minuto se compara solo con sus vecinos."""
    ok = [False] * len(ventanas)
    for i in range(len(ventanas) - 1):
        if abs(ventanas[i][0] - ventanas[i + 1][0]) <= tol:
            ok[i] = ok[i + 1] = True
    cs = [c for (_, c), o in zip(ventanas, ok) if o]
    return len(cs), float(sum(cs))


def seguir_video(gm, ge, lag0):
    """Desfase en ventanas de 20 s cada segundo (como seguir(), con la señal de cambios de plano).
    Si lleva 20 s sin encajar (falta o sobra un trozo grande), cada 5 s se busca en todo el original."""
    WIN, SEARCH = 20 * VR, 15 * VR

    def confirmado(t, L):
        """Lo que encaja lejos solo vale si los 20 s siguientes del doblaje encajan en el mismo desfase (±0,3 s): un
        trozo suelto con pocos cortes encaja por casualidad en cualquier sitio y se llevaba el seguimiento allí (Kojak
        1x16: 13 minutos con desfases disparatados). Si no se puede confirmar, se vuelve a buscar 5 s después."""
        t2 = t + WIN
        if t2 + WIN > len(gm) or n_cortes(gm[t2:t2 + WIN]) < 2:
            return False
        lo, hi = max(0, t2 + L - 30), min(len(ge), t2 + L + WIN + 30)
        c = ncc_curve(gm[t2:t2 + WIN], ge[lo:hi]) if hi - lo >= WIN else None
        return c is not None and len(c) > 0 and float(c.max()) >= 0.6

    pts, lag, ult = [], int(round(lag0 * VR)), 0
    for t in range(0, len(gm) - WIN, VR):
        c = None
        if t - ult >= 20 * VR and (t // VR) % 5 == 0 and n_cortes(gm[t:t + WIN]) >= MIN_CORTES_BUSQUEDA:
            c = ncc_curve(gm[t:t + WIN], ge)
            lo = 0
            if c is not None and (c.max() < 0.8 or not confirmado(t, int(np.argmax(c)) - t)):
                c = None
        if c is None:
            lo, hi = max(0, t + lag - SEARCH), min(len(ge), t + lag + WIN + SEARCH)
            if hi - lo < WIN:
                continue
            c = ncc_curve(gm[t:t + WIN], ge[lo:hi])
        if c is None:
            continue
        i = int(np.argmax(c)); s = float(c[i])
        L = lo + i + pico(c, i) - t
        if s > 0.6:
            lag, ult = int(round(L)), t
        pts.append(((t + WIN / 2) / VR, L / VR, s))
    return np.array(pts).reshape(-1, 3)


def niveles_video(pts, ev, ref, k, min_cortes=4):
    """buscar_niveles() para la imagen. Cada punto de seguir_video es una ventana de 20 s y van cada segundo, así que un
    solo trozo que encaja por casualidad da una veintena de puntos seguidos y pasaba por un desfase que se repite: cada
    nivel tiene que tener además al menos min_cortes cambios de plano DISTINTOS del doblaje que encajen con él donde
    aparece. Si ninguno llega (cortes muy escasos), los de siempre."""
    todos, out = buscar_niveles(pts, k), []
    for L in todos:
        g = pts[(pts[:, 2] > 0.25) & (np.abs(pts[:, 1] - k * pts[:, 0] - L) < 0.020)]
        if not len(g):
            continue
        cand = ev[(ev >= g[:, 0].min() - 10) & (ev <= g[:, 0].max() + 10)]     # cada ventana abarca ±10 s
        p_ = cand * (1 + k) + L
        i = np.clip(np.searchsorted(ref, p_), 1, len(ref) - 1)
        d = np.minimum(np.abs(ref[i] - p_), np.abs(ref[i - 1] - p_))
        if int((d < 2.5 * SIGMA).sum()) >= min_cortes:
            out.append(L)
    return out or todos


def votos(ev, ref, k, niveles):
    """Para cada cambio de plano del doblaje y cada nivel: +1 si en el original hay uno donde lo
    pone ese desfase, -1 si no (con transición suave según la distancia)."""
    E = np.empty((len(ev), len(niveles)))
    for j, L in enumerate(niveles):
        p_ = ev * (1 + k) + L
        i = np.clip(np.searchsorted(ref, p_), 1, len(ref) - 1)
        d = np.minimum(np.abs(ref[i] - p_), np.abs(ref[i - 1] - p_))
        E[:, j] = 2 * np.exp(-0.5 * (d / SIGMA) ** 2) - 1
    return E


def tramos_video(ev, ref, k, niveles, min_ev=3):
    """Viterbi sobre los cambios de plano del doblaje: tramos [primer cambio, último cambio, nivel].
    Un salto de desfase queda entre el último cambio de un tramo y el primero del siguiente."""
    E = votos(ev, ref, k, niveles)
    n, S = E.shape
    dp, bp, idx = E[0].copy(), np.zeros((n, S), np.int32), np.arange(S)
    for f in range(1, n):
        j = int(np.argmax(dp)); sw = dp[j] - PEN_V > dp
        bp[f] = np.where(sw, j, idx)
        dp = np.where(sw, dp[j] - PEN_V, dp) + E[f]
    path = np.zeros(n, int); path[-1] = int(np.argmax(dp))
    for f in range(n - 1, 0, -1):
        path[f - 1] = bp[f, path[f]]
    runs, s0 = [], 0
    for f in range(1, n + 1):
        if f == n or path[f] != path[f - 1]:
            runs.append([s0, f - 1, path[s0], int((E[s0:f, path[s0]] > 0).sum())])
            s0 = f

    def unir(runs, i, j):
        """El tramo i pasa al vecino j; luego se juntan los vecinos que hayan quedado con el mismo nivel."""
        runs[j][0], runs[j][1] = min(runs[j][0], runs[i][0]), max(runs[j][1], runs[i][1])
        del runs[i]
        fus = [runs[0]]
        for r in runs[1:]:
            if r[2] == fus[-1][2]:
                fus[-1][1] = r[1]; fus[-1][3] += r[3]
            else:
                fus.append(r)
        return fus

    # tramos con muy pocos cambios de plano que encajen (créditos distintos, casualidades): al vecino
    while len(runs) > 1:
        i = min(range(len(runs)), key=lambda i: runs[i][3])
        if runs[i][3] >= min_ev:
            break
        runs = unir(runs, i, max([j for j in (i - 1, i + 1) if 0 <= j < len(runs)], key=lambda j: runs[j][3]))
    # dos tramos seguidos que harían volver atrás el original (el doblaje repetiría metraje): si uno de los dos es corto
    # o encaja poco, es un encaje casual: una cabecera con decenas de cortes seguidos (destellos) admite casi cualquier
    # desfase (Kojak 2x24: 20 s del doblaje a +19,5 s entre tramos a +1,1 y +2,9 s: insertaba 18,5 s y recortaba 16,6),
    # y el que menos cortes encaja pasa al otro. Si los dos son largos y encajan de sobra, el doblaje repite de verdad
    # (Kojak 2x06 latino, emisión de TV: al volver de la publicidad repite dos minutos, dos veces): la repetición se
    # quita, es decir, el segundo tramo empieza donde el original sigue a partir del primero
    orig = lambda r, extremo: ev[r[extremo]] * (1 + k) + niveles[r[2]]
    firme = lambda r: r[3] >= MIN_CORTES_REPETICION and ev[r[1]] - ev[r[0]] >= MIN_S_REPETICION
    while True:
        i = next((i for i in range(len(runs) - 1)
                  if orig(runs[i + 1], 0) < orig(runs[i], 1) - MAX_RETROCESO), None)
        if i is None:
            break
        a_, b_ = runs[i], runs[i + 1]
        if firme(a_) and firme(b_):
            fin_a = orig(a_, 1)
            sigue = next((f for f in range(b_[0], b_[1] + 1) if ev[f] * (1 + k) + niveles[b_[2]] > fin_a + 0.5), None)
            if sigue is not None:
                resto = [sigue, b_[1], b_[2],
                         int((votos(ev[sigue:b_[1] + 1], ref, k, [niveles[b_[2]]])[:, 0] > 0).sum())]
                if firme(resto):
                    runs[i + 1] = resto
                    continue
        runs = unir(runs, i, i + 1) if runs[i][3] <= runs[i + 1][3] else unir(runs, i + 1, i)
    return [[float(ev[a]), float(ev[b]), niveles[l]] for a, b, l, _ in runs]


def puntos_video(ev, ref, k, segs):
    """(t, desfase, 1) de cada cambio de plano del doblaje que encaja con el de su tramo."""
    lim = [s[1] for s in segs[:-1]]
    out = []
    for t in ev:
        p_ = t * (1 + k) + segs[int(np.searchsorted(lim, t))][2]
        i = int(np.clip(np.searchsorted(ref, p_), 1, len(ref) - 1))
        r = min(ref[i], ref[i - 1], key=lambda x: abs(x - p_))
        if abs(r - p_) < 2.5 * SIGMA:
            out.append((t, r - t, 1.0))
    return np.array(out).reshape(-1, 3)


# Dos clases de avisos: los que dicen que algo puede estar mal (van delante y con «[revisar]») y los que solo piden
# escuchar algo que lo normal es que esté bien (un corte sin silencio, un relleno con el original). Pedido del usuario
# (21-10-2026): que el informe sea más claro y no avise igual de todo
REVISAR = ("la imagen va ahí a", "otro desfase", "no coinciden", "no se ha podido comprobar para qué versión",
           "caracteres raros", "etiquetas de idioma", "parece la versión original", "no va igual de desfasado",
           "otro montaje", "no deja comprobar", "música desplazada", "desfase residual", "no encajan con el original")


def para_revisar(aviso):
    return any(x in aviso for x in REVISAR)


def duracion(s):
    """«12 min 5 s» (o «40 s»)."""
    s = int(round(s))
    return f"{s // 60} min {s % 60} s" if s >= 60 else f"{s} s"


# Cuánto tarda cada parte del análisis (pedido del usuario: para ver dónde se va el tiempo, también si falla; «Voy a
# brillar» tardó 26 min y falló sin decir en qué): «audio» lo apunta sincronizar al acabar con el audio, «imagen» lo
# suma cortes_de_ambos cada vez que lee los cambios de plano
CRONO = {}


def texto_tiempo(total):
    """«14 min 5 s (leer y medir el audio: 2 min 10 s; leer los cambios de plano: 10 min 2 s; el resto: 1 min 53 s)»."""
    partes = [(nombre, CRONO[clave]) for clave, nombre in (("audio", "leer y medir el audio"),
                                                          ("imagen", "leer los cambios de plano"),
                                                          ("contraste", "contrastar el doblaje con el original"))
              if CRONO.get(clave)]
    resto = total - sum(t for _, t in partes)
    if not partes:
        return duracion(total)
    return (f"{duracion(total)} (" + "; ".join(f"{n}: {duracion(t)}" for n, t in partes)
            + (f"; el resto: {duracion(resto)}" if resto >= 1 else "") + ")")


def cortes_de_ambos(es_path, en_path, st_es, st_en, deco="cpu", p=print, miniaturas=(None, None)):
    """cortes_video() del doblaje y del original, los dos a la vez (dos ffmpeg en paralelo). miniaturas: dónde
    guardar las de cada uno (cortes_video), o None. Dice cuánto ha tardado: con un original 1080p es lo más lento."""
    t0 = time.time()
    r = en_paralelo(lambda x: cortes_video(x[0], pista_video(x[0]), float(x[1].get("start_time") or 0), deco, p,
                                           miniaturas=x[2]),
                    [(es_path, st_es, miniaturas[0]), (en_path, st_en, miniaturas[1])])
    CRONO["imagen"] = CRONO.get("imagen", 0.0) + time.time() - t0
    p(f"Cambios de plano leídos en {duracion(time.time() - t0)}")
    return r


# Doblajes de VHS o de emisiones comprimidas en tiempo: la velocidad no es fija (Ninja Sasuke 2, frente a la versión
# árabe: de media un 0,92 % más rápido, a ratos igual que el original y a ratos un 1,4 % más; 11 s al final). Dentro de
# una ventana de 20 s esa deriva descoloca ±100 ms los cambios de plano de sus extremos, nada encaja de sobra y salía
# «los vídeos tampoco coinciden». Se sigue cambio de plano a cambio de plano: el original se adapta a la velocidad
# media y lo que varía se reparte en tramos (cortes pequeños en el castellano, que no se estira: decisión del usuario).
DERIVA_MAX = 0.03          # lo que puede ir el doblaje más rápido o más lento que su media, a ratos
TOL_DERIVA = 0.05          # ± s que puede desviarse un tramo antes de cortar (como MIN_SALTO_VIDEO: < 0,1 s no se toca)
SUAVIZADO_DERIVA = 3.0     # ± s de la mediana de desfases antes de trocear (los cortes van en fotogramas de 33-42 ms)


# Destellos: en un trozo con cambios de plano cada pocos fotogramas cualquier desfase encuentra uno cerca por
# casualidad, y el seguimiento sacaba desfases inventados (Becker 1x02: la cabecera, unos 6 por segundo durante 17 s,
# dio -2,54, -0,08, -1,37 y -0,09 s, con 5 s de inglés metidos, cuando la imagen va a +1,48 s todo el rato; Kojak 2x24).
# Sus cambios de plano no cuentan para medir: el trozo va con el desfase de al lado (y la imagen lo comprueba)
DENSO_CORTES = 6        # cambios de plano distintos en 2 s (±1 s alrededor de cada uno) para que sea un destello


def sin_destellos(ev):
    """Los cambios de plano ev sin los de los destellos (al menos 1 s seguido con DENSO_CORTES en cada 2 s). Si los
    destellos ocupan más de la mitad del tiempo (un vídeo así entero), todos: no habría con qué medir. (Por tiempo, no
    por cortes: un destello acumula casi todos; en una copia de 2,5 min de Becker eran 115 de 149 en 17 s.)
    Devuelve (cambios de plano, [(desde, hasta)] de los destellos)."""
    if len(ev) < 10:
        return ev, []
    u = ev[np.concatenate([[True], np.diff(ev) > 0.06])]        # (sin los dobles de un fundido)
    denso = (np.searchsorted(u, u + 1.0, side="right") - np.searchsorted(u, u - 1.0)) >= DENSO_CORTES
    zonas = []
    for t, d in zip(u, denso):
        if d:
            if zonas and t - zonas[-1][1] <= 1.0:
                zonas[-1][1] = t
            else:
                zonas.append([t, t])
    zonas = [(max(0.0, a - 0.5), b + 0.5) for a, b in zonas if b - a >= 1.0]
    if sum(b - a for a, b in zonas) > 0.5 * max(ev[-1] - ev[0], 1.0):
        return ev, []
    fuera = np.ones(len(ev), bool)
    for a, b in zonas:
        fuera &= (ev < a) | (ev > b)
    return ev[fuera], zonas


def cortes_unicos(t, s, umbral=0.3):
    """Tiempos de los cambios de plano (intensidad > umbral) sin los dobles: un telecine con campos mezclados da el
    corte en dos fotogramas seguidos (428 de los 1252 del doblaje de Ninja Sasuke 2); se queda el más fuerte."""
    out = []
    for ti, si in zip(t[s > umbral], s[s > umbral]):
        if out and ti - out[-1][0] < 0.05:
            if si > out[-1][1]:
                out[-1] = (ti, si)
        else:
            out.append((ti, si))
    return np.array([x[0] for x in out])


def cadena_deriva(gm, ge, salto=2.0):
    """Curva gruesa del desfase: ventanas de 20 s cada 5 s buscadas en todo el original, y de sus mejores encajes la
    cadena de más parecido en la que el desfase cambia como mucho DERIVA_MAX (+0,3 s) de una a otra; saltarse esa
    condición (falta o sobra un trozo) cuesta `salto`. Un encaje casual queda suelto, lejos de los de al lado.
    Devuelve (ventanas medidas, cadena [(t, desfase, parecido)])."""
    W, H = 20 * VR, 5 * VR
    pts = []
    for t0 in range(0, len(gm) - W, H):
        if n_cortes(gm[t0:t0 + W]) < MIN_CORTES_BUSQUEDA:
            continue
        c = ncc_curve(gm[t0:t0 + W], ge)
        if c is not None and len(c):
            i = int(np.argmax(c))
            pts.append(((t0 + W / 2) / VR, (i - t0) / VR, float(c[i])))
    if len(pts) < 3:
        return len(pts), np.zeros((0, 3))
    pts = np.array(pts)
    best, prev = pts[:, 2].copy(), np.full(len(pts), -1)
    for j in range(len(pts)):
        for i in range(j):
            suave = abs(pts[j, 1] - pts[i, 1]) <= 0.3 + DERIVA_MAX * (pts[j, 0] - pts[i, 0])
            v = best[i] + pts[j, 2] - (0.0 if suave else salto)
            if v > best[j]:
                best[j], prev[j] = v, i
    j, cadena = int(np.argmax(best)), []
    while j >= 0:
        cadena.append(j)
        j = prev[j]
    return len(pts), pts[cadena[::-1]]


def seguir_cortes(e, ref, cadena, banda=1.0, paso=0.005, coste=0.08):
    """Viterbi sobre los cambios de plano del doblaje (e) con desfases en ±banda s de la curva gruesa, cada `paso` s:
    cada corte vota como en votos() y mover el desfase cuesta `coste` por paso (seguir una deriva del 1,4 % cuesta
    poco; saltar a por un corte casual 0,1 s más allá, ida y vuelta, más de lo que gana). Devuelve (desfase de cada
    corte, si encaja con un corte del original, ese corte del original)."""
    C = np.interp(e, cadena[:, 0], cadena[:, 1])
    d = np.arange(-banda, banda + paso / 2, paso)
    S, idx = len(d), np.arange(len(d))

    def emision(j):
        x = e[j] + C[j] + d
        i = np.clip(np.searchsorted(ref, x), 1, len(ref) - 1)
        dd = np.minimum(np.abs(ref[i] - x), np.abs(ref[i - 1] - x))
        return 2 * np.exp(-0.5 * (dd / SIGMA) ** 2) - 1

    dp, bp = emision(0), np.zeros((len(e), S), np.int32)
    for j in range(1, len(e)):
        # el mismo desfase de verdad cae en otro estado si la curva gruesa ha cambiado
        src = idx + int(round((C[j] - C[j - 1]) / paso))
        ok = (src >= 0) & (src < S)
        a = np.full(S, -1e9)
        a[ok] = dp[src[ok]]
        # máximo de a[s'] - coste·|s - s'| para cada s, con sus orígenes (transformada de distancia L1)
        up, down = a + coste * idx, a - coste * idx
        f = np.maximum.accumulate(up)
        fi = np.maximum.accumulate(np.where(up == f, idx, 0))
        g = np.maximum.accumulate(down[::-1])[::-1]
        gi = np.minimum.accumulate(np.where(down == g, idx, S - 1)[::-1])[::-1]
        fv, gv = f - coste * idx, g + coste * idx
        de_f = fv >= gv
        dp = np.where(de_f, fv, gv) + emision(j)
        bp[j] = np.where(ok, src, 0)[np.where(de_f, fi, gi)]
    camino = np.zeros(len(e), int)
    camino[-1] = int(np.argmax(dp))
    for j in range(len(e) - 1, 0, -1):
        camino[j - 1] = bp[j, camino[j]]
    Lc = C + d[camino]
    x = e + Lc
    i = np.clip(np.searchsorted(ref, x), 1, len(ref) - 1)
    r = np.where(np.abs(ref[i] - x) < np.abs(ref[i - 1] - x), ref[i], ref[i - 1])
    return Lc, np.abs(r - x) < 2.5 * SIGMA, r


def tramos_deriva(t, o, min_s=2.0, min_n=3):
    """Tramos de desfase constante que siguen una deriva: desfases suavizados (mediana de ±SUAVIZADO_DERIVA s) y un
    tramo nuevo cada vez que se salen de ±TOL_DERIVA; los de menos de min_s s o min_n cortes, con el vecino de nivel
    más parecido. Devuelve los tramos como [primer, último] índice de t."""
    s = np.array([np.median(o[np.abs(t - x) <= SUAVIZADO_DERIVA]) for x in t])
    idx, a, lo, hi = [], 0, s[0], s[0]
    for j in range(1, len(t)):
        if max(hi, s[j]) - min(lo, s[j]) > 2 * TOL_DERIVA:
            idx.append([a, j - 1])
            a, lo, hi = j, s[j], s[j]
        else:
            lo, hi = min(lo, s[j]), max(hi, s[j])
    idx.append([a, len(t) - 1])
    nivel = lambda r: np.median(s[r[0]:r[1] + 1])
    while len(idx) > 1:
        i = next((i for i, (a_, b_) in enumerate(idx) if t[b_] - t[a_] < min_s or b_ - a_ + 1 < min_n), None)
        if i is None:
            break
        j = min((x for x in (i - 1, i + 1) if 0 <= x < len(idx)), key=lambda x: abs(nivel(idx[x]) - nivel(idx[i])))
        idx[min(i, j)] = [min(idx[i][0], idx[j][0]), max(idx[i][1], idx[j][1])]
        del idx[max(i, j)]
    return idx


# Opción del usuario para la velocidad variable: estirar el castellano en vez de cortarlo. Lo que se estira es la deriva
# continua; los saltos de verdad (fotogramas que faltan o sobran en el VHS: en Ninja Sasuke 2, 0,25 s de golpe a los
# 3:23) obligarían a acelerones de casi un 5 % (un «guau» en el tono), y esos se cortan como en la opción de cortes
MARGEN_ESTIRAR = 0.02      # lo que puede variar la velocidad del castellano estirado alrededor de su media
SALTO_ESTIRAR = 0.10       # s de desfase que no caben en ese margen: a partir de aquí, un corte en vez de estirar


def estirado_deriva(t, o, dur):
    """Curva continua para estirar el castellano y los saltos que se cortan. De los desfases de los cambios de plano
    que encajan (t, o), sin los sueltos (a más de 60 ms de la mediana de ±SUAVIZADO_DERIVA s), su mediana de
    ±SUAVIZADO_DERIVA s (que deja los saltos de golpe) en nudos cada segundo: la curva la sigue con la velocidad dentro de
    la media ±MARGEN_ESTIRAR; lo que no cabe se recupera en los nudos siguientes o, si son SALTO_ESTIRAR s o más, es un
    salto y abre un tramo nuevo. Luego se suaviza (media de ±5 s: el desfase se mueve a saltitos de fotograma, y cada
    uno cambiaría el tono un instante) y el nivel de cada tramo es la mediana de lo que le falta a la curva.
    Devuelve (curva [(t del doblaje, desfase continuo)], tramos [[inicio, fin, nivel]], t y o sin los sueltos)."""
    med = lambda tt, oo, x: np.median(oo[np.abs(tt - x) <= SUAVIZADO_DERIVA])
    bien = np.abs(o - np.array([med(t, o, x) for x in t])) <= 0.06
    t, o = t[bien], o[bien]
    s = np.array([med(t, o, x) for x in t])
    k = float(np.polyfit(t, s, 1)[0])
    nudos = np.arange(0.0, dur, 1.0)
    if dur - nudos[-1] < 0.5:       # sin un último tramo de milésimas: su pendiente se dispararía
        nudos[-1] = dur
    else:
        nudos = np.append(nudos, dur)
    y = np.interp(nudos, t, s)
    c, nivel, saltos = np.empty(len(nudos)), 0.0, []
    c[0] = y[0]
    for j in range(1, len(nudos)):
        h = nudos[j] - nudos[j - 1]
        quiere = y[j] - c[j - 1] - nivel
        paso = min(max(quiere, (k - MARGEN_ESTIRAR) * h), (k + MARGEN_ESTIRAR) * h)
        if abs(quiere - paso) >= SALTO_ESTIRAR:
            nivel += quiere - paso
            saltos.append((nudos[j - 1] + nudos[j]) / 2)
        c[j] = c[j - 1] + paso
    c = np.convolve(np.pad(c, 5, mode="edge"), np.ones(11) / 11, mode="valid")
    tramo = np.searchsorted(saltos, t)
    tramos = []
    for i in range(len(saltos) + 1):
        m = tramo == i
        if m.any():
            tramos.append([float(t[m][0]), float(t[m][-1]),
                           float(np.median(o[m] - np.interp(t[m], nudos, c)))])
    return np.column_stack([nudos, c]), tramos, t, o


def deriva_en(t, curva):
    """El desfase continuo de la curva [(t del doblaje, desfase)] en t (fuera de ella, el de su extremo)."""
    c = np.asarray(curva, float)
    return np.interp(t, c[:, 0], c[:, 1])


# remuestreo con la velocidad variable: sinc con ventana de Kaiser, 16 coeficientes y 512 fases (la del cambio de
# velocidad, de hasta un 3 %, cabe de sobra en el corte al 92 %)
TAPS_ESTIRAR, FASES_ESTIRAR = 16, 512


def tabla_estirar():
    k = np.arange(1 - TAPS_ESTIRAR // 2, TAPS_ESTIRAR // 2 + 1)
    x = k[None, :] - (np.arange(FASES_ESTIRAR + 1) / FASES_ESTIRAR)[:, None]
    R = TAPS_ESTIRAR / 2
    h = 0.92 * np.sinc(0.92 * x) * np.i0(8.0 * np.sqrt(np.clip(1 - (x / R) ** 2, 0, None))) / np.i0(8.0)
    return (h / h.sum(1, keepdims=True)).astype(np.float32), k


def estirar_bloques(es, fs, curva, nivel, a, b, pre, bloque=1 << 17):
    """El doblaje estirado siguiendo la curva [(t del doblaje, desfase continuo)] con el nivel de su tramo (en el
    resultado, sin pre: t + desfase + nivel), para las muestras a..b del resultado (contando pre), por bloques: (primera
    muestra, audio). Cada muestra del resultado se busca en el doblaje con la curva al revés y se interpola; fuera de la
    curva, a la velocidad del original; lo que caiga fuera del doblaje, silencio."""
    h, k = tabla_estirar()
    tau, d = np.asarray(curva, float).T
    T = tau + d + nivel
    a_doblaje = lambda x: np.where(x < T[0], x - d[0] - nivel, np.where(x > T[-1], x - d[-1] - nivel,
                                                                        np.interp(x, T, tau)))
    for o in range(a, b, bloque):
        pos = np.clip(a_doblaje((np.arange(o, min(o + bloque, b)) - pre) / fs) * fs,
                      -TAPS_ESTIRAR, len(es) + TAPS_ESTIRAR)
        i0 = np.floor(pos).astype(np.int64)
        fase = np.rint((pos - i0) * FASES_ESTIRAR).astype(np.int64)
        lo, hi = max(int(i0.min()) + k[0], 0), min(int(i0.max()) + k[-1] + 1, len(es))
        # con ceros a los lados (fuera del doblaje, silencio), ningún coeficiente se sale
        ceros = np.zeros((2 * TAPS_ESTIRAR, es.shape[1]), np.float32)
        x = np.concatenate([ceros, np.asarray(es[lo:max(hi, lo)], np.float32), ceros])
        base = i0 - lo + 2 * TAPS_ESTIRAR
        y = np.zeros((len(pos), es.shape[1]), np.float32)
        for j, kk in enumerate(k):
            y += x[base + kk] * h[fase, j][:, None]
        yield o, y


# Con la velocidad variable los cambios de plano no lo ven todo: en un destello (cortes cada 0,125 s) cualquier desfase
# encaja, y con pocos cortes el seguimiento sigue con lo de antes aunque el doblaje cambie (Ninja Sasuke 2, 15:44: se le
# acumulaba +0,7 s en 23 s y luego volvía de golpe; el compañero del usuario lo oyó, y los cortes que solo tienen uno
# del original cerca le daban la razón, 4 a 0). El contenido de la imagen sí lo ve: secuencias de VENTANA_IMAGEN s de
# miniaturas (la imagen y su movimiento) comparadas con el original. Donde lo contradice claramente, manda la imagen
VENTANA_IMAGEN = 3.0       # s de cada secuencia que se compara (una cada segundo)
MARGEN_IMAGEN = 0.05       # parecido del mejor desfase sobre el del mejor a más de 0,25 s: por debajo, no se fía
DESVIO_IMAGEN = 0.15       # s de diferencia con lo de los cambios de plano para corregir...
MIN_VENTANAS_IMAGEN = 5    # ...en al menos tantas ventanas fiables (casi) seguidas


def leer_miniaturas(ruta):
    """(tiempos, fotogramas n x 48 x 64 en gris) que guardó cortes_video (en disco, sin cargarlos), o None."""
    try:
        t = np.load(ruta + ".t.npy")
        x = np.memmap(ruta, np.uint8, "r")
    except (OSError, ValueError):
        return None
    n = min(len(t), len(x) // (48 * 64))
    if n < 100:
        return None
    t, x = t[:n], x[:n * 48 * 64].reshape(n, 48, 64)
    if (np.diff(t) < 0).any():          # (en el orden en que salen; casi siempre ya es el de los tiempos)
        orden = np.argsort(t, kind="stable")
        t, x = t[orden], np.asarray(x)[orden]
    return t, x


def rasgos_imagen(x):
    """Para comparar contenidos, de cada fotograma: la imagen y su cambio respecto al anterior, en 32x24 normalizados
    (media precisión: unos 200 MB por episodio), solo de la zona con imagen: los píxeles que cambian a lo largo del
    vídeo (fuera los bordes fijos, como los decorados a los lados del doblaje de Ninja Sasuke, o negros)."""
    s = np.asarray(x[::10], np.float32).std(0)
    mk = s > 0.25 * np.percentile(s, 95)
    f, c = np.where(mk.mean(1) > 0.3)[0], np.where(mk.mean(0) > 0.3)[0]
    f, c = (f, c) if len(f) >= 8 and len(c) >= 8 else (np.arange(48), np.arange(64))
    img, mov = np.empty((len(x), 24 * 32), np.float16), np.empty((len(x), 24 * 32), np.float16)
    previo = None
    for i in range(0, len(x), 4000):
        y = np.asarray(x[i:i + 4000, f[0]:f[-1] + 1, c[0]:c[-1] + 1], np.float32)
        y = zoom(y, (1, 24 / y.shape[1], 32 / y.shape[2]), order=1).reshape(len(y), -1)
        d = np.diff(y, axis=0, prepend=y[:1] if previo is None else previo[None])
        previo = y[-1]
        for dst, v in ((img, y), (mov, d)):
            v = v - v.mean(1, keepdims=True)
            dst[i:i + len(v)] = v / (np.linalg.norm(v, axis=1, keepdims=True) + 1e-6)
    return img, mov


def contenido_deriva(td, xd, to, xo, desfase):
    """Desfase del contenido de la imagen cada segundo: cada VENTANA_IMAGEN s del doblaje (td, xd) frente al original
    (to, xo, en el tiempo con el que se mide), buscado en ±1,5 s de desfase(t) fotograma a fotograma. Parecido: la media
    de las correlaciones de imagen y de movimiento. Devuelve [(t, desfase, el de desfase(t), parecido, margen)]."""
    Id, Md = rasgos_imagen(xd)
    Io, Mo = rasgos_imagen(xo)
    paso = float(np.median(np.diff(to)))
    out = []
    for w0 in np.arange(max(td[0], 0.0), td[-1] - VENTANA_IMAGEN, 1.0):
        i0, i1 = np.searchsorted(td, [w0, w0 + VENTANA_IMAGEN])
        if i1 - i0 < 10:
            continue
        La = float(desfase(w0 + VENTANA_IMAGEN / 2))
        Ls = La + np.arange(-1.5, 1.5 + paso / 2, paso)
        j0, j1 = np.searchsorted(to, [td[i0] + Ls[0] - paso, td[i1 - 1] + Ls[-1] + paso])
        if j1 - j0 < 10:
            continue
        f32 = lambda a: np.asarray(a, np.float32)
        G = f32(Id[i0:i1]) @ f32(Io[j0:j1]).T + f32(Md[i0:i1]) @ f32(Mo[j0:j1]).T
        j = np.clip(np.searchsorted(to, td[i0:i1, None] + Ls[None, :]), j0 + 1, j1 - 1)
        j = np.where(np.abs(to[j - 1] - (td[i0:i1, None] + Ls)) < np.abs(to[j] - (td[i0:i1, None] + Ls)), j - 1, j)
        S = G[np.arange(i1 - i0)[:, None], j - j0].mean(0) / 2
        b = int(np.argmax(S))
        lejos = S[np.abs(Ls - Ls[b]) > 0.25]
        out.append((w0 + VENTANA_IMAGEN / 2, Ls[b], La, S[b], S[b] - (lejos.max() if len(lejos) else 0.0)))
    return np.array(out).reshape(-1, 5)


def corregir_con_imagen(t, o, e, ref, cont):
    """Los desfases de los cambios de plano que encajan (t, o) con lo que dice la imagen (contenido_deriva, medida
    alrededor de ellos): donde discrepa más de DESVIO_IMAGEN en MIN_VENTANAS_IMAGEN ventanas fiables casi seguidas y
    los cambios de plano del doblaje que solo tienen uno del original cerca no le quitan la razón (e, ref), sus medidas
    sustituyen a las de los cortes en ese trozo. Devuelve (t, o, [(desde, hasta, desvío mínimo, máximo)])."""
    if not len(cont):
        return t, o, []
    dev = cont[:, 1] - cont[:, 2]
    mala = (cont[:, 4] >= MARGEN_IMAGEN) & (np.abs(dev) > DESVIO_IMAGEN)
    trozos, i = [], 0
    while i < len(cont):
        if not mala[i]:
            i += 1
            continue
        j = ult = i
        while j + 1 < len(cont) and mala[j + 1:j + 4].any():
            j += 1
            ult = j if mala[j] else ult
        if mala[i:ult + 1].sum() >= MIN_VENTANAS_IMAGEN:
            if trozos and cont[i, 0] - cont[trozos[-1][1], 0] < 6:      # con un hueco corto, uno solo (en el hueco
                trozos[-1] = (trozos[-1][0], ult)                         # quedaban encajes falsos de un destello)
            else:
                trozos.append((i, ult))
        i = ult + 1
    hechos = []
    for i, j in trozos:
        a, b = cont[i, 0], cont[j, 0]
        dz = np.interp(e, cont[i:j + 1, 0], dev[i:j + 1])
        a_favor = en_contra = 0
        for tc, d in zip(e[(e >= a - 1.5) & (e <= b + 1.5)], dz[(e >= a - 1.5) & (e <= b + 1.5)]):
            La = float(np.interp(tc, cont[:, 0], cont[:, 2]))
            cerca = ref[np.abs(ref - (tc + La)) < 1.2] - tc
            if not (len(cerca) == 1 or (len(cerca) == 2 and np.ptp(cerca) > 0.6)):
                continue            # más cortes del original cerca: un encaje así no dice nada
            con_cortes, con_imagen = np.abs(cerca - La).min() < 0.05, np.abs(cerca - La - d).min() < 0.05
            en_contra += con_cortes and not con_imagen
            a_favor += con_imagen and not con_cortes
        if en_contra > a_favor:
            continue
        fuera = (t < a - 1.5) | (t > b + 1.5)
        nuevos = cont[i:j + 1][cont[i:j + 1, 4] >= MARGEN_IMAGEN]
        t = np.concatenate([t[fuera], nuevos[:, 0]])
        o = np.concatenate([o[fuera], nuevos[:, 1]])
        orden = np.argsort(t, kind="stable")
        t, o = t[orden], o[orden]
        hechos.append((float(a), float(b), float(dev[i:j + 1][mala[i:j + 1]].min()),
                       float(dev[i:j + 1][mala[i:j + 1]].max())))
    return t, o, hechos


def medir_deriva(tm, sm, te, se, p, estirar=False, imagen=None):
    """Medida con los cambios de plano cuando la velocidad del doblaje varía (VHS): curva gruesa (cadena_deriva), cada
    cambio de plano (seguir_cortes), la velocidad media para el original y tramos para lo que varía (tramos_deriva).
    Solo vale si la cadena reúne al menos el 25 % de las ventanas y cubre el 70 % del doblaje y encaja la mitad de sus
    cambios de plano (Ninja Sasuke 2: 45 %, 99 % y 79 %; el mismo doblaje frente al original al revés: 5 %, 52 % y 26 %).
    estirar: en vez de tramos, una curva para estirar el castellano (curva_deriva); el original no se toca.
    imagen: ((tiempos, miniaturas) del doblaje, (tiempos, miniaturas) del original): lo de los cambios de plano se
    corrige con el contenido de la imagen donde lo contradice (corregir_con_imagen).
    Devuelve (tramos [inicio, fin, desfase], desfases, velocidad para el original, puntos, trechos del doblaje
    [(desde, hasta, desvío)]: sin poder comprobar (desvío None) o corregidos con la imagen, curva o None) o None."""
    e, ref = cortes_unicos(tm, sm), te[se > 0.15]
    if len(e) < 30 or len(ref) < 30:
        return None
    n_v, cadena = cadena_deriva(senal_cortes(tm, sm), senal_cortes(te, se))
    if len(cadena) < 3:
        return None
    cubre = (cadena[-1, 0] - cadena[0, 0]) / max(e[-1] - e[0], 1.0)
    Lc, encaja, r = seguir_cortes(e, ref, cadena)
    if len(cadena) < 0.25 * n_v or cubre < 0.7 or encaja.mean() < 0.5:
        return None
    # trechos de 10 s o más en los que casi nada encaja (de cada 10 cambios de plano, menos de 3): sus encajes casuales
    # no cuentan y siguen con el desfase de al lado. No se cambian por el audio original como hace sin_encaje: en un
    # doblaje así no se distingue otro montaje de una escena ilegible (Ninja Sasuke 2: una pelea con destellos y
    # fotogramas fundidos encajaba un 31 %, unas transiciones de mirilla un 0 %, y eran el mismo montaje; un minuto de
    # otra escena metido a propósito encajaba un 50 %, porque el seguimiento se mueve un poco a por cortes casuales).
    # Se avisa de ellos
    dudoso = np.convolve(encaja.astype(float), np.ones(10) / 10, mode="same") < 0.3
    huecos, i = [], 0
    while i < len(e):
        j = i
        while dudoso[i] and j + 1 < len(e) and dudoso[j + 1]:
            j += 1
        if dudoso[i] and e[j] - e[i] >= 10:
            huecos.append((float(e[i]), float(e[j])))
        i = j + 1
    vale = encaja.copy()
    for a, b in huecos:
        vale &= (e < a) | (e > b)
    t, o, r = e[vale], r[vale] - e[vale], r[vale]
    corregidos = []
    if imagen is not None:
        (td, xd), (to, xo) = imagen
        suave = np.array([np.median(o[np.abs(t - x) <= SUAVIZADO_DERIVA]) for x in t])
        cont = contenido_deriva(td, xd, to, xo, lambda x: np.interp(x, t, suave))
        t, o, corregidos = corregir_con_imagen(t, o, e, ref, cont)
        r = t + o
        for a, b, d0, d1 in corregidos:
            p(f"Corregido con la imagen: doblaje {mmss(a)}-{mmss(b)}, de {d0 * 1000:+.0f} a {d1 * 1000:+.0f} ms "
              "(ahí los cambios de plano no bastaban: destellos o pocos cortes)")
        # lo que la imagen ha medido ya no queda sin comprobar
        huecos = [(a, b) for a, b in huecos if not any(c0 - 2 <= a and b <= c1 + 2 for c0, c1, _, _ in corregidos)]
    k = float(np.polyfit(t, o, 1)[0])
    if abs(k) > 0.10:
        return None
    # la velocidad de verdad, a ratos: la pendiente de cada minuto con cambios de plano de sobra
    ritmos = [np.polyfit(t[m], r[m], 1)[0] - 1 for x in np.arange(t[0], t[-1] - 60, 30)
              if (m := (t >= x) & (t < x + 60)).sum() >= 10]
    if estirar:
        # opción del usuario para este caso: el castellano se estira siguiendo la curva y el original no se toca
        curva, segs, t, o = estirado_deriva(t, o, float(tm.max()))
        L, vel, n = [sg[2] for sg in segs], Fraction(1), len(segs) - 1
        como = (f"el castellano se estira siguiendo la del original (su velocidad, dentro de la media "
                f"±{MARGEN_ESTIRAR * 100:.0f} %)"
                + (f" y {n} salto{'s' if n > 1 else ''} de verdad (fotogramas que faltan o sobran) se corta"
                   f"{'n' if n > 1 else ''}" if n else ", sin cortes") + "; el original no se toca")
    else:
        curva, vel = None, Fraction(1 + k).limit_denominator(200000)
        o = (t + o) / float(vel) - t                   # ya con el original a la velocidad media
        idx = tramos_deriva(t, o)
        L = [float(np.median(o[a:b + 1])) for a, b in idx]
        segs = [[float(t[a]), float(t[b]), Li] for (a, b), Li in zip(idx, L)]
        como = (f"el original se adapta a esa media y lo que varía se reparte en {len(segs)} tramos de "
                f"±{TOL_DERIVA * 1000:.0f} ms (cortes pequeños en el castellano)")
    pct = lambda x, f: format(x * 100, f).replace(".", ",")
    p(f"La velocidad del doblaje no es fija (VHS o emisión comprimida en tiempo): se sigue cambio de plano a cambio "
      f"de plano. Encajan {encaja.sum()} de sus {len(e)} cambios de plano; va de media un {pct(abs(k), '.2f')} % más "
      f"{'rápido' if k > 0 else 'lento'} que el original"
      + (f" (casi siempre entre {pct(np.percentile(ritmos, 10), '+.1f')} % y {pct(np.percentile(ritmos, 90), '+.1f')}"
         " %)" if len(ritmos) >= 5 else "")
      + f"; {como}"
      + (f". {len(huecos)} trecho{'s' if len(huecos) > 1 else ''} sin poder comprobar con la imagen "
         f"(va{'n' if len(huecos) > 1 else ''} con el desfase de al lado)" if huecos else ""))
    zonas = [(a, b, None) for a, b in huecos] + [(a, b, (d0, d1)) for a, b, d0, d1 in corregidos]
    return segs, L, vel, np.column_stack([t, o, np.ones(len(t))]), sorted(zonas), curva


def medir_video(es_path, en_path, st_es, st_en, p, deco="cpu", vel=None, estirar=False):
    """Tramos, deriva y desfases medidos con los cambios de plano de los dos vídeos.
    vel: velocidad del doblaje frente al original (Fraction) o None para averiguarla aquí.
    estirar: si la velocidad del doblaje resulta variable, el castellano se estira siguiendo una curva (medir_deriva).
    Al leer los cambios de plano se guardan de paso miniaturas de los dos vídeos en una carpeta temporal, por si la
    velocidad resulta variable (contenido_deriva); se borran al terminar.
    Devuelve (tramos, k, L, cambios, vel, puntos, zonas con otro montaje, trechos del doblaje sin comprobar o
    corregidos con la imagen, curva, avisos de la comprobación con la imagen); los tiempos del original, ya a la
    velocidad del doblaje."""
    tmp = tempfile.mkdtemp(prefix="miniaturas_")
    try:
        return _medir_video(es_path, en_path, st_es, st_en, p, deco, vel, estirar,
                            (os.path.join(tmp, "doblaje.gris"), os.path.join(tmp, "original.gris")))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _medir_video(es_path, en_path, st_es, st_en, p, deco, vel, estirar, miniaturas):
    p("Leyendo los cambios de plano de los dos vídeos...")
    (gm, tm, sm), (ge, te, se) = cortes_de_ambos(es_path, en_path, st_es, st_en, deco, p, miniaturas)
    if vel is None:
        # la misma velocidad o una de las conversiones habituales: con la que más minutos repartidos por todo el
        # episodio caen en el mismo desfase que el de al lado (y mejor encajan). El parecido de un minuto suelto no
        # sirve: con pocos cortes encaja por casualidad en cualquier sitio (Kojak 1x16, doblaje PAL frente a 23,976:
        # 0,72-0,85 a la misma velocidad con desfases disparatados, y a 25/23,976 el primer minuto daba 0,81, que no
        # llegaba, aunque los demás daban 0,94-0,99 todos en el mismo desfase)
        pista = velocidad_por_fps(es_path, en_path) or Fraction(1)
        medida = lambda v: coherencia_video(ventanas_video(gm, senal_cortes(te / float(v), se)))
        candidatas = [Fraction(1)] + sorted(VELOCIDADES, key=lambda v: abs(v - pista))
        med = dict(zip(candidatas, en_paralelo(medida, candidatas)))
        n1, s1 = med[Fraction(1)]
        # vale si al menos 3 minutos coinciden con sus vecinos, encajan bien (parecido medio >= 0,6) y supera de
        # lejos a la misma velocidad
        claro = lambda m: m[0] >= 3 and m[1] >= 0.6 * m[0] and m[1] >= s1 + 1.0
        mejor = max(med, key=lambda v: med[v][1])
        vel = mejor if mejor != 1 and claro(med[mejor]) else Fraction(1)
        rara = ""
        if vel == 1 and n1 < 3:
            # ni la misma velocidad ni una conversión habitual: cualquier otra entre -10 % y +10 %, y se afina con
            # toda la película (la señal entera no admite ni 10 ppm de error)
            p("Velocidad: los cambios de plano no encajan a la misma velocidad ni con ninguna conversión habitual; "
              "se busca cualquier otra...")
            v, c_env = barrido_velocidad(gm, lambda v: senal_cortes(te / v, se))
            if c_env >= 0.3:
                ws = list(np.arange(v - 6e-5, v + 6e-5, 4e-6))
                finos = dict(zip(ws, en_paralelo(medida, ws)))
                w = max(finos, key=lambda w: finos[w][1])
                if claro(finos[w]):
                    vel = Fraction(float(w)).limit_denominator(200000)
                    med[vel] = finos[w]
                    rara = " (no es una conversión de fps habitual)"
        if vel != 1:
            n, s = med[vel]
            p(f"Velocidad (por los cambios de plano): {texto_velocidad(vel, es_path, en_path)}{rara}; se adapta el "
              f"original al doblaje (confianza {s / n:.2f}, {n} minutos en el mismo desfase; a la misma velocidad {n1})")
    if vel != 1:
        te = te / float(vel)
        ge = senal_cortes(te, se)
    ev, ref = tm[sm > 0.3], te[se > 0.15]
    lag0, c0 = desfase_video(gm, ge)
    p(f"Desfase inicial aprox. (vídeo): {lag0 * 1000:+.0f} ms (confianza {c0:.2f}); "
      f"cambios de plano: {len(ev)} en el doblaje, {int((se > 0.3).sum())} en el original")
    ev, destellos = sin_destellos(ev)
    if destellos:
        p("Destellos (cambios de plano cada pocos fotogramas) en " + ", ".join(f"{mmss(a)}-{mmss(b)}" for a, b in destellos)
          + " del doblaje: sus cambios de plano no cuentan para medir (encajan con cualquier desfase); va con el "
            "desfase de al lado")
    pts = seguir_video(gm, ge, lag0)
    if len(ev) < 10 or len(ref) < 10 or (pts[:, 2] > 0.6).mean() < 0.2:
        # casi ninguna ventana encaja de sobra: quizá la velocidad del doblaje no es fija (VHS). Con las miniaturas,
        # también se compara el contenido de la imagen (las del original, en el tiempo con el que se mide)
        md, mo = leer_miniaturas(miniaturas[0]), leer_miniaturas(miniaturas[1])
        imagen = (md, (mo[0] / float(vel), mo[1])) if md and mo else None
        deriva = medir_deriva(tm, sm, te, se, p, estirar, imagen)
        md = mo = imagen = None         # (sueltan los archivos para poder borrarlos)
        if deriva is None:
            raise RuntimeError("los vídeos tampoco coinciden: ¿es el mismo episodio?")
        segs, L, v_media, pts, dudosas, curva = deriva
        return segs, 0.0, L, (tm, sm, te / float(v_media), se), vel * v_media, pts, [], dudosas, curva, []
    k = 0.0
    for _ in range(3):
        segs = tramos_video(ev, ref, k, niveles_video(pts, ev, ref, k))
        k, L, _n = ajustar(puntos_video(ev, ref, k, segs), segs, k, margen=0.0)
        for sg, Li in zip(segs, L):
            sg[2] = Li
    antes = [sg[:2] for sg in segs]
    segs, L, nuevos = repasar_huecos(segs, L, ev, ref, k)
    segs, L, quitados = sin_idas_y_vueltas(segs, L, ev, ref, k)
    if [sg[:2] for sg in segs] != antes:
        k, L, _n = ajustar(puntos_video(ev, ref, k, segs), segs, k, margen=0.0)
        for sg, Li in zip(segs, L):
            sg[2] = Li
    for a, b, Lg in nuevos:
        p(f"Repaso: entre {mmss(a)} y {mmss(b)} del doblaje no encajaba ninguno de los tramos de al lado; sus "
          f"cambios de plano van a {Lg:+.2f} s y ahí va un tramo con ese desfase")
    for a, b, Lg in quitados:
        p(f"Repaso: {mmss(a)}-{mmss(b)} del doblaje iba a {Lg:+.2f} s, pero sus cambios de plano encajan igual con el "
          f"desfase de los tramos de al lado; va con ellos")
    # comprobación con el contenido de la imagen (revisar_con_imagen)
    confirmados, avisos = [], []
    md, mo = leer_miniaturas(miniaturas[0]), leer_miniaturas(miniaturas[1])
    if md and mo:
        antes = [list(sg) for sg in segs]
        segs, L, confirmados, avisos = revisar_con_imagen(segs, L, k, ev, ref, (md, (mo[0] / float(vel), mo[1])), p,
                                                          niveles_video(pts, ev, ref, k))
        if [sg[:2] for sg in segs] != [sg[:2] for sg in antes]:
            k, L, _n = ajustar(puntos_video(ev, ref, k, segs), segs, k, margen=0.0)
            for sg, Li in zip(segs, L):
                sg[2] = Li
    md = mo = None                  # (sueltan los archivos para poder borrarlos)
    segs, L, zonas = sin_encaje(segs, L, ev, ref, k, confirmados, p)
    return segs, k, L, (tm, sm, te, se), vel, pts, zonas, None, None, avisos


def repasar_huecos(segs, L, ev, ref, k, min_s=10.0):
    """Entre el último cambio de plano que encaja con un tramo y el primero que encaja con el siguiente puede quedar un
    trozo largo donde no encaja ninguno de los dos (Kojak 4x10: la cabecera y los 4 minutos siguientes iban a +1,5/+1,7 s
    y otros 30 s a -34,84, entre un tramo a +1,4 y otro a -34,6; esos desfases no estaban entre los candidatos, el
    seguimiento cambió al de después al principio del trozo y los 36 s que sobraban se quitaban 4 minutos antes de donde
    estaban: el castellano iba adelantado). En un trozo así (al menos min_s s y 6 cambios de plano) se prueban los
    desfases que más se repiten entre sus cambios de plano (hasta 5 s más allá de los de al lado): vale el que hace
    encajar la tanda más larga de cambios de plano seguidos (al menos 6, y el 70 % de los de la tanda: los encajes de
    casualidad salen sueltos), que va como tramo, o alarga el de al lado si su desfase es casi el mismo; y se repite con
    lo que quede a cada lado.
    Devuelve (tramos, desfases, [(desde, hasta, desfase) de los tramos nuevos])."""
    def encajan(t, Lg):
        x = t * (1 + k) + Lg
        i = np.clip(np.searchsorted(ref, x), 1, len(ref) - 1)
        return np.minimum(np.abs(ref[i] - x), np.abs(ref[i - 1] - x)) < 2.5 * SIGMA

    def tanda(m):
        """(primero, último, encajes) de la tanda con más encajes y al menos un 70 % de ellos, o None."""
        idx, mejor = np.where(m)[0], None
        for p0 in range(len(idx)):
            for p1 in range(p0, len(idx)):
                n = p1 - p0 + 1
                if n / (idx[p1] - idx[p0] + 1) >= 0.7 and (mejor is None or n > mejor[2]):
                    mejor = (idx[p0], idx[p1], n)
        return mejor

    def firme(e, m, desde_el_final=False):
        """El primer (o el último) cambio de plano que encaja y abre (o cierra) una tanda de al menos 3 encajes en 4
        seguidos: un encaje suelto de casualidad no marca dónde empieza un tramo (Kojak 4x10, 13:25 del doblaje)."""
        orden = range(len(e) - 1, -1, -1) if desde_el_final else range(len(e))
        for j in orden:
            if m[j]:
                tramo = m[max(j - 3, 0):j + 1] if desde_el_final else m[j:j + 4]
                if tramo.sum() >= min(3, len(tramo)):
                    return float(e[j])
        return None

    unicos = ev[np.concatenate([[True], np.diff(ev) > 0.06])] if len(ev) else ev     # sin los dobles de un fundido
    segs, L, nuevos, i = [list(s) for s in segs], list(L), [], 0
    fijo = [[False, False] for _ in segs]     # bordes ya puestos por el repaso: no se vuelven a recortar
    while i < len(segs) - 1:
        e0 = unicos[(unicos >= segs[i][0]) & (unicos <= segs[i][1])]
        e1 = unicos[(unicos >= segs[i + 1][0]) & (unicos <= segs[i + 1][1])]
        a = segs[i][1] if fijo[i][1] else firme(e0, encajan(e0, L[i]), True)
        b = segs[i + 1][0] if fijo[i + 1][0] else firme(e1, encajan(e1, L[i + 1]))
        if a is None or b is None:
            i += 1
            continue
        hueco = unicos[(unicos > a + 0.1) & (unicos < b - 0.1)]
        if b - a < min_s or len(hueco) < 6:
            i += 1
            continue
        lo, hi = min(L[i], L[i + 1]) - 5, max(L[i], L[i + 1]) + 5
        difs = np.concatenate([ref[(ref >= t * (1 + k) + lo) & (ref <= t * (1 + k) + hi)] - t * (1 + k) for t in hueco])
        h, bb = np.histogram(difs, bins=np.arange(lo, hi + 0.04, 0.04))
        mejor = None
        for Lg in bb[np.argsort(h)[::-1][:20]] + 0.02:        # los 20 desfases más repetidos
            r = tanda(encajan(hueco, Lg))
            if r and r[2] >= 6 and (mejor is None or r[2] > mejor[3]):
                mejor = (float(Lg), r[0], r[1], r[2])
        if mejor is None:
            i += 1
            continue
        Lg, p0, p1, _ = mejor
        e, m = hueco[p0:p1 + 1], encajan(hueco[p0:p1 + 1], Lg)
        Lg = float(np.median([min(ref[np.abs(ref - (t * (1 + k) + Lg)) < 0.1] - t * (1 + k), key=lambda d: abs(d - Lg))
                              for t in e[m]]))
        desde, hasta = firme(e, m) or float(e[0]), firme(e, m, True) or float(e[-1])
        segs[i][1], segs[i + 1][0], fijo[i][1], fijo[i + 1][0] = a, b, True, True
        if min(abs(Lg - L[i]), abs(Lg - L[i + 1])) < MIN_SALTO_VIDEO:
            # es el de al lado, que sigue con unos fotogramas más o menos (Kojak 4x10: la cabecera va a +1,52 hasta
            # 5:18 del doblaje y a +1,60 hasta 6:21, donde empiezan los 36 s que sobran): se alarga hasta ahí
            if abs(Lg - L[i]) <= abs(Lg - L[i + 1]):
                segs[i][1] = hasta
            else:
                segs[i + 1][0] = desde
            continue
        segs.insert(i + 1, [desde, hasta, Lg])
        L.insert(i + 1, Lg)
        fijo.insert(i + 1, [True, True])
        nuevos.append(segs[i + 1])          # (la misma lista: si luego se alarga, se informa hasta donde llega)
        # (sin pasar al siguiente: se vuelve a mirar entre el anterior y el nuevo, y luego entre el nuevo y el siguiente)
    return segs, L, sorted(tuple(s) for s in nuevos)


def sin_idas_y_vueltas(segs, L, ev, ref, k):
    """Un tramo que se va a otro desfase y vuelve al de antes sobra si sus cambios de plano encajan igual de bien con el
    desfase de los de al lado (Kojak 4x10, 33:52 del doblaje: 2 s a -36,5 entre dos a -48,5, con los cambios de plano
    de un fundido, que encajan con los dos; eran 12 s de original metidos y 12 s de castellano quitados).
    Devuelve (tramos, desfases, [(desde, hasta, desfase) de los quitados])."""
    segs, L, quitados, i = list(segs), list(L), [], 1
    while i < len(segs) - 1:
        if (abs(L[i - 1] - L[i + 1]) < MIN_SALTO_VIDEO and min(abs(L[i] - L[i - 1]), abs(L[i] - L[i + 1])) >= MIN_SALTO_VIDEO
                and max(encajan_en_tramo(ev, ref, k, [*segs[i][:2], L[j]])[1] for j in (i - 1, i + 1))
                >= encajan_en_tramo(ev, ref, k, segs[i])[1]):
            quitados.append(tuple(segs[i][:2]) + (L[i],))
            del segs[i], L[i]
        else:
            i += 1
    return segs, L, quitados


# Comprobación con el contenido de la imagen (medida con los cambios de plano y velocidad fija). Los cambios de plano
# solo se comparan con el desfase de su tramo, y la verificación solo contaba los que encajaban: en el Kojak 4x10 salía
# «38,9 ms» con 4 minutos de la cabecera a -34,6 s cuando iban a +1,5 (176 de 978 cambios de plano sin encajar, y
# nada lo decía). Las miniaturas, que ya se guardan al leer los cambios de plano, se comparan con el original en todos
# los desfases del episodio: donde otro encaja claramente mejor durante un rato, se corrige; donde entre dos tramos no
# hay cambios de plano que digan dónde va el salto, la imagen lo acota; y un trozo con pocos cambios de plano que
# encajen («montaje distinto») cuya imagen sí va con su desfase no se cambia por el audio original
GRUPO_IMAGEN = 0.6         # s: desfases a menos de esto se buscan juntos (con 0,3 s más a cada lado)
FIABLE_IMAGEN = 0.05       # parecido del mejor grupo sobre el segundo para fiarse de una ventana...
PISO_IMAGEN = 0.7          # ...y al menos esta parte del parecido típico del episodio (la mediana; como poco 0,3): en
                           # el Kojak 4x10, los encajes de verdad, 0,45-0,85 (mediana 0,68); 3 s del trozo que sobra
                           # (un fundido) daban 0,35 con un desfase y nada con el otro, y acotaban mal el salto
MEJORA_IMAGEN = 0.10       # parecido de más de otro grupo sobre el del tramo para que la ventana diga «otro»
MIN_OTRO_IMAGEN = 8        # ventanas (una por segundo) casi seguidas que dicen «otro» para corregir; desde 4, aviso


def grupos_desfase(L):
    """Los desfases del episodio, agrupados los que están a menos de GRUPO_IMAGEN: [desde, hasta] de cada grupo."""
    out = []
    for x in sorted(L):
        if out and x - out[-1][0] <= GRUPO_IMAGEN:
            out[-1][1] = x
        else:
            out.append([x, x])
    return out


def grupo_de(grupos, x):
    return min(range(len(grupos)), key=lambda g: max(grupos[g][0] - x, x - grupos[g][1], 0.0))


def parecidos_imagen(td, Id, Md, to, Io, Mo, k, grupos):
    """Cada segundo, VENTANA_IMAGEN s del doblaje (td y sus rasgos_imagen) frente al original (to, en el tiempo con
    el que se mide) en cada grupo de desfases (±0,3 s, fotograma a fotograma; el parecido, como en contenido_deriva).
    Devuelve (centros de las ventanas, parecido n x grupos, mejor desfase n x grupos); nan donde el original no llega."""
    paso = float(np.median(np.diff(to)))
    f32 = lambda a: np.asarray(a, np.float32)
    T, S, O = [], [], []
    for w0 in np.arange(max(td[0], 0.0), td[-1] - VENTANA_IMAGEN, 1.0):
        i0, i1 = np.searchsorted(td, [w0, w0 + VENTANA_IMAGEN])
        if i1 - i0 < 6:
            continue
        x = td[i0:i1] * (1 + k)
        Di, Dm = f32(Id[i0:i1]), f32(Md[i0:i1])
        s_, o_ = np.full(len(grupos), np.nan), np.full(len(grupos), np.nan)
        for g, (lo, hi) in enumerate(grupos):
            Ls = np.arange(lo - 0.3, hi + 0.3 + paso / 2, paso)
            Ls = Ls[(x[0] + Ls >= to[0]) & (x[-1] + Ls <= to[-1])]
            if not len(Ls):
                continue
            j0, j1 = np.searchsorted(to, [x[0] + Ls[0] - paso, x[-1] + Ls[-1] + paso])
            j0, j1 = max(j0 - 1, 0), min(j1 + 1, len(to))
            G = Di @ f32(Io[j0:j1]).T + Dm @ f32(Mo[j0:j1]).T
            y = x[:, None] + Ls[None, :]
            j = np.clip(np.searchsorted(to, y), j0 + 1, j1 - 1)
            j = np.where(np.abs(to[j - 1] - y) < np.abs(to[j] - y), j - 1, j)
            sg = G[np.arange(i1 - i0)[:, None], j - j0].mean(0) / 2
            b = int(np.argmax(sg))
            s_[g], o_[g] = sg[b], Ls[b]
        if np.isfinite(s_).any():
            T.append(w0 + VENTANA_IMAGEN / 2)
            S.append(s_)
            O.append(o_)
    return np.array(T), np.array(S).reshape(-1, len(grupos)), np.array(O).reshape(-1, len(grupos))


def revisar_con_imagen(segs, L, k, ev, ref, imagen, p, candidatos=(), calibracion=0.0, apoyo=None):
    """Comprueba los tramos medidos con los cambios de plano contra el contenido de la imagen (parecidos_imagen):
    - dentro de un tramo, MIN_OTRO_IMAGEN ventanas fiables casi seguidas en que otro grupo de desfases encaja
      MEJORA_IMAGEN mejor: ese trozo va a ese desfase (el de sus cambios de plano si encajan, el de un tramo de ese
      grupo, o el de la imagen) y se parte el tramo; con menos (desde 4), aviso;
    - en el hueco entre dos tramos de distinto grupo (donde va el salto), las ventanas que van con uno o con otro lo
      acotan, si están en orden (y, si el doblaje sobra, cabe lo que se quita);
    - los tramos con al menos 5 ventanas fiables y el 60 % con su propio desfase quedan confirmados (sin_encaje).
    imagen: ((tiempos, miniaturas) del doblaje, (tiempos, miniaturas) del original, en el tiempo con el que se mide).
    candidatos: los demás desfases con los que se ha medido (niveles_video), que también se prueban: el seguimiento puede
    haber descartado uno bueno (Kojak 4x10 recortado a 12:20-14:59: el tramo a -36,4 pasó entero al de -49,1, porque
    un encaje casual hacía volver atrás el original y quedó un solo tramo).
    Medido con el audio (la doble medida): calibracion, lo que va la imagen del doblaje desplazada de su sonido en todo
    el episodio (comprobar_con_imagen; los desfases se comparan con la imagen restándoselo); apoyo(desde, hasta,
    desfase): True si el audio confirma ese desfase ahí, y entonces no se corrige: se avisa (con pruebas, el audio es
    más preciso que la imagen). Lo que no tiene pruebas del audio (iba con el desfase de al lado) sí se corrige.
    Devuelve (tramos, desfases, confirmados [(desde, hasta)], avisos)."""
    c0 = float(calibracion)
    segs, L, candidatos = [[s[0], s[1], s[2] - c0] for s in segs], [x - c0 for x in L], [x - c0 for x in candidatos]
    devolver = lambda segs, L, conf, av: ([[s[0], s[1], s[2] + c0] for s in segs], [x + c0 for x in L], conf, av)
    (td, xd), (to, xo) = imagen
    Id, Md = rasgos_imagen(xd[::2])         # (uno de cada dos fotogramas: la mitad de memoria y de tiempo)
    Io, Mo = rasgos_imagen(xo[::2])
    td, to = np.asarray(td[::2]), np.asarray(to[::2])
    grupos = grupos_desfase(list(L) + list(candidatos))
    T, S, O = parecidos_imagen(td, Id, Md, to, Io, Mo, k, grupos)
    del Id, Md, Io, Mo
    segs, L, avisos = [list(s) for s in segs], list(L), []
    if len(T) < 30 or len(grupos) < 2:
        return devolver(segs, L, [], avisos)
    Sn = np.where(np.isfinite(S), S, -1.0)
    n_w = np.arange(len(T))
    alto = Sn.max(1)
    # grupos que encuentran el mismo desfase (a menos de 0,25 s del mejor) y casi el mismo parecido son el mismo
    # candidato (dos grupos vecinos se solapan en sus ±0,3 s): cuenta el primero, y el segundo mejor es otro desfase
    igual = (np.abs(O - O[n_w, np.argmax(Sn, 1)][:, None]) <= 0.25) & (Sn >= alto[:, None] - 0.02)
    mejor = np.argmax(igual, 1)
    segundo = np.where(np.abs(O - O[n_w, mejor][:, None]) > 0.25, Sn, -1.0).max(1)
    piso = max(0.3, PISO_IMAGEN * float(np.median(alto)))
    fiable = (alto - segundo >= FIABLE_IMAGEN) & (alto >= piso)
    va_con = lambda w, g: bool(igual[w, g])
    dentro = lambda sg: np.where((T - VENTANA_IMAGEN / 2 >= sg[0]) & (T + VENTANA_IMAGEN / 2 <= sg[1]))[0]

    def etiqueta(w, g):
        """El grupo que dice la ventana w si es otro que g y encaja claramente mejor; g si va con él; -1 si nada."""
        if not fiable[w]:
            return -1
        if va_con(w, g):
            return g
        return int(mejor[w]) if alto[w] - Sn[w, g] >= MEJORA_IMAGEN else -1

    def otros(i):
        """Los trozos del tramo i que la imagen pone en otro grupo: [(ventanas que lo dicen, primera, última, grupo,
        ventana anterior con el del tramo, la siguiente, índices de las que lo dicen)]."""
        g, idx = grupo_de(grupos, L[i]), dentro(segs[i])
        et = [etiqueta(w, g) for w in idx]
        out, n = [], 0
        while n < len(idx):
            b = et[n]
            if b in (g, -1):
                n += 1
                continue
            m = ult = n
            neutras = 0
            while m + 1 < len(idx) and et[m + 1] in (b, -1) and neutras < 3:      # (hasta 3 sin decir nada)
                m += 1
                if et[m] == b:
                    ult, neutras = m, 0
                else:
                    neutras += 1
            previa = next((float(T[idx[x]]) for x in range(n - 1, -1, -1) if et[x] == g), None)
            siguiente = next((float(T[idx[x]]) for x in range(ult + 1, len(idx)) if et[x] == g), None)
            ws = [idx[x] for x in range(n, ult + 1) if et[x] == b]
            out.append((len(ws), float(T[idx[n]]), float(T[idx[ult]]), b, previa, siguiente, ws))
            n = ult + 1
        return out

    # 1) trozos de un tramo que la imagen pone en otro desfase: de uno en uno, y se vuelve a mirar
    rechazados = set()          # (los que el audio confirma: se avisa y no se tocan)
    clave = lambda x: (round(x[1], 1), round(x[2], 1))
    for _ in range(20):
        cambio = next(((i, max(r)) for i in range(len(segs))
                       if (r := [x for x in otros(i) if x[0] >= MIN_OTRO_IMAGEN and clave(x) not in rechazados])), None)
        if cambio is None:
            break
        i, (cuantas, a_, b_, g, previa, siguiente, ws) = cambio
        Li = float(np.median(O[ws, g]))
        # el desfase exacto: el de los cambios de plano del trozo que encajan cerca, o el de un tramo de ese grupo
        e = ev[(ev >= a_ - 1.5) & (ev <= b_ + 1.5)]
        cerca = [min(ref[np.abs(ref - (t * (1 + k) + Li)) < 0.12] - t * (1 + k), key=lambda d: abs(d - Li))
                 for t in e if (np.abs(ref - (t * (1 + k) + Li)) < 0.12).any()]
        hermanos = [x for x in list(L) + list(candidatos) if grupo_de(grupos, x) == g and abs(x - Li) < 0.2]
        nuevo = (float(np.median(cerca)) if len(cerca) >= 3
                 else min(hermanos, key=lambda x: abs(x - Li)) if hermanos else Li)
        sg, Lv = segs[i], L[i]
        if apoyo is not None and apoyo(a_ - 1.5, b_ + 1.5, Lv + c0):
            rechazados.add(clave(cambio[1]))
            avisos.append(f"{mmss(a_ - 1.5)}-{mmss(b_ + 1.5)} del doblaje: la imagen va ahí a {nuevo + c0:+.2f} s y el "
                          f"audio a {Lv + c0:+.2f} s ({cuantas} ventanas de imagen); se deja el del audio, que lo confirma: "
                          "conviene comprobarlo")
            continue
        p(f"Corregido con la imagen: {mmss(a_ - 1.5)}-{mmss(b_ + 1.5)} del doblaje iba a {Lv + c0:+.2f} s, pero su "
          f"imagen va a {nuevo + c0:+.2f} s ({cuantas} ventanas lo dicen claramente); va con ese desfase")
        pieza = [a_ if previa is not None else sg[0], b_ if siguiente is not None else sg[1], nuevo]
        piezas = ([[sg[0], previa, Lv]] if previa is not None else []) + [pieza] +                  ([[siguiente, sg[1], Lv]] if siguiente is not None else [])
        segs[i:i + 1], L[i:i + 1] = piezas, [x[2] for x in piezas]
        # si va casi con el de al lado, era su final o su principio: se alarga ese (con su desfase, el medido)
        j = segs.index(pieza)
        for v in (j + 1, j - 1):
            if 0 <= v < len(segs) and pieza in segs and abs(L[v] - nuevo) < MIN_SALTO_VIDEO:
                j = segs.index(pieza)
                segs[v][0 if v > j else 1] = pieza[0 if v > j else 1]
                del segs[j], L[j]
    for i in range(len(segs)):
        for cuantas, a_, b_, *_ in otros(i):
            if cuantas >= 4 and clave((cuantas, a_, b_)) not in rechazados:
                avisos.append(f"{mmss(a_ - 1.5)}-{mmss(b_ + 1.5)} del doblaje: la imagen parece ir ahí con otro "
                              f"desfase ({cuantas} ventanas), conviene comprobarlo")
    # 2) dónde va el salto entre dos tramos de distinto grupo
    for i in range(len(segs) - 1):
        g0, g1 = grupo_de(grupos, L[i]), grupo_de(grupos, L[i + 1])
        if g0 == g1:
            continue
        idx = np.where((T > segs[i][1]) & (T < segs[i + 1][0]))[0]
        uno = [float(T[w]) for w in idx if fiable[w] and va_con(w, g0) and Sn[w, g0] - Sn[w, g1] >= MEJORA_IMAGEN]
        otro = [float(T[w]) for w in idx if fiable[w] and va_con(w, g1) and Sn[w, g1] - Sn[w, g0] >= MEJORA_IMAGEN]
        x0 = max(uno) if uno else segs[i][1]
        x1 = min(otro) if otro else segs[i + 1][0]
        if (not uno and not otro) or (uno and otro and max(uno) > min(otro)) or x1 - x0 < -(L[i + 1] - L[i]) - 1.0:
            continue        # (desordenadas, o no cabría lo que sobra: no se toca)
        if x0 > segs[i][1] + 1.0 or x1 < segs[i + 1][0] - 1.0:
            p(f"Acotado con la imagen: el salto de {L[i + 1] - L[i]:+.2f} s, que podía ir entre {mmss(segs[i][1])} y "
              f"{mmss(segs[i + 1][0])} del doblaje, va entre {mmss(x0)} y {mmss(x1)}")
            segs[i][1], segs[i + 1][0] = x0, x1
    # 3) los tramos que la imagen confirma
    confirmados, n_ok, n_fiables = [], 0, int(fiable.sum())
    for i, sg in enumerate(segs):
        g = grupo_de(grupos, L[i])
        et = [etiqueta(w, g) for w in dentro(sg)]
        ok, total = sum(1 for x in et if x == g), sum(1 for x in et if x != -1)
        n_ok += ok
        if ok >= 5 and ok >= 0.6 * total:
            confirmados.append((sg[0], sg[1]))
    p(f"Comprobación con la imagen: {n_fiables} de {len(T)} ventanas de {VENTANA_IMAGEN:.0f} s se pueden comparar; "
      f"{n_ok} van con el desfase de su tramo")
    return devolver(segs, L, confirmados, avisos)


def encajan_en_tramo(ev, ref, k, sg):
    """(cambios de plano del doblaje en el tramo [inicio, fin, desfase], cuántos encajan con su desfase)."""
    e = ev[(ev >= sg[0]) & (ev <= sg[1])]
    if not len(e) or len(ref) < 2:
        return len(e), 0
    p_ = e * (1 + k) + sg[2]
    i = np.clip(np.searchsorted(ref, p_), 1, len(ref) - 1)
    return len(e), int((np.minimum(np.abs(ref[i] - p_), np.abs(ref[i - 1] - p_)) < 2.5 * SIGMA).sum())


def sin_encaje(segs, L, ev, ref, k, confirmados=(), p=print):
    """Tramos con otro montaje en el doblaje (Kojak 2x02: el resumen del capítulo anterior, con otras escenas y en otro
    orden): casi ninguno de sus cambios de plano encaja con su desfase (el 7 %, frente al 100 % del resto), que es una
    casualidad, y el castellano quedaba ahí descolocado. Se quitan y su sitio en el resultado va con el audio original.
    Devuelve (tramos, desfases, zonas): cada zona, dict(z0, z1: dónde va en el resultado, en el tiempo del original ya
    a la velocidad del doblaje; a, b: dónde estaba en el doblaje; n, m: cambios de plano y cuántos encajaban)."""
    calidad = [encajan_en_tramo(ev, ref, k, sg) for sg in segs]
    # lo que encaja un tramo normal: la mediana ponderada por cambios de plano (con la media, el propio tramo malo de
    # 99 cortes la bajaba y el de 26 s al 36 % pasaba por bueno)
    orden = sorted((m / n, n) for n, m in calidad if n)
    acum, medio = 0, 1.0
    for r_, n in orden:
        acum += n
        if acum >= sum(n for _, n in orden) / 2:
            medio = r_
            break
    malos = [i for i, (n, m) in enumerate(calidad) if n >= 8 and m / n < min(0.4, 0.5 * medio)]
    # (los que la imagen confirma no son otro montaje: Kojak 4x10, 33:04, encajaban 8 de 21 cambios de plano por un
    # fundido y la imagen iba con su desfase de principio a fin; eran 68 s de inglés)
    for i in [i for i in malos if tuple(segs[i][:2]) in set(map(tuple, confirmados))]:
        p(f"Comprobado con la imagen: {mmss(segs[i][0])}-{mmss(segs[i][1])} del doblaje solo encaja "
          f"{calidad[i][1]} de sus {calidad[i][0]} cambios de plano, pero su imagen va con ese desfase: no es otro montaje")
        malos.remove(i)
    if not malos or len(malos) == len(segs):
        return segs, L, []
    buenos = [i for i in range(len(segs)) if i not in malos]
    zonas, i = [], 0
    while i < len(malos):
        j = i
        while j + 1 < len(malos) and malos[j + 1] == malos[j] + 1:
            j += 1
        a_, b_ = malos[i], malos[j]
        ant = max((x for x in buenos if x < a_), default=None)
        sig = min((x for x in buenos if x > b_), default=None)
        zonas.append(dict(z0=segs[ant][1] * (1 + k) + L[ant] if ant is not None else 0.0,
                          z1=segs[sig][0] * (1 + k) + L[sig] if sig is not None else float("inf"),
                          a=segs[a_][0], b=segs[b_][1], n=sum(calidad[x][0] for x in range(a_, b_ + 1)),
                          m=sum(calidad[x][1] for x in range(a_, b_ + 1))))
        i = j + 1
    return [segs[x] for x in buenos], [L[x] for x in buenos], zonas


def sin_microexcursiones(segs, L, dur_max=3.0, salto_max=0.15, vuelta=0.03):
    """Tramos de menos de dur_max s con otro desfase (menos de salto_max) que vuelven al de antes: unos fotogramas de
    más y de menos de una captura de TV (Godzilla 1x09: +76 ms y -83 ms en medio segundo, +68 y -72 en un segundo).
    Cortar dos veces el doblaje, sin silencio, se oiría más que ir un par de fotogramas desfasado ese rato: se quitan."""
    segs, L = [list(s) for s in segs], list(L)
    i = 1
    while i < len(L) - 1:
        if (segs[i][1] - segs[i][0] < dur_max and abs(L[i] - L[i - 1]) < salto_max
                and abs(L[i + 1] - L[i - 1]) < vuelta):
            segs[i - 1][1] = segs[i + 1][1]
            del segs[i:i + 2], L[i:i + 2]
        else:
            i += 1
    for sg, Li in zip(segs, L):
        sg[2] = Li
    return segs, L


def punto_entre(db, lo, hi, salto):
    """Dónde cortar un salto de desfase que está entre dos cambios de plano del doblaje (lo, hi).
    Si el doblaje sobra, lo que se quita tiene que caber ahí; un salto pequeño (fotogramas sueltos)
    se lleva al silencio más cercano, como en la medida con audio: unos ms de más no se notan."""
    quita = max(-salto, 0.0)
    a, b = lo + quita / 2, hi - quita / 2
    if abs(salto) <= 0.3:
        a, b = a - 2.5, b + 2.5
    if b <= a:
        a = b = (lo + hi) / 2
    return punto_silencio(db, (a + b) / 2, max((b - a) / 2, 0.05))


# Medida con la imagen: el castellano va donde va su imagen, pero dentro del propio archivo del doblaje el sonido puede ir
# desfasado de la imagen (una grabación de TV: Kojak 4x10, de Popular TV en AVI, 180 ms tarde, y al principio se oía
# en inglés lo que luego repetía el castellano). Aunque los dos audios apenas se parezcan (otra mezcla), lo poco que
# comparten (música, golpes) cae siempre en el mismo desplazamiento respecto a donde lo pone la imagen
BANDA_AV = (60, 300)       # Hz: donde más comparten dos audios con mezclas distintas (Kojak 4x10: 28 ventanas, del
                           # principio al final; con toda la banda, 12 y solo del principio)
MIN_AV = 0.04              # s: un desfase menor (un fotograma) no se toca


def ventanas_sonido(es8, en8, tramos, largo=8.0, paso=4.0):
    """Ventanas de 8 s cada 4 s de cada tramo del doblaje (es8, mono a AR) frente al original (en8, mono a AR, ya a la
    velocidad del resultado) donde las pone la imagen (tramos: [(desde, hasta, desfase)] en s del doblaje; desfase hasta
    el resultado sin el retraso del original), en ±1 s y en la banda BANDA_AV. Devuelve las que se parecen algo
    (> 0,08): array [centro, tramo, desplazamiento (negativo si su sonido va tarde), parecido]."""
    sos = butter(4, BANDA_AV, btype="band", fs=AR, output="sos")
    a, b = sosfiltfilt(sos, es8).astype(np.float32), sosfiltfilt(sos, en8).astype(np.float32)
    W, B, out = int(largo * AR), AR, []
    for i, (s0, s1, desf) in enumerate(tramos):
        for t0 in np.arange(s0, s1 - largo, paso):
            i0, o0 = int(t0 * AR), int((t0 + desf(t0 + largo / 2)) * AR) - B
            if o0 < 0 or o0 + W + 2 * B > len(b) or i0 + W > len(a):
                continue
            x, y = a[i0:i0 + W], b[o0:o0 + W + 2 * B]
            nx = float(np.linalg.norm(x))
            if nx < 1e-4:
                continue
            cs = np.concatenate([[0.0], np.cumsum(y.astype(np.float64) ** 2)])
            cc = fftconvolve(y, x[::-1], mode="valid") / (np.sqrt(np.maximum(cs[W:] - cs[:-W], 1e-12)) * nx)
            j = int(np.argmax(cc))
            if cc[j] > 0.08:
                out.append((t0 + largo / 2, i, (j - B) / AR, float(cc[j])))
    return np.array(out).reshape(-1, 4)


def pico_sonido(v, minimo=10, solape=1.0):
    """El desplazamiento que más se repite entre las ventanas v (filas de ventanas_sonido) si lo dicen al menos `minimo`
    y el triple de las que caerían ahí por casualidad (en ±40 ms de ±1 s, un 4 %): (desplazamiento, cuántas lo dicen,
    cuáles) o None. solape: cuántas ventanas seguidas comparten el mismo sonido (largo / paso): no son pruebas
    distintas, así que `minimo` cuenta trozos de sonido distintos (Diagnóstico asesinato 6x04 medido con la imagen: 13
    ventanas de 6 s cada 2 s, en un trecho sin nada en común con el original, cayeron en +309 ms por casualidad, unos 4
    trozos de sonido con parecidos de 0,12-0,18, y ese trozo quedó 307 ms descolocado)."""
    if len(v) < minimo * solape:
        return None
    h, bb = np.histogram(v[:, 2], bins=np.arange(-1.0, 1.0001, 0.02), weights=v[:, 3])
    centro = bb[int(np.argmax(h))] + 0.01
    cerca = np.abs(v[:, 2] - centro) <= 0.04
    if cerca.sum() < max(minimo * solape, 3 * len(v) * 0.04):
        return None
    return float(np.median(v[cerca, 2])), int(cerca.sum()), cerca


def desfase_imagen_sonido(es8, en8, tramos):
    """Desfase entre el sonido y la imagen del doblaje en todo el episodio (ventanas_sonido, pico_sonido), o None.
    Devuelve (desfase en s: negativo si su sonido va tarde, ventanas que lo dicen, ventanas que se parecen algo)."""
    v = ventanas_sonido(es8, en8, tramos)
    r = pico_sonido(v, solape=2.0)          # (ventanas de 8 s cada 4 s)
    return (r[0], r[1], len(v)) if r else None


# ...y puede no ser el mismo en todo el episodio: en el Kojak 4x24 (DVDRip con el audio latino puesto a mano) iba 430 ms
# adelantado hasta el 10:14, 490 hasta el 18, nada del 20 al 26... y no coincidía con los saltos de la imagen: donde al
# vídeo del DVD le faltan unos fotogramas (8:52, 0,2 s) el sonido sigue entero, y ese salto lo descolocaba más. Con un
# único desfase (el más repetido, +431 ms, no llegaba a fiarse) quedaba todo algo desfasado. Si las ventanas de un tramo
# dicen claramente otro desplazamiento, se sigue al sonido en ese tramo (y si cambia dentro del tramo, se parte)
VENTANA_AV_TRAMO = (6.0, 2.0)  # s de cada ventana y cada cuánto, para medirlo por tramos (con 8 s cada 4, del 20 al 26
                              # del 4x24 salía de -82 a +74 ms; con 6 s, -10 limpio)
MIN_AV_TRAMO = 10          # trozos de sonido distintos (ventanas sin solaparse) que tienen que decir lo mismo en un
                           # tramo, o en cada parte si se parte: 30 ventanas de 6 s cada 2 s, unos 60 s (hasta la 1.4.4
                           # eran 10 ventanas, 20 s, y 13 por casualidad descolocaron 307 ms un trozo: pico_sonido)
SOLAPE_AV_TRAMO = VENTANA_AV_TRAMO[0] / VENTANA_AV_TRAMO[1]
AV_VARIABLE = 0.2          # s que tiene que apartarse alguna parte del más repetido para seguir al sonido por tramos:
                           # lo que se nota (4x24: +0,43 a +0,5 s adelantado); en el 4x10, ya corregido, las partes
                           # quedaban a -2/-106/-40 ms del resto y con un único desfase iba bien


def partes_sonido(v, nivel=0):
    """Las partes de un tramo (sus ventanas, en orden) con un mismo desplazamiento del sonido: [(primera, última ventana
    que lo dicen, desplazamiento, cuántas)], o [] si no se sabe. Se parte en dos si cada lado dice claramente uno
    distinto (MIN_SALTO_VIDEO o más) y entre los dos lo dicen al menos MIN_AV_TRAMO ventanas más que sin partir."""
    r = pico_sonido(v, MIN_AV_TRAMO, SOLAPE_AV_TRAMO)
    mejor = None
    n_min = int(round(MIN_AV_TRAMO * SOLAPE_AV_TRAMO))         # (en ventanas)
    if nivel < 4 and len(v) >= 2 * n_min:
        # (aunque el tramo entero no diga nada claro: con dos desplazamientos a medias, ninguno destaca en todo él)
        for k in range(n_min, len(v) - n_min + 1):
            a, b = pico_sonido(v[:k], MIN_AV_TRAMO, SOLAPE_AV_TRAMO), pico_sonido(v[k:], MIN_AV_TRAMO, SOLAPE_AV_TRAMO)
            if (a and b and abs(a[0] - b[0]) >= MIN_SALTO_VIDEO and a[1] + b[1] >= (r[1] if r else 0) + n_min
                    and (mejor is None or a[1] + b[1] > mejor[0])):
                mejor = (a[1] + b[1], k)
    if mejor:
        return partes_sonido(v[:mejor[1]], nivel + 1) + partes_sonido(v[mejor[1]:], nivel + 1)
    if r is None:
        return []
    sel = v[r[2]]
    return [(float(sel[0, 0]), float(sel[-1, 0]), r[0], r[1])]


def seguir_al_sonido(v, L, cortes, db, dur, p):
    """Si el sonido del doblaje no va igual de desfasado de su imagen en todos los tramos (partes_sonido de las
    ventanas_sonido v; los tramos sin ventanas que lo digan, como el más cercano que sí), cada trozo va con su
    desplazamiento: los cambios dentro de un tramo, con un corte en el silencio entre las ventanas de cada lado; y los
    cortes de la imagen que el sonido no tiene (los dos lados quedan a menos de un fotograma), fuera.
    Solo si alguna parte se aparta AV_VARIABLE o más del desplazamiento más repetido del episodio; los tramos sin ventanas
    que lo digan van con ese (o, si no lo hay, con el del tramo medido más cercano).
    Devuelve (L, cortes, partes [(desde, hasta, desplazamiento, ventanas)], el más repetido o None) o None si va igual
    en todo el episodio (desfase_imagen_sonido)."""
    por_tramo = [partes_sonido(v[v[:, 1] == i]) for i in range(len(L))]
    medidos = [i for i, x in enumerate(por_tramo) if x]
    if not medidos:
        return None
    g = pico_sonido(v, solape=SOLAPE_AV_TRAMO)
    comun = g[0] if g else float(np.median([x[2] for i in medidos for x in por_tramo[i]]))
    if all(abs(x[2] - comun) < AV_VARIABLE for i in medidos for x in por_tramo[i]):
        return None
    nL, nc, partes = [], [], []
    for i in range(len(L)):
        if por_tramo[i]:
            ps = por_tramo[i]
        elif g:
            ps = [(None, None, comun, 0)]
        else:                            # sin medida: como el tramo medido más cercano (el de antes, si empatan)
            j = min(medidos, key=lambda j: abs(j - i))
            ps = [(None, None, por_tramo[j][-1 if j < i else 0][2], 0)]
        for k, x in enumerate(ps):
            if k:
                nc.append(punto_entre(db, ps[k - 1][1], x[0], x[2] - ps[k - 1][2]))
            nL.append(L[i] + x[2])
            partes.append(x)
        if i < len(L) - 1:
            nc.append(cortes[i])
    quitados, i = 0, 0
    while i < len(nc):
        if abs(nL[i + 1] - nL[i]) < 0.04:
            nL[i:i + 2] = [(nL[i] + nL[i + 1]) / 2]
            del nc[i]
            quitados += 1
        else:
            i += 1
    if quitados:
        p(f"Siguiendo al sonido: {quitados} corte{'s' if quitados > 1 else ''} de la imagen que el sonido no tiene "
          f"(fotogramas que le faltan al vídeo del doblaje, no a su audio) se quita{'n' if quitados > 1 else ''}")
    return nL, nc, [x for x in partes if x[0] is not None], (comun if g else None)


# Con una guía (la versión original dentro del doblaje) se mide con ella y se daba por hecho que la pista doblada va a la
# par dentro del archivo, y la verificación también se hacía con la guía. No siempre va: en Diagnóstico asesinato S06
# (avi con el castellano de la TDT y la VO de un DVD) el castellano iba de -90 a +180 ms de la VO, distinto en cada
# trozo (quien hizo el avi no dejó las dos pistas a la par), y la verificación daba «0,0 ms»; el usuario lo notó en el
# 6x04 (~200 ms, 02-11-2026). Ahora la propia pista doblada se contrasta con el original donde la pone la guía: lo que
# comparten (música y efectos) dice cuánto se aparta, y si se aparta claramente se corrige por trozos, con cortes en sus
# silencios. Probado a mano en siete episodios de esa serie antes de ponerlo aquí: de 90-180 ms a 0 ms de mediana
CONTRASTE_VENTANA = (15.0, 5.0)  # s de cada ventana y cada cuánto
CONTRASTE_BUSCA = 0.6            # s a cada lado de donde la pone la guía
CONTRASTE_FIABLE = 0.3           # parecido para dar una ventana por buena (con la mezcla o con los graves)
CONTRASTE_FLOJA = 0.2            # por debajo, la ventana no cuenta
CONTRASTE_AMBIGUA = 0.85         # otro pico así de alto a más de 10 ms (un timbre, música con ritmo: picos cada 14-30
                                 # ms casi iguales): la ventana no dice nada (el teléfono del 6x04 se tomaba por -300 ms)
CONTRASTE_CAMBIO = 1.0           # lo que cuesta cambiar de desfase en el recorrido (unas pocas ventanas claras)
CONTRASTE_JUNTAR = 0.015         # s: escalones menores se juntan si el trozo unido sigue apretado (±10 ms): no merece
                                 # la pena un corte por lo que no se nota
CONTRASTE_MIN = 0.015            # s: si ningún trozo se aparta tanto, va a la par de la guía y no se toca
CONTRASTE_MIN_VENTANAS = 10      # menos ventanas buenas: no se puede contrastar
CONTRASTE_LEJOS = 3.0            # s: al verificar, lo que no encaja a ±CONTRASTE_BUSCA se busca hasta aquí
CONTRASTE_LEJOS_SEGUIDAS = 2     # ventanas seguidas (de 15 s cada 5: unos 20 s) para buscarlas tan lejos
CONTRASTE_LEJOS_ENCAJA = 0.4     # parecido para darla por encajada lejos (más que en su sitio: hay más casualidades)
CONTRASTE_CORTO = 0.5            # parecido que tiene que dar la única ventana de un tramo corto para fiarse de ella
CONTRASTE_DUDA = 20.0            # s: si el cambio de un corte nuevo puede estar en cualquier punto de un hueco así (sin
                                 # ventanas buenas de ningún lado), se avisa: va en su silencio más largo, pero no se sabe
CONTRASTE_DUDA_SALTO = 0.040     # s: ...solo si el salto se notaría de caer en otro sitio (22 ms en el 6x04, no)


def curvas_contraste(x, y, ventanas, largo=CONTRASTE_VENTANA[0], busca=CONTRASTE_BUSCA):
    """Para cada ventana (desde, desfase) en s: el parecido de x[desde, desde + largo] (mono a AR, tiempo del doblaje)
    con y (mono a AR, tiempo del resultado sin el retraso del original, como en ventanas_sonido) donde la pone el
    desfase, ±busca. Devuelve (curvas [ventana, ms]: el máximo de cada ms, desplazamiento del pico en ms afinado (nan si
    la ventana no se puede medir)). Positivo: en el original suena más tarde de donde lo pone el desfase."""
    W, B, M = int(largo * AR), int(busca * AR), AR // 1000
    nb = int(round(busca * 1000))
    N = 1 << int(np.ceil(np.log2(W + 2 * B)))
    curvas = np.zeros((len(ventanas), 2 * nb + 1), np.float32)
    picos = np.full(len(ventanas), np.nan)
    for w, (t0, desf) in enumerate(ventanas):
        i0, o0 = int(round(t0 * AR)), int(round((t0 + desf) * AR)) - B
        if i0 < 0 or o0 < 0 or i0 + W > len(x) or o0 + W + 2 * B > len(y):
            continue
        a, b = x[i0:i0 + W].astype(np.float64), y[o0:o0 + W + 2 * B].astype(np.float64)
        na = float(np.sqrt((a ** 2).sum()))
        if na < 1e-6 or b.std() < 1e-7:
            continue
        c = np.fft.irfft(np.fft.rfft(b, N) * np.conj(np.fft.rfft(a, N)), N)[:2 * B + 1]
        cs = np.concatenate(([0.0], np.cumsum(b ** 2)))
        c = c / (np.sqrt(np.maximum(cs[W:W + 2 * B + 1] - cs[:2 * B + 1], 1e-18)) * na)
        k = int(np.argmax(c))
        d = 0.0
        if 0 < k < 2 * B:
            den = c[k - 1] - 2 * c[k] + c[k + 1]
            d = 0.5 * (c[k - 1] - c[k + 1]) / den if den else 0.0
        picos[w] = (k - B + d) / AR * 1000
        cp = np.concatenate((np.full(M // 2, -1.0), c, np.full(M, -1.0)))
        curvas[w] = cp[:(2 * nb + 1) * M].reshape(2 * nb + 1, M).max(axis=1)
    return curvas, picos


def ambigua(c):
    """La curva tiene otro pico casi igual (CONTRASTE_AMBIGUA) a más de 10 ms del mejor, con un valle entre los dos (un
    timbre, música con ritmo): no dice dónde va. (Un solo pico ancho, como el de una envolvente, no es ambiguo.)"""
    k = int(np.argmax(c))
    top = float(c[k])
    picos = np.where((c == maximum_filter(c, size=7)) & (c >= CONTRASTE_AMBIGUA * top))[0]
    for j in picos[np.abs(picos - k) > 10]:
        a, b = sorted((j, k))
        if float(c[a:b + 1].min()) < float(c[j]) - 0.1 * top:
            return True
    return False


def envolvente_grave(x):
    """La envolvente de los graves (40-250 Hz, suavizada a 25 Hz, sin su media de ±1 s): con el tono corregido la onda
    no coincide nunca, pero los golpes de la música y los efectos sí (un doblaje fabricado así: 0,95-0,97, estable a
    ±1 ms; con la onda, 0,04-0,14)."""
    e = sosfiltfilt(butter(2, 25, fs=AR, output="sos"),
                    np.abs(sosfiltfilt(butter(4, (40, 250), btype="band", fs=AR, output="sos"),
                                       np.asarray(x, np.float64))))
    return (e - uniform_filter1d(e, 2 * AR)).astype(np.float32)


def sin_retardo(y, ref):
    """y (el original acelerado sin cambiar el tono) sin el retardo que le ha añadido atempo respecto a ref (el mismo
    original remuestreado, con el que se ha colocado la guía): un doblaje fabricado con el tono corregido salía 10-12 ms
    «adelantado» de su guía en los trozos que iban a la par. Se mide con la envolvente de los graves cada 30 s."""
    ventanas = [(float(t), 0.0) for t in np.arange(5.0, min(len(y), len(ref)) / AR - 25.0, 30.0)]
    if not ventanas:
        return y
    C, picos = curvas_contraste(envolvente_grave(ref), envolvente_grave(y), ventanas)
    ok = (C.max(axis=1) >= 0.5) & np.isfinite(picos)
    if ok.sum() < 3:
        return y
    n = int(round(float(np.median(picos[ok])) / 1000 * AR))
    return y[n:] if n > 0 else np.concatenate([np.zeros(-n, np.float32), y])


def senales_contraste(x, y, envolvente=False):
    """Los pares de señales (doblaje, original) con que se contrasta: la mezcla y los graves (< 250 Hz: la música y los
    golpes, sin la voz); con envolvente (el tono corregido), la envolvente de los graves. Se filtran una vez y se miden
    las ventanas que hagan falta (medir_contraste)."""
    if envolvente:
        return [(envolvente_grave(x), envolvente_grave(y))]
    sos = butter(4, 250, btype="low", fs=AR, output="sos")
    return [(x, y), (sosfiltfilt(sos, x).astype(np.float32), sosfiltfilt(sos, y).astype(np.float32))]


def medir_contraste(pares, ventanas, largo=CONTRASTE_VENTANA[0], busca=CONTRASTE_BUSCA):
    """Las ventanas medidas con cada par de senales_contraste, quitando las ambiguas de cada una. Devuelve (curva que vale
    de cada ventana, su pico en ms, su parecido; 0 si no vale)."""
    senales = [curvas_contraste(a, b, ventanas, largo, busca) for a, b in pares]
    C = np.zeros_like(senales[0][0])
    picos, fuerza = np.full(len(ventanas), np.nan), np.zeros(len(ventanas))
    for w in range(len(ventanas)):
        validas = [(cu[w], pk[w]) for cu, pk in senales if np.isfinite(pk[w]) and not ambigua(cu[w])]
        if validas:
            C[w] = np.max([c for c, _ in validas], axis=0)
            picos[w] = max(validas, key=lambda v: float(v[0].max()))[1]
            fuerza[w] = float(C[w].max())
    return C, picos, fuerza


def recorrido_ms(E, cambio):
    """El desfase (columna, en ms) de cada ventana que da más E en total, pagando `cambio` cada vez que cambia."""
    W, D = E.shape
    dp = E[0].astype(np.float64).copy()
    atras = np.zeros((W, D), np.int32)
    for w in range(1, W):
        k = int(np.argmax(dp))
        usa = dp[k] - cambio > dp
        atras[w] = np.where(usa, k, np.arange(D))
        dp = np.where(usa, dp[k] - cambio, dp) + E[w]
    d = np.zeros(W, np.int32)
    d[-1] = int(np.argmax(dp))
    for w in range(W - 1, 0, -1):
        d[w - 1] = atras[w, d[w]]
    return d


CONTRASTE_SEGUIDAS = 3           # ventanas buenas seguidas y de acuerdo (±5 ms) que hacen trozo aunque el recorrido...
CONTRASTE_APARTE = 0.030         # s ...las haya metido en un trozo del que se apartan tanto (apartar_seguidas)


def apartar_seguidas(trozos, picos, fuerza):
    """Repaso del recorrido: si dentro de un trozo hay CONTRASTE_SEGUIDAS o más ventanas seguidas que dicen lo mismo (±5
    ms) y se apartan CONTRASTE_APARTE o más de él, son un trozo aparte; valen las flojas (CONTRASTE_FLOJA) si al menos
    una es buena. Con la envolvente (el tono corregido) las curvas son anchas y el recorrido apenas distingue -14 de
    -137 ms: en Mortadelo y Filemón 1x01, con 120 ms metidos a propósito del 3:00 al 5:00, el trozo a -14 de antes (una
    ventana buena y dos flojas, todas a -14) se lo tragaba el de -138 y se corregía 120 ms de más."""
    out = []
    for t in trozos:
        d_ms, w, tramos_ = t["d"] * 1000, t["w0"], []
        buena = lambda j: fuerza[j] >= CONTRASTE_FLOJA and np.isfinite(picos[j])
        while w <= t["w1"]:
            if buena(w) and abs(picos[w] - d_ms) >= CONTRASTE_APARTE * 1000:
                j = w
                while (j + 1 <= t["w1"] and buena(j + 1) and abs(picos[j + 1] - d_ms) >= CONTRASTE_APARTE * 1000
                       and abs(picos[j + 1] - float(np.median(picos[w:j + 1]))) <= 5):
                    j += 1
                if j - w + 1 >= CONTRASTE_SEGUIDAS and float(fuerza[w:j + 1].max()) >= CONTRASTE_FIABLE:
                    tramos_.append((w, j))
                w = j + 1
            else:
                w += 1
        if not tramos_:
            out.append(t)
            continue
        bordes = [t["w0"]] + [x for a, b in tramos_ for x in (a, b + 1)] + [t["w1"] + 1]
        for k in range(len(bordes) - 1):
            a, b = bordes[k], bordes[k + 1] - 1
            if b < a:
                continue
            if k % 2:           # una de las seguidas
                out.append(dict(w0=a, w1=b, d=float(np.median(picos[a:b + 1])) / 1000,
                                apoyo=[x for x in range(a, b + 1) if fuerza[x] >= CONTRASTE_FIABLE]))
            else:
                out.append(dict(w0=a, w1=b, d=t["d"], apoyo=[x for x in t["apoyo"] if a <= x <= b]))
    return out


def trozos_contraste(C, picos, fuerza):
    """Trozos seguidos de ventanas con el mismo desplazamiento (recorrido_ms; los escalones de menos de CONTRASTE_JUNTAR
    se juntan si el trozo sigue apretado): [dict(w0, w1, d en s, apoyo: ventanas buenas que lo dicen)]."""
    nb = (C.shape[1] - 1) // 2
    E = C.astype(np.float64) - np.median(C, axis=1, keepdims=True)
    E[fuerza < CONTRASTE_FLOJA] = 0.0
    camino = recorrido_ms(np.maximum(E, 0.0), CONTRASTE_CAMBIO) - nb
    trozos, ini = [], 0
    for w in range(1, len(camino) + 1):
        if w == len(camino) or camino[w] != camino[ini]:
            d = int(camino[ini])
            apoyo = [j for j in range(ini, w) if fuerza[j] >= CONTRASTE_FIABLE and abs(picos[j] - d) <= 4]
            trozos.append(dict(w0=ini, w1=w - 1, d=(float(np.median(picos[apoyo])) if apoyo else float(d)) / 1000,
                               apoyo=apoyo))
            ini = w
    trozos = apartar_seguidas(trozos, picos, fuerza)
    while True:
        mejor = None
        for i in range(len(trozos) - 1):
            dif = abs(trozos[i + 1]["d"] - trozos[i]["d"])
            if dif >= CONTRASTE_JUNTAR:
                continue
            ap = trozos[i]["apoyo"] + trozos[i + 1]["apoyo"]
            if ap:
                med = float(np.median(picos[ap]))
                p10, p90 = np.percentile(picos[ap] - med, [10, 90])
                if p10 < -10 or p90 > 10:
                    continue
                med /= 1000
            else:
                med = (trozos[i]["d"] + trozos[i + 1]["d"]) / 2
            if mejor is None or dif < mejor[0]:
                mejor = (dif, i, ap, med)
        if mejor is None:
            return trozos
        _, i, ap, med = mejor
        trozos[i:i + 2] = [dict(w0=trozos[i]["w0"], w1=trozos[i + 1]["w1"], d=med, apoyo=sorted(ap))]


def contrastar_doblada(x, y, L, cortes, dur, dame_db, envolvente=False, estricto=False):
    """La pista doblada x (mono a AR, tiempo del doblaje) frente al original y (mono a AR, como en ventanas_sonido) donde
    la ponen los tramos medidos (L, cortes: con la guía o con la imagen). Si algún trozo se aparta CONTRASTE_MIN o más,
    cada uno va con su desplazamiento: los cambios dentro de un tramo, con un corte en el silencio entre las ventanas de
    cada lado (dame_db(): niveles de la pista doblada cada 10 ms, solo si hace falta cortar). Un tramo demasiado corto
    para una ventana entera se mide con una a su medida (si se parece CONTRASTE_CORTO o más).
    estricto (medido con la imagen: otra mezcla, menos que compartir): cada trozo necesita 3 ventanas buenas, y un tramo
    sin medida se queda donde lo pone la imagen (no como el de al lado).
    Devuelve (L, cortes, informe): informe = dict(estado "corregido" | "igual" | "sin_medida", n ventanas buenas,
    mediana en s, partes [(desde, hasta, desplazamiento en s, ventanas, nota)] en s del doblaje, nuevos cortes)."""
    largo, paso = CONTRASTE_VENTANA
    ini, fin = limites(cortes, L, dur)
    ventanas, de_tramo = [], []
    for i, (s0, s1) in enumerate(zip(ini, fin)):
        for t0 in np.arange(s0 + 0.5, s1 - largo - 0.5, paso):
            ventanas.append((float(t0), L[i]))
            de_tramo.append(i)
    pares = senales_contraste(x, y, envolvente)
    # los tramos sin ventana entera (7-16 s), con una ventana a su medida
    cortos = {}
    for i, (s0, s1) in enumerate(zip(ini, fin)):
        if i not in de_tramo and s1 - s0 >= 7.0:
            _, pk, fz = medir_contraste(pares, [(s0 + 0.5, L[i])], largo=s1 - s0 - 1.0)
            if fz[0] >= CONTRASTE_CORTO:
                cortos[i] = float(pk[0]) / 1000
    if not ventanas:
        return L, cortes, dict(estado="sin_medida", n=0)
    C, picos, fuerza = medir_contraste(pares, ventanas)
    pares = None
    buenas = fuerza >= CONTRASTE_FIABLE
    n = int(buenas.sum())
    if n < CONTRASTE_MIN_VENTANAS:
        return L, cortes, dict(estado="sin_medida", n=n)
    mediana = float(np.median(picos[buenas])) / 1000
    trozos = trozos_contraste(C, picos, fuerza)
    if estricto:
        for t in trozos:
            if len(t["apoyo"]) < 3:
                t["apoyo"] = []
    if all(abs(t["d"]) < CONTRASTE_MIN or not t["apoyo"] for t in trozos) and             all(abs(d) < CONTRASTE_MIN for d in cortos.values()):
        return L, cortes, dict(estado="igual", n=n, mediana=mediana)
    de_ventana = np.zeros(len(ventanas), int)
    for j, t in enumerate(trozos):
        de_ventana[t["w0"]:t["w1"] + 1] = j
    centro = lambda w: ventanas[w][0] + largo / 2
    apoya = lambda j, w: not isinstance(j, str) and w in trozos[j]["apoyo"]
    db = None
    nL, nc, partes, nuevos, dudas = [], [], [], 0, []
    for i in range(len(L)):
        ws = [w for w in range(len(ventanas)) if de_tramo[w] == i]
        ps = []
        for w in ws:
            if ps and ps[-1][0] == de_ventana[w]:
                ps[-1][1].append(w)
            else:
                ps.append((int(de_ventana[w]), [w]))
        # dentro de un tramo solo se parte si cada lado lo dicen ventanas buenas suyas: en un trecho sin medida el
        # recorrido cambia en cuanto puede, y ese cambio va mejor en el corte que ya hay (Diagnóstico asesinato 6x04:
        # el trozo nuevo partía el tramo 16 s antes de su corte, con sonido, y el cambio de verdad era el corte)
        apoyadas = [(j, wsj) for j, wsj in ps if any(apoya(j, w) for w in wsj)]
        if apoyadas and len(apoyadas) < len(ps):
            juntas = []
            for j, wsj in ps:
                if any(apoya(j, w) for w in wsj) or not juntas:
                    juntas.append((j, list(wsj)))
                else:
                    juntas[-1][1].extend(wsj)
            if not any(apoya(juntas[0][0], w) for w in juntas[0][1]) and len(juntas) > 1:
                juntas[1] = (juntas[1][0], juntas[0][1] + juntas[1][1])
                juntas = juntas[1:]
            ps = juntas
        elif not apoyadas:
            if i in cortos:
                ps = [("corto", ws)]
            elif estricto:
                ps = [("imagen", ws)]
            else:
                # sin ventanas buenas (o corto): como la ventana buena más cercana (la de antes, si empatan)
                buenas_w = [w for t in trozos for w in t["apoyo"]] or list(range(len(ventanas)))
                cerca = min(buenas_w, key=lambda w: (abs(centro(w) - (ini[i] + fin[i]) / 2), -w))
                ps = [(int(de_ventana[cerca]), ws, "vecino")]
        bordes = [ini[i]]
        for k, parte in enumerate(ps):
            j, wsj = parte[0], parte[1]
            d = {"corto": cortos.get(i, 0.0), "imagen": 0.0}[j] if isinstance(j, str) else trozos[j]["d"]
            if k:
                # entre la última ventana buena del trozo de antes y la primera de este (con 3 s de margen: el cambio
                # puede caer dentro de cualquiera de las dos)
                prev_j, prev_ws = ps[k - 1][0], ps[k - 1][1]
                ap_a = [w for w in prev_ws if apoya(prev_j, w)] or prev_ws
                ap_b = [w for w in wsj if apoya(j, w)] or wsj
                lo = max(centro(ap_a[-1]) - 3, ini[i])
                hi = min(centro(ap_b[0]) + 3, fin[i])
                if db is None:
                    db = dame_db()
                nc.append(punto_entre(db, lo, hi, d - trozos[prev_j]["d"]))
                bordes.append(nc[-1]["c"])
                nuevos += 1
                if hi - lo >= CONTRASTE_DUDA and abs(d - trozos[prev_j]["d"]) >= CONTRASTE_DUDA_SALTO:
                    dudas.append((lo, hi, nc[-1]["c"]))
            nL.append(L[i] + d)
            nota = parte[2] if len(parte) > 2 else (j if isinstance(j, str) else "")
            partes.append([None, None, d, sum(1 for w in wsj if apoya(j, w)), nota])
        bordes.append(fin[i])
        for k in range(len(ps)):
            partes[len(partes) - len(ps) + k][:2] = bordes[k], bordes[k + 1]
        if i < len(L) - 1:
            nc.append(cortes[i])
    # tramos que se quedan con el mismo desplazamiento: el corte entre ellos sobra
    i = 0
    while i < len(nc):
        if abs(nL[i + 1] - nL[i]) < 0.001:
            del nL[i + 1], nc[i]
        else:
            i += 1
    # partes seguidas con el mismo desplazamiento (de tramos distintos), juntas en el informe
    unidas = []
    for pt in map(tuple, partes):
        if unidas and abs(unidas[-1][2] - pt[2]) < 1e-9:
            u = unidas[-1]
            unidas[-1] = (u[0], pt[1], pt[2], u[3] + pt[3], u[4] if u[4] == pt[4] else "")
        else:
            unidas.append(pt)
    return nL, nc, dict(estado="corregido", n=n, mediana=mediana, partes=unidas, nuevos=nuevos, dudas=dudas)


def avisos_dudas(inf, de="del castellano"):
    """Avisos de los cortes nuevos del contraste cuyo cambio podía estar en cualquier punto de un hueco largo."""
    return [f"corte {mmss(c)}: el cambio de desfase {de} puede estar en cualquier punto entre {mmss(lo)} y {mmss(hi)} "
            "del doblaje (no hay sonido en común con el original para saberlo); va en el silencio más largo, conviene "
            "escuchar ese trozo" for lo, hi, c in inf.get("dudas", [])]


def texto_contraste(inf, de="del castellano", ref="la guía"):
    """Las líneas del informe que explican el contraste (contrastar_doblada). de: «del castellano», «de la pista 3...»;
    ref: con qué se había colocado («la guía», «su imagen»)."""
    pct = lambda d: (f"{abs(d) * 1000:.0f} ms {'tarde' if d < 0 else 'adelantado'} respecto a {ref}"
                     if abs(d) >= 0.0005 else f"a la par de {ref}")
    if inf["estado"] == "sin_medida":
        return [f"Contraste {de} con el original: se parecen demasiado poco para comprobar que va a la par de "
                f"{ref} ({inf['n']} ventanas buenas); se da por hecho"]
    if inf["estado"] == "igual":
        return [f"Contraste {de} con el original: va a la par de {ref} ({inf['n']} ventanas buenas, "
                f"mediana {inf['mediana'] * 1000:+.0f} ms)"]
    ds = [x[2] for x in inf["partes"]]
    out = [f"Contraste {de} con el original: dentro del doblaje NO va a la par de {ref} (de "
           f"{min(ds) * 1000:+.0f} a {max(ds) * 1000:+.0f} ms según el trozo; {inf['n']} ventanas buenas); se corrige "
           f"por trozos" + (f", con {inf['nuevos']} corte{'s' if inf['nuevos'] != 1 else ''} nuevo"
                            f"{'s' if inf['nuevos'] != 1 else ''} en sus silencios" if inf["nuevos"] else "") + ":"]
    notas = {"corto": " (tramo corto: medido con una sola ventana)",
             "imagen": " (sin medida: se deja donde lo pone la imagen)",
             "vecino": " (sin ventanas propias: como el trozo de al lado)"}
    for a, b, d, nv, nota in inf["partes"]:
        out.append(f"  {mmss(a):>9}-{mmss(b)} del doblaje: iba {pct(d)}"
                   + (notas[nota] if nota in notas else f" ({nv} ventanas)"))
    return out


def verificar_contraste(x, y, L, cortes, en_len, excluir=(), envolvente=False):
    """La pista doblada x (mono a AR), montada con L y los cortes, frente al original y: dict(n ventanas buenas,
    p50 y p90 del desplazamiento que queda en ms (en valor absoluto), por_seg [(ventanas, mediana en ms)] de cada tramo
    colocado, colocación). excluir: [(desde, hasta)] en s del resultado (rellenos con el original)."""
    out, coloc, _ = montar(x.reshape(-1, 1), AR, 0.0, L, cortes, en_len, 0)
    z = out[:, 0]
    out = None
    largo, paso = CONTRASTE_VENTANA
    ventanas = [(float(t0), 0.0) for t0 in np.arange(0.5, len(z) / AR - largo - 0.5, paso)
                if not any(t0 < e1 and t0 + largo > e0 for e0, e1 in excluir)]
    if not ventanas:
        return dict(n=0, por_seg=[], coloc=coloc)
    pares = senales_contraste(z, y, envolvente)
    _, picos, fuerza = medir_contraste(pares, ventanas)
    ok = fuerza >= CONTRASTE_FIABLE
    r = np.abs(picos[ok])
    centros = np.array([t0 + largo / 2 for t0, _ in ventanas])
    por_seg = []
    for a0, a1 in coloc:
        m = ok & (centros > a0 + largo / 2) & (centros < a1 - largo / 2)
        por_seg.append((int(m.sum()), float(np.median(picos[m])) if m.any() else None))
    # las que no encajan en su sitio (±CONTRASTE_BUSCA), más lejos: un trozo del castellano descolocado más de lo que
    # mide el contraste no se vería si no
    descolocados = []
    i = 0
    while i < len(ventanas):
        if ok[i]:
            i += 1
            continue
        j = i
        while j + 1 < len(ventanas) and not ok[j + 1] and ventanas[j + 1][0] - ventanas[j][0] <= paso + 0.01:
            j += 1
        n = j - i + 1
        if n >= CONTRASTE_LEJOS_SEGUIDAS:
            _, pk, fz = medir_contraste(pares, ventanas[i:j + 1], busca=CONTRASTE_LEJOS)
            lejos = [v / 1000 for v, f in zip(pk, fz) if f >= CONTRASTE_LEJOS_ENCAJA and abs(v) > CONTRASTE_BUSCA * 1000]
            if len(lejos) >= max(CONTRASTE_LEJOS_SEGUIDAS, 0.6 * n):
                d = float(np.median(lejos))
                acuerdo = sum(1 for v in lejos if abs(v - d) <= 0.02)
                if acuerdo >= max(CONTRASTE_LEJOS_SEGUIDAS, 0.6 * n):
                    descolocados.append((ventanas[i][0], ventanas[j][0] + largo, d, acuerdo, n))
        i = j + 1
    return dict(n=int(ok.sum()), total=len(ventanas), p50=float(np.median(r)) if len(r) else None,
                p90=float(np.percentile(r, 90)) if len(r) else None, por_seg=por_seg, coloc=coloc,
                descolocados=descolocados)


# Correcciones a mano, para lo que la medida no puede ver: un desfase entre la imagen y el sonido del propio archivo del
# doblaje (Ninja Sasuke 2: el compañero del usuario lo oía 100 ms tarde en todo el episodio) o un trozo que le falta y
# luego le sobra en medio de un destello, donde los cambios de plano encajan con cualquier desfase (los 0,7 s de 15:44)
RE_CORRECCION = re.compile(r"^\s*(?:(\d+)[:.](\d\d(?:,\d+)?)\s*-\s*(\d+)[:.](\d\d(?:,\d+)?)\s+)?([+-]?\d+)\s*(?:ms)?\s*$")


def leer_correcciones(texto):
    """'-100; 15:44-16:09 +700' -> [(None, None, -0.1), (944.0, 969.0, 0.7)]: ms que se retrasa (+) o se adelanta (-) el
    castellano, en todo el episodio o entre dos tiempos del resultado (mm:ss, el vídeo final). Se separan con ';' o
    líneas. ValueError si algo no se entiende."""
    out = []
    for parte in re.split(r"[;\n]", texto or ""):
        if not parte.strip():
            continue
        m = RE_CORRECCION.match(parte)
        if not m:
            raise ValueError(f"no se entiende «{parte.strip()}» (ejemplos: «-100» o «15:44-16:09 +700»)")
        d = int(m[5]) / 1000
        if m[1] is None:
            out.append((None, None, d))
            continue
        a, b = (int(mm) * 60 + float(ss.replace(",", ".")) for mm, ss in ((m[1], m[2]), (m[3], m[4])))
        if b <= a:
            raise ValueError(f"en «{parte.strip()}» el final va antes del principio")
        out.append((a, b, d))
    return out


def aplicar_correcciones(correcciones, L, cortes, db, dur, p, curva=None):
    """Las correcciones de leer_correcciones sobre los tramos ya medidos (L, cortes; los tiempos del resultado sin el
    retraso del original). Lo de todo el episodio se suma a todos los tramos; lo de un trozo pone un corte a cada lado
    (en el silencio más cercano, ±1 s, o en uno que ya haya a menos de 0,3 s) y se suma a los tramos de en medio.
    Devuelve (L, cortes)."""
    L, cortes = list(L), list(cortes)
    desf = lambda t, i: L[i] + (float(deriva_en(t, curva)) if curva is not None else 0.0)

    def a_doblaje(T):
        """Instante del doblaje que cae en T del resultado (en un hueco, el principio del tramo siguiente)."""
        starts, ends = limites(cortes, L, dur)
        for i, (s0, s1) in enumerate(zip(starts, ends)):
            if T < s0 + desf(s0, i):
                return s0
            if T <= s1 + desf(s1, i):
                t = T - desf(T - L[i], i)
                return min(max(t, s0), s1)
        return dur

    def partir(t):
        """Un corte en t (o el que ya haya cerca); devuelve su instante."""
        bordes = [c["c"] for c in cortes]
        cerca = [b for b in bordes if abs(b - t) < 0.3]
        if cerca:
            return min(cerca, key=lambda b: abs(b - t))
        c = punto_silencio(db, t, 1.0)
        j = int(np.searchsorted(bordes, t))
        izq, der = (bordes[j - 1] if j else 0.0), (bordes[j] if j < len(bordes) else dur)
        if not izq < c["c"] < der:
            c = corte_exacto(db, t)
        c["manual"] = True
        j = int(np.searchsorted(bordes, c["c"]))
        cortes.insert(j, c)
        L.insert(j + 1, L[j])
        return c["c"]

    for T0, T1, d in correcciones:
        if T0 is None:
            L = [x + d for x in L]
            p(f"Corrección a mano: {d * 1000:+.0f} ms en todo el doblaje")
            continue
        c0 = partir(a_doblaje(T0))
        c1 = partir(a_doblaje(T1))
        bordes = [0.0] + [c["c"] for c in cortes] + [dur]
        for i in range(len(L)):
            if bordes[i] >= c0 - 1e-6 and bordes[i + 1] <= c1 + 1e-6:
                L[i] += d
        p(f"Corrección a mano: {d * 1000:+.0f} ms de {mmss(T0)} a {mmss(T1)} del resultado (doblaje "
          f"{mmss(c0)}-{mmss(c1)})")
    return L, cortes


# Medida con audio: un trozo largo sin coincidencias (una cabecera con la canción doblada, unos créditos distintos) se
# queda con el desfase del tramo de al lado aunque al doblaje le falte o le sobre algo ahí. Si los dos archivos son
# vídeos, ese trozo se mide con los cambios de plano (Buzz Lightyear 1x09: la cabecera del doblaje era 0,48 s más corta
# y el castellano iba medio segundo tarde en ella; el resto, al milisegundo con el audio).
MIN_HUECO_AUDIO = 12.0       # s seguidos sin coincidencias del audio que se miden con la imagen
GUIA_SIN_IMAGEN = 0.95       # con guía, si encaja en esta parte de las ventanas (y sin huecos) no se mide con la imagen
MIN_SALTO_VIDEO = 0.10       # s: una diferencia menor (2-3 fotogramas) no se toca
MIN_CORTES_TRAMO_VIDEO = 10  # cambios de plano que tienen que encajar para cambiar el desfase de un trozo


def pintar_tramo(segs, x0, x1, nivel):
    """Los tramos [inicio, fin, desfase] con [x0, x1] puesto a `nivel` (lo que había ahí se recorta)."""
    out = []
    for s0, s1, lv in segs:
        if s1 <= x0 or s0 >= x1:
            out.append([s0, s1, lv])
            continue
        if s0 < x0:
            out.append([s0, x0, lv])
        if s1 > x1:
            out.append([x1, s1, lv])
    out.append([x0, x1, nivel])
    return sorted(out, key=lambda s: s[0])


def cortes_de_los_dos(es_path, en_path, st_es, st_en, vel, p, deco="cpu", miniaturas=(None, None)):
    """Cambios de plano de los dos vídeos enteros, (tm, sm, te, se), los del original ya a la velocidad del doblaje;
    o None si no se pueden leer. Se leen una vez y sirven para los huecos del audio y para la comprobación.
    miniaturas: dónde guardar de paso las de cada vídeo (cortes_video), para comparar su contenido."""
    p("Leyendo los cambios de plano de los dos vídeos para medir también con la imagen...")
    try:
        (_, tm, sm), (_, te, se) = cortes_de_ambos(es_path, en_path, st_es, st_en, deco, p, miniaturas)
    except Exception as e:
        p(f"Medida con la imagen: no se han podido leer los vídeos ({e}); se mide solo con el audio")
        return None
    return tm, sm, te / float(vel), se


def tramos_imagen(tm, sm, te, se, k, lag0, extra=()):
    """Tramos según la imagen: [primer corte, último corte, desfase, cambios de plano que encajan] y los puntos que
    encajan (t, desfase, 1). Los desfases candidatos, como en medir_video: los que aparecen de forma coherente
    siguiendo ventanas de 20 s (con cortes sueltos, una cabecera llena de cortes seguidos daba desfases casuales),
    más los de `extra` (los del audio). El desfase de cada tramo es la mediana de sus cambios de plano."""
    ev, ref = tm[sm > 0.3], te[se > 0.15]
    ev, _ = sin_destellos(ev)
    if len(ev) < 5 or len(ref) < 5:
        return [], np.zeros((0, 3))
    pv0 = seguir_video(senal_cortes(tm, sm), senal_cortes(te, se), lag0)
    niveles = niveles_video(pv0, ev, ref, k) if len(pv0) else []
    for x in extra:
        if all(abs(x - n) >= MIN_JUMP for n in niveles):
            niveles.append(x)
    if not niveles:
        return [], np.zeros((0, 3))
    tv = tramos_video(ev, ref, k, sorted(niveles), min_ev=5)
    pv = puntos_video(ev, ref, k, tv)
    for sg in tv:
        m = (pv[:, 0] >= sg[0]) & (pv[:, 0] <= sg[1])
        sg.append(int(m.sum()))
        if m.sum():
            sg[2] = float(np.median(pv[m, 1] - k * pv[m, 0]))
    unidos = [tv[0]]            # seguidos con casi el mismo desfase: uno solo (sumando sus cambios de plano)
    for sg in tv[1:]:
        if abs(sg[2] - unidos[-1][2]) < MIN_JUMP:
            unidos[-1][1], unidos[-1][3] = sg[1], unidos[-1][3] + sg[3]
        else:
            unidos.append(sg)
    return unidos, pv


def nivel_en(segs, t):
    """Desfase de los tramos [inicio, fin, desfase] en t (fuera de ellos, el del extremo)."""
    return next((s[2] for s in segs if s[0] <= t <= s[1]), segs[0][2] if t < segs[0][0] else segs[-1][2])


def cubierto_por_audio(pts, t):
    """¿t está en una ventana de seguir() (6 s) que encajó con claridad?"""
    fi = np.sort(pts[pts[:, 2] > 0.4, 0]) if len(pts) else np.zeros(0)
    i = np.searchsorted(fi, t)
    return np.minimum(np.abs(t - fi[np.clip(i, 0, len(fi) - 1)]),
                      np.abs(t - fi[np.clip(i - 1, 0, len(fi) - 1)])) <= 3.0 if len(fi) else np.zeros_like(t, bool)


def salto_con_imagen(ev, ref, k, a, b, l1, l2, c):
    """Dónde pasa el desfase de l1 a l2 (los midió el audio a cada lado) dentro de un trozo [a, b] sin coincidencias
    del audio. No se buscan desfases nuevos, solo el punto: los cambios de plano de antes encajan con l1 y los de
    después con l2 (c: lo que difieren audio e imagen). Si al doblaje le sobra metraje (l2 < l1), entre el último que
    encaja antes y el primero después tiene que caber lo que sobra: si dos «encajan» más juntos, uno es casual (Iron
    Man 2x01: un corte de censura de 4,24 s en el original; un corte del doblaje caía por casualidad junto a otro del
    original y el salto quedaba 40 s tarde con la búsqueda de desfases libre). Devuelve (último cambio de plano que
    encaja antes, primero después, cuántos encajan, cuántos hay) o None."""
    cand = ev[(ev >= a - 3) & (ev <= b + 3)]
    if len(cand) < 4:
        return None
    encaja = lambda v: np.array([np.min(np.abs(ref - (t * (1 + k) + v))) < 2.5 * SIGMA for t in cand])
    e1, e2 = encaja(l1 - c), encaja(l2 - c)
    t1, t2 = cand[e1], cand[e2]
    quita = max(0.0, l1 - l2)
    mejor = None
    # frontera: último cambio de plano que encaja con l1 (o el principio) y primero que encaja con l2 (o el final)
    for lo in np.concatenate([[a - 3], t1]):
        n1 = int((t1 <= lo).sum())
        for hi in np.concatenate([t2, [b + 3]]):
            if hi - lo < max(quita - 0.1, 0.0):
                continue
            clave = (n1 + int((t2 >= hi).sum()), -(hi - lo))   # más cortes que encajan; a igualdad, el hueco justo
            if mejor is None or clave > mejor[0]:
                mejor = (clave, float(lo), float(hi))
    if mejor is None:
        return None
    n = mejor[0][0]
    if n < 5 or n < 0.3 * len(cand):
        return None
    return mejor[1], mejor[2], n, len(cand)


def huecos_audio(pts, dur_es):
    """Trozos (inicio, fin) de al menos MIN_HUECO_AUDIO s sin ninguna ventana de seguir() que encaje con claridad."""
    fi = np.sort(pts[pts[:, 2] > 0.4, 0]) if len(pts) else np.zeros(0)
    # cada punto de seguir() mide una ventana de 6 s: cubre ±3 s alrededor
    bordes = np.concatenate([[-3.0], fi, [dur_es + 3.0]])
    return [(max(0.0, a + 3), min(dur_es, b - 3)) for a, b in zip(bordes, bordes[1:]) if b - a - 6 >= MIN_HUECO_AUDIO]


def completar_con_video(segs, k, pts, dur_es, p, cambios):
    """Trozos de al menos MIN_HUECO_AUDIO s sin coincidencias del audio, medidos con los cambios de plano (cambios:
    los de los dos vídeos, de cortes_de_los_dos). El salto que ve la imagen respecto al tramo de al lado, que sí se
    midió con audio, se suma a su desfase: así lo que la imagen no ve igual que el audio (unos ms de diferencia entre
    los dos archivos) no cuenta. Devuelve (tramos, {índice del salto: (último cambio de plano antes, primero después,
    cambios de plano)}) para cortar esos saltos entre cambios de plano."""
    if not len(pts) or (pts[:, 2] > 0.4).sum() < 10:
        return segs, {}
    huecos = huecos_audio(pts, dur_es)
    if not huecos:
        return segs, {}
    nivel = lambda t: nivel_en(segs, t)
    tm_t, sm_t, te_t, se_t = cambios
    saltos = {}             # tiempo del salto -> (lo, hi, cambios)
    for a, b in huecos:
        if a > 0 and b < dur_es and abs(nivel(a - 5) - nivel(b + 5)) < MIN_JUMP:
            # el audio tiene el mismo desfase a los dos lados: dentro no ha cambiado el montaje. Si la imagen dice otra
            # cosa es que la captura se retrasa unos fotogramas y luego los recupera, y el audio no se mueve por eso
            # (Buzz 1x09, 14:52-15:16: +120 ms con 7 cambios de plano)
            continue
        r0, r1 = max(0.0, a - 60), min(dur_es, b + 90)
        ln = nivel(b + 5) if b + 5 < dur_es else nivel(a - 5)
        me, mo = (tm_t >= r0) & (tm_t <= r1), (te_t >= r0 + ln - 25) & (te_t <= r1 + ln + 25)
        tm, sm, te, se = tm_t[me], sm_t[me], te_t[mo], se_t[mo]
        if a > 0 and b < dur_es:
            # el audio sabe el desfase de los dos lados: la imagen solo tiene que decir dónde se pasa de uno a otro
            l1, l2 = nivel(a - 5), nivel(b + 5)
            ev, ref = tm[sm > 0.3], te[se > 0.15]
            ev, _ = sin_destellos(ev)
            d = []          # calibración: audio - imagen en las zonas medidas con audio
            for t in ev[(ev < a - 3) | (ev > b + 3)] if len(ref) else []:
                L = nivel(t)
                r = ref[np.argmin(np.abs(ref - (t * (1 + k) + L)))] - t * (1 + k)
                if abs(r - L) < 0.08:
                    d.append(L - r)
            res = salto_con_imagen(ev, ref, k, a, b, l1, l2, float(np.median(d))) if len(d) >= 5 else None
            if res is None:
                p(f"Sin coincidencias del audio {mmss(a)}-{mmss(b)}: la imagen no dice con claridad dónde está el salto; "
                  "se deja donde lo puso el audio")
                continue
            lo, hi, n, total = res
            x = (lo + hi) / 2
            segs = pintar_tramo(pintar_tramo(segs, a - 3, x, l1), x, b + 3, l2)
            saltos[x] = (lo, hi, (tm, sm, te, se))
            p(f"Sin coincidencias del audio {mmss(a)}-{mmss(b)}: medido con los cambios de plano, el salto de "
              f"{(l2 - l1) * 1000:+.0f} ms va entre {mmss(lo)} y {mmss(hi)} ({n} de {total} cambios de plano encajan)")
            continue
        tv, pv = tramos_imagen(tm, sm, te, se, k, ln)
        if not tv:
            p(f"Sin coincidencias del audio {mmss(a)}-{mmss(b)}: la imagen tampoco da una medida clara; se deja así")
            continue
        # calibración: lo que difieren audio e imagen donde se midió con los dos (mediana de todos los cambios de plano
        # de esa zona: el vídeo de una captura de TV va uno o dos fotogramas arriba y abajo)
        fuera = (pv[:, 0] < a - 3) | (pv[:, 0] > b + 3)
        if fuera.sum() < 5:
            p(f"Sin coincidencias del audio {mmss(a)}-{mmss(b)}: la imagen no encaja en la zona medida con el "
              "audio; se deja así")
            continue
        c = float(np.median([nivel(t) - (lag - k * t) for t, lag, _ in pv[fuera]]))
        cambio = False
        for i, sg in enumerate(tv):
            centro = (sg[0] + sg[1]) / 2
            if not (a <= centro <= b) or sg[3] < MIN_CORTES_TRAMO_VIDEO:
                continue
            nuevo, actual = sg[2] + c, nivel(centro)
            if abs(nuevo - actual) < MIN_SALTO_VIDEO:
                continue
            x0 = 0.0 if i == 0 and r0 == 0 else ((tv[i - 1][1] + sg[0]) / 2 if i > 0 else sg[0])
            x1 = dur_es if i == len(tv) - 1 and r1 >= dur_es else ((sg[1] + tv[i + 1][0]) / 2 if i < len(tv) - 1
                                                                    else sg[1])
            lim0, lim1 = (a - 3 if a > 0 else 0.0), (b + 3 if b < dur_es else dur_es)
            x0, x1 = max(x0, lim0), min(x1, lim1)
            cambios = (tm, sm, te, se)
            # el corte se busca entre los cambios de plano de cada lado, pero sin salir del trozo sin coincidencias:
            # más allá manda lo que midió el audio (Buzz 1x01: el siguiente cambio de plano estaba 20 s después)
            if i > 0 and x0 > 0:
                saltos[x0] = (min(max(tv[i - 1][1], lim0), x0), max(sg[0], x0), cambios)
            if i < len(tv) - 1 and x1 < dur_es:
                saltos[x1] = (min(sg[1], x1), max(min(tv[i + 1][0], lim1), x1), cambios)
            segs = pintar_tramo(segs, x0, x1, nuevo)
            cambio = True
            p(f"Sin coincidencias del audio {mmss(a)}-{mmss(b)}: medido con los cambios de plano, "
              f"{mmss(x0)}-{mmss(x1)} va a {nuevo * 1000:+.0f} ms ({(nuevo - actual) * 1000:+.0f} ms respecto al "
              f"tramo de al lado; {sg[3]} cambios de plano)")
        if not cambio:
            p(f"Sin coincidencias del audio {mmss(a)}-{mmss(b)}: los cambios de plano confirman el desfase del tramo "
              "de al lado")
    # pintar puede dejar tramos seguidos con el mismo desfase: uno solo (si no, saldría un corte de 0 ms, como el de
    # 1:58 del Iron Man 2x01)
    segs = fusionar_iguales([list(s) for s in segs])
    entre = {i: saltos[s[1]] for i, s in enumerate(segs[:-1]) if s[1] in saltos}
    return segs, entre


def revisar_audio_con_imagen(segs, entre, k, pts, cambios, calibracion, imagen, p, candidatos=()):
    """El contenido de la imagen sobre lo medido con el audio (revisar_con_imagen): donde la imagen pone claramente
    otro desfase y el audio no tenía pruebas (ninguna ventana fiable con su desfase: seguía el de al lado), se corrige y
    el salto va entre las ventanas de la imagen de cada lado (como un salto de completar_con_video); si el audio sí lo
    confirma, solo se avisa. entre: los saltos que ya ha puesto la imagen ({índice: (desde, hasta, cambios)}).
    candidatos: los desfases que mide la imagen (comprobar_con_imagen), que también se prueban: con un único desfase
    del audio en todo el episodio no habría con qué comparar.
    Devuelve (tramos, entre, avisos)."""
    tm, sm, te, se = cambios
    pts = np.asarray(pts).reshape(-1, 3)

    def apoyo(a, b, nivel):
        m = (pts[:, 0] >= a) & (pts[:, 0] <= b) & (pts[:, 2] > 0.4)
        return int((m & (np.abs(pts[:, 1] - k * pts[:, 0] - nivel) <= 0.03)).sum()) >= 3

    saltos = {segs[i][1]: v for i, v in entre.items()}
    L = [sg[2] for sg in segs]
    nuevos, L2, _, avisos = revisar_con_imagen([list(s) for s in segs], L, k, tm[sm > 0.3], te[se > 0.15], imagen, p,
                                               candidatos, calibracion=calibracion, apoyo=apoyo)
    # los huecos que deja una corrección (entre la última ventana de un lado y la primera del otro) pasan a ser el
    # sitio del salto, como los de completar_con_video
    for i in range(len(nuevos) - 1):
        if nuevos[i + 1][0] - nuevos[i][1] > 0.5:
            lo, hi = nuevos[i][1], nuevos[i + 1][0]
            x = (lo + hi) / 2
            saltos[x] = (lo, hi, cambios)
            nuevos[i][1] = nuevos[i + 1][0] = x
    nuevos = fusionar_iguales([list(s) for s in nuevos])
    return nuevos, {i: saltos[s[1]] for i, s in enumerate(nuevos[:-1]) if s[1] in saltos}, avisos


def comprobar_con_imagen(segs, k, pts, cambios, p):
    """Doble medida (siempre que los dos archivos sean vídeos; pedido del usuario, 12-10-2026): el episodio entero
    medido también con los cambios de plano y comparado tramo a tramo con lo que se va a montar. Lo que difieren
    audio e imagen donde se midió con los dos se descuenta (unos ms entre los dos archivos); si en un trozo de al menos
    10 s con MIN_CORTES_TRAMO_VIDEO cambios de plano la imagen dice otra cosa (MIN_SALTO_VIDEO o más), aviso con el
    minuto. Devuelve (avisos, lo que difieren audio e imagen en todo el episodio, o None si no se ha podido medir,
    los desfases de los tramos de la imagen, ya en los del audio)."""
    tm, sm, te, se = cambios
    tv, pv = tramos_imagen(tm, sm, te, se, k, nivel_en(segs, 60.0), sorted({s[2] for s in segs}))
    t = pv[:, 0]
    cub = cubierto_por_audio(pts, t) if len(t) else np.zeros(0, bool)
    if not tv or cub.sum() < 10:
        p("Comprobación con la imagen: no encajan bastantes cambios de plano para comprobar la medida")
        return [], None, []
    r = np.array([nivel_en(segs, x) for x in t]) - (pv[:, 1] - k * t)     # audio - imagen en cada cambio de plano
    c0 = float(np.median(r[cub]))
    r -= c0
    avisos = []
    for sg in tv:
        m = (t >= sg[0]) & (t <= sg[1])
        if m.sum() < MIN_CORTES_TRAMO_VIDEO or sg[1] - sg[0] < 10:
            continue
        d = -float(np.median(r[m]))
        if abs(d) >= MIN_SALTO_VIDEO:
            avisos.append(f"{mmss(sg[0])}-{mmss(sg[1])}: la imagen y el audio no coinciden (la imagen lo pone "
                          f"{d * 1000:+.0f} ms; {int(m.sum())} cambios de plano), conviene comprobarlo")
    # sin las casualidades (cortes que encajan a medio segundo o más: en Iron Man 2x01 daban 1422 ms de desviación
    # con un p90 de 50 ms)
    rc = r[cub & (np.abs(r) < 0.5)]
    dt, p90 = float(np.std(rc)) * 1000, float(np.percentile(np.abs(rc), 90)) * 1000
    p(f"Comprobación con la imagen: {len(t)} cambios de plano encajan; donde se midió con los dos, desviación típica "
      f"{dt:.0f} ms, p90 {p90:.0f} ms (el redondeo a fotogramas)"
      + (f"; NO coinciden en {len(avisos)} trozo(s), ver avisos" if avisos else "; coinciden en todo el episodio"))
    if abs(c0) >= MIN_SALTO_VIDEO:
        # Buzz 1x06: 210 ms en todo el episodio. Manda el audio (al oído, el resultado bueno era el del audio)
        p(f"Comprobación con la imagen: en el doblaje, la imagen va {c0 * 1000:+.0f} ms desplazada respecto a su "
          "propio sonido en todo el episodio; se sigue al sonido, que es lo que cuadra con el original")
    return avisos, c0, [sg[2] + c0 for sg in tv]


# La verificación solo medía los cambios de plano que encajan, y no decía nada de los que no: en el Kojak 4x10, 4 minutos
# a -34,6 s en vez de +1,5 daban «38,9 ms» igual. Ahora también avisa de los trechos en que ninguno encaja
MIN_SUELTOS = 6            # cambios de plano seguidos del doblaje (sin los dobles) que no encajan con el resultado...
MIN_S_SUELTOS = 15.0       # ...en al menos tantos segundos: aviso


def verificar_video(cambios, mapa, starts, ends, excluir=()):
    """Cambios de plano del doblaje llevados con el mapa final frente a los del original. excluir: trozos del doblaje
    (s) con otro montaje, que van con el audio original y no dicen nada de la sincronía. Lo que se quita del doblaje
    (entre ends[i] y starts[i + 1]) tampoco cuenta. sueltos: [(desde, hasta en el doblaje, desde, hasta en el original,
    cuántos)] de los trechos con MIN_SUELTOS cambios de plano seguidos que no encajan en MIN_S_SUELTOS s o más."""
    tm, sm, te, se = cambios
    ref = te[se > 0.3]
    r, todos = [], []
    dob = tm[sm > 0.5]
    for a_, b_ in excluir:
        dob = dob[(dob < a_) | (dob > b_)]
    for e_, s_ in zip(ends, starts[1:]):
        dob = dob[(dob <= e_) | (dob >= s_)]
    for t in dob:
        x = mapear(t, mapa) - mapa["pre"]
        j = int(np.clip(np.searchsorted(ref, x), 1, len(ref) - 1))
        d = min(ref[j] - x, ref[j - 1] - x, key=abs)
        if abs(d) < 0.1:
            r.append((t, d * 1000))
        if not todos or t - todos[-1][0] > 0.06:            # (sin los dobles de un fundido)
            todos.append((t, x, abs(d) < 0.1))
    sueltos, racha = [], []
    for t, x, ok in todos + [(np.inf, np.inf, True)]:
        if not ok:
            racha.append((t, x))
            continue
        if len(racha) >= MIN_SUELTOS and racha[-1][1] - racha[0][1] >= MIN_S_SUELTOS:
            sueltos.append((racha[0][0], racha[-1][0], racha[0][1], racha[-1][1], len(racha)))
        racha = []
    r = np.array(r).reshape(-1, 2)
    por_seg = []
    for a0, a1 in zip(starts, ends):
        m = r[(r[:, 0] > a0) & (r[:, 0] < a1)]
        por_seg.append((len(m), float(np.median(m[:, 1])) if len(m) else None))
    return dict(n=len(r), p50=float(np.median(np.abs(r[:, 1]))) if len(r) else None,
                p90=float(np.percentile(np.abs(r[:, 1]), 90)) if len(r) else None, por_seg=por_seg,
                total=len(dob), sueltos=sueltos)


def verificar(out, fs, pre, en_a, lateral, colocacion, excluir=(), transformar=None):
    """excluir: tramos (s, sin contar pre) rellenados con el audio original, que coinciden con él
    por construcción y no dicen nada de la sincronía. transformar: lo mismo que a la señal del original (en_a), como
    envolvente_ar con el tono corregido."""
    x = out[pre:]
    # lateral: 0 = mezcla, 1 = lateral, -1 = lateral invertida (canales cambiados en uno de los archivos)
    x = (x[:, 0] - x[:, 1]) * lateral if lateral else x[:, :2].sum(1)
    fr = Fraction(AR, fs)
    a = resample_poly(x, fr.numerator, fr.denominator).astype(np.float32)
    if transformar is not None:
        a = transformar(a)
    WIN, STEP, S = 4 * AR, 2 * AR, int(0.3 * AR)
    r = []
    for t in range(S, min(len(a), len(en_a)) - WIN - S, STEP):
        c = ncc_curve(a[t:t + WIN], en_a[t - S:t + WIN + S])
        if c is not None:
            i = int(np.argmax(c)); r.append(((t + WIN / 2) / AR, (i - S) / AR * 1000, float(c[i])))
    r = np.array(r).reshape(-1, 3)
    for e0, e1 in excluir:
        r = r[(r[:, 0] < e0 - 2) | (r[:, 0] > e1 + 2)]
    g = r[r[:, 2] > 0.45]
    por_seg = []
    for a0, a1 in colocacion:
        m = g[(g[:, 0] > a0 + 2) & (g[:, 0] < a1 - 2)]
        por_seg.append((len(m), float(np.median(m[:, 1])) if len(m) else None))
    return dict(n=len(g), p50=float(np.median(np.abs(g[:, 1]))) if len(g) else None,
                p90=float(np.percentile(np.abs(g[:, 1]), 90)) if len(g) else None, por_seg=por_seg, total=len(r),
                descolocados=trechos_descolocados(a, en_a, r, WIN))


# La verificación solo cuenta las ventanas que encajan en su sitio (±0,3 s): un trozo descolocado 1-2 s no encaja, se
# quedaba fuera de la cuenta y el p90 salía igual de bonito (como el «0,0 ms» de la guía en Diagnóstico asesinato, que
# no veía el castellano). Los trechos seguidos que no encajan se buscan más lejos, y si encajan claramente en otro
# desfase, se avisa (con la corrección a mano que lo arreglaría). Un trozo así de corto (menos de unos 10 s) tampoco
# llega a ser un desfase de la medida (buscar_niveles), así que esto es lo que lo ve. No se corrige solo: sería
# decidir con una única medida
VERIF_SEGUIDAS = 3     # ventanas seguidas (de 4 s cada 2 s: unos 8 s) que no encajan, para buscarlas más lejos
VERIF_LEJOS = 5.0      # s a cada lado
VERIF_LEJOS_ENCAJA = 0.5   # parecido para darla por encajada más lejos (algo más exigente que en su sitio)
VERIF_ACUERDO = 0.04   # s: lo que pueden diferir entre ellas las ventanas del trecho


def trechos_descolocados(a, en_a, r, win):
    """De las ventanas de verificar (r: centro en s, desfase en ms, parecido; en orden): los trechos de VERIF_SEGUIDAS o
    más seguidas que no encajan en su sitio y que, buscadas a ±VERIF_LEJOS, encajan casi todas (60 %) en un mismo
    desfase lejos de su sitio: [(desde, hasta en s del resultado, desfase en s, ventanas que lo dicen, del trecho)].
    Positivo: en el original suena más tarde (el castellano tendría que ir más tarde)."""
    out, lejos_n = [], int(VERIF_LEJOS * AR)
    malas = r[:, 2] <= 0.45 if len(r) else np.zeros(0, bool)
    i = 0
    while i < len(r):
        if not malas[i]:
            i += 1
            continue
        j = i
        while j + 1 < len(r) and malas[j + 1] and r[j + 1, 0] - r[j, 0] <= 4.5:
            j += 1
        n = j - i + 1
        if n >= VERIF_SEGUIDAS:
            lejos = []
            for centro in r[i:j + 1, 0]:
                t = int(round(centro * AR - win / 2))
                lo, hi = t - lejos_n, t + win + lejos_n
                if lo < 0 or hi > min(len(en_a), len(a) + lejos_n):
                    continue
                c = ncc_curve(a[t:t + win], en_a[lo:hi])
                if c is not None:
                    k = int(np.argmax(c))
                    if c[k] > VERIF_LEJOS_ENCAJA:
                        lejos.append((k - lejos_n) / AR)
            if len(lejos) >= max(VERIF_SEGUIDAS, 0.6 * n):
                d = float(np.median(lejos))
                acuerdo = sum(1 for x in lejos if abs(x - d) <= VERIF_ACUERDO)
                if acuerdo >= max(VERIF_SEGUIDAS, 0.6 * n) and abs(d) > 0.3:
                    out.append((float(r[i, 0] - win / AR / 2), float(r[j, 0] + win / AR / 2), d, acuerdo, n))
        i = j + 1
    return out


def avisos_descolocados(trechos, que="del castellano"):
    """Los avisos (para revisar) de trechos_descolocados, con la corrección a mano que lo arreglaría, escrita como la
    lee leer_correcciones (segundos enteros, hacia fuera: «15:44-16:09 +700»)."""
    seg = lambda t, arriba: (lambda s: f"{s // 60}:{s % 60:02d}")(int(np.ceil(t)) if arriba else int(np.floor(t)))
    return [f"{mmss(a)}-{mmss(b)}: {k} de {n} ventanas seguidas {que} no encajan con el original en su sitio, "
            f"sino {abs(d):.2f} s {'más tarde' if d > 0 else 'antes'}; puede estar descolocado, conviene comprobarlo "
            f"(si lo está, la corrección a mano sería «{seg(a, False)}-{seg(b, True)} {d * 1000:+.0f}»)"
            for a, b, d, k, n in trechos]


# ---------------------------------------------------------------- subtítulos

SRT_T = re.compile(rb"(\d+):(\d\d):(\d\d)[,.](\d{3})(\s*-->\s*)(\d+):(\d\d):(\d\d)[,.](\d{3})")


def mapear(t, mapa):
    """Tiempo del doblaje -> tiempo de la pista sincronizada (la misma transformación que el audio)."""
    i = max(0, int(np.searchsorted(mapa["inicios"], t, side="right")) - 1)
    t = min(t, mapa["fines"][i])        # dentro de un trozo recortado: se queda en el corte
    if mapa.get("curva"):               # velocidad variable con el castellano estirado: la curva en vez de la deriva
        return max(0.0, mapa["pre"] + t + float(deriva_en(t, mapa["curva"])) + mapa["L"][i])
    return max(0.0, mapa["pre"] + t * (1 + mapa["k"]) + mapa["L"][i])


def ajustar_srt(src, dst, mapa, t0=0.0):
    """Reescribe solo las marcas de tiempo; el texto y la codificación quedan intactos.
    t0: dónde empieza la pista de audio del doblaje en el tiempo del subtítulo (0: van a la par)."""
    with open(src, "rb") as f:
        data, n = _srt_mapeado(f.read(), mapa, t0)
    with open(dst, "xb") as f:
        f.write(data)
    return n


def _srt_mapeado(data, mapa, t0=0.0):
    """ajustar_srt sobre los bytes del .srt: (bytes, líneas)."""
    def seg(h, m, s, ms):
        return int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000

    def fmt(t):
        h, r = divmod(int(round(t * 1000)), 3600000)
        m, r = divmod(r, 60000)
        return f"{h:02d}:{m:02d}:{r // 1000:02d},{r % 1000:03d}".encode()

    n = 0
    def rep(mo):
        nonlocal n
        n += 1
        g = mo.groups()
        return fmt(mapear(seg(*g[:4]) - t0, mapa)) + g[4] + fmt(mapear(seg(*g[5:]) - t0, mapa))

    return SRT_T.sub(rep, data), n


ASS_T = re.compile(rb"^((?:Dialogue|Comment):[^,]*,)(\d+):(\d\d):(\d\d)\.(\d\d),(\d+):(\d\d):(\d\d)\.(\d\d),", re.M)


def ajustar_ass(src, dst, mapa, t0=0.0):
    """Como ajustar_srt, para ASS/SSA (tiempos H:MM:SS.cc); estilos y posiciones quedan intactos."""
    with open(src, "rb") as f:
        data, n = _ass_mapeado(f.read(), mapa, t0)
    with open(dst, "xb") as f:
        f.write(data)
    return n


def ass_tiempo(t):
    """H:MM:SS.cc de un ASS/SSA."""
    h, r = divmod(int(round(max(0.0, t) * 100)), 360000)
    m, r = divmod(r, 6000)
    return f"{h}:{m:02d}:{r // 100:02d}.{r % 100:02d}".encode()


def _ass_mapeado(data, mapa, t0=0.0):
    """ajustar_ass sobre los bytes del .ass: (bytes, líneas)."""
    def seg(h, m, s, cs):
        return int(h) * 3600 + int(m) * 60 + int(s) + int(cs) / 100

    n = 0
    def rep(mo):
        nonlocal n
        n += 1
        g = mo.groups()
        return (g[0] + ass_tiempo(mapear(seg(*g[1:5]) - t0, mapa)) + b","
                + ass_tiempo(mapear(seg(*g[5:9]) - t0, mapa)) + b",")

    return ASS_T.sub(rep, data), n


# subtítulos de texto que se pueden reajustar (extensión con la que se guardan); los de imagen (PGS, VobSub,
# DVB) no: se avisa y se dejan fuera
SUB_TEXTO = {"subrip": ".srt", "srt": ".srt", "mov_text": ".srt", "webvtt": ".srt", "text": ".srt",
             "ass": ".ass", "ssa": ".ass"}


def pistas_sub_doblaje(path):
    """Pistas de subtítulos del doblaje: [dict(n, index, codec, idioma, titulo, pred, forz, ext)]; ext None = imagen."""
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "s", "-show_entries",
                        "stream=index,codec_name:stream_tags=language,title:stream_disposition=default,forced",
                        "-of", "json", path], capture_output=True, text=True, encoding="utf-8", errors="replace",
                       **SIN_VENTANA)
    out = []
    for n, s in enumerate(json.loads(r.stdout or "{}").get("streams", []), 1):
        tags, disp = s.get("tags") or {}, s.get("disposition") or {}
        idioma = next((v for k, v in tags.items() if k.lower() == "language"), "")
        titulo = next((v for k, v in tags.items() if k.lower() == "title"), "")
        out.append(dict(n=n, index=s["index"], codec=s.get("codec_name", "?"), idioma=idioma_valido(idioma),
                        titulo=titulo, pred=bool(disp.get("default")), forz=bool(disp.get("forced")),
                        ext=SUB_TEXTO.get(s.get("codec_name"))))
    return out


def describir_sub(s):
    return (s["codec"] + (f" [{s['idioma']}]" if s["idioma"] else "") + (f" «{s['titulo']}»" if s["titulo"] else "")
            + (" forzado" if s["forz"] else "") + (" predeterminado" if s["pred"] else ""))


def ruta_sub_doblaje(out_path, s):
    return f"{os.path.splitext(out_path)[0]}_sub{s['n']}{s['ext']}"


def ajustar_subs_doblaje(es_path, t_audio, mapa, out_path, p=print):
    """Las pistas de subtítulos de texto que trae el doblaje, con los mismos cortes que el audio, junto al audio
    sincronizado (_sub1.srt, _sub2.ass...). Las que ya existan se dejan (quizá corregidas a mano).
    Devuelve cuántas pistas de texto tiene el doblaje."""
    pendientes, _, n = preparar_subs_doblaje(es_path, t_audio, mapa, out_path, p)
    escribir_pendientes(pendientes, p)
    return n


def preparar_subs_doblaje(es_path, t_audio, mapa, out_path, p=print, refs=None, duracion=None):
    """Como ajustar_subs_doblaje, sin escribir nada: ([(ruta, bytes, línea del informe)], avisos, pistas de texto).
    Con refs (curvas de voz) se comprueba para qué versión está hecha cada pista: dentro del doblaje casi siempre es
    para él, pero un remux puede traer las de otra edición; y se corrigen sus erratas."""
    n, pendientes, avisos = 0, [], []
    for s in pistas_sub_doblaje(es_path):
        cab = f"Subtítulo del doblaje {s['n']}: {describir_sub(s)}"
        if not s["ext"]:
            p(f"{cab}: es de imagen y no se puede ajustar; se deja fuera")
            continue
        n += 1
        ruta = ruta_sub_doblaje(out_path, s)
        if os.path.exists(ruta):
            p(f"{cab}: ya existe {ruta}; se usa ese")
            continue
        with tempfile.TemporaryDirectory(prefix="subs_") as tmp:
            bruto = os.path.join(tmp, "sub" + s["ext"])
            # -copyts: los tiempos del contenedor, los mismos con los que va el audio (se resta su inicio)
            r = subprocess.run(["ffmpeg", "-v", "error", "-copyts", "-i", es_path, "-map", f"0:{s['index']}", "-c:s",
                                "copy" if s["codec"] == "ass" else ("ass" if s["ext"] == ".ass" else "srt"), bruto],
                               capture_output=True, text=True, encoding="utf-8", errors="replace", **SIN_VENTANA)
            if r.returncode != 0 or not os.path.exists(bruto):
                p(f"{cab}: no se ha podido extraer ({' '.join(r.stderr.strip().splitlines()[-1:])[:150]})")
                continue
            datos, lineas, informe, av = preparar_subtitulo(bruto, mapa, refs, t_audio, "doblaje",
                                                            f"subtítulo del doblaje {s['n']}", duracion=duracion)
        for x in informe:
            p(f"Subtítulos: {x}")
        avisos += av
        pendientes.append((ruta, datos, f"{cab}: {lineas} líneas ajustadas -> {ruta}"))
    return pendientes, avisos, n


def escribir_pendientes(pendientes, p=print):
    """Escribe los subtítulos ya preparados (sin pisar ninguno que exista) y lo dice en el informe."""
    for ruta, datos, linea in pendientes:
        with open(ruta, "xb") as f:
            f.write(datos)
        p(linea)


def codificacion_texto(ruta):
    """UTF-8 o, si no lo es, Windows-1252 (los .srt en castellano de internet suelen venir así)."""
    try:
        with open(ruta, "rb") as f:
            f.read().decode("utf-8")
        return "UTF-8"
    except UnicodeDecodeError:
        return "windows-1252"


def subs_para_muxear(es_path, out_path, idioma, pistas=None):
    """Subtítulos ya ajustados que acompañan al audio sincronizado, en el orden en que se muxean: los que traía el
    doblaje (con su idioma, título y marcas) y el .srt suelto que se le dio (idioma del muxeado)."""
    try:
        pistas = pistas_sub_doblaje(es_path) if pistas is None else pistas
    except Exception:
        pistas = []
    out = []
    for s in pistas:
        ruta = ruta_sub_doblaje(out_path, s) if s["ext"] else None
        if ruta and os.path.exists(ruta):
            out.append(dict(ruta=ruta, idioma=s["idioma"] or idioma, titulo=s["titulo"], pred=s["pred"],
                            forz=s["forz"], cod=codificacion_texto(ruta)))
    suelto = os.path.splitext(out_path)[0] + ".srt"
    if os.path.exists(suelto):
        out.append(dict(ruta=suelto, idioma=idioma, titulo="", pred=False, forz=False, cod=codificacion_texto(suelto)))
    return out


def sin_copia_subs(rutas, mkv):
    """Los subtítulos ajustados ya van dentro del vídeo muxeado: no se deja copia aparte (lo pidió el usuario,
    18-10-2026). Solo si el vídeo existe. Los forzados del OCR no pasan por aquí: se quedan, porque son los que se
    corrigen a mano antes de volver a muxear. Devuelve la línea para el informe (o ninguna)."""
    if not mkv or not os.path.exists(mkv):
        return []
    borrados = []
    for ruta in rutas:
        try:
            os.remove(ruta)
            borrados.append(os.path.basename(ruta))
        except OSError:
            pass
    if not borrados:
        return []
    linea = "Subtítulos ya muxeados en el vídeo; no se deja copia aparte: " + ", ".join(borrados)
    print(linea)
    return [linea]


def srt_tiempo(t):
    h, r = divmod(int(round(max(0.0, t) * 1000)), 3600000)
    m, r = divmod(r, 60000)
    return f"{h:02d}:{m:02d}:{r // 1000:02d},{r % 1000:03d}"


# ---------------------------------------------------------------- subtítulos de cualquier versión
# Un subtítulo puede estar hecho para el doblaje, para el original o para otra versión (otra velocidad, otro desfase,
# otro montaje), y traer erratas en los tiempos. Se averigua comparando cuándo hay un subtítulo en pantalla con cuándo
# se habla (el ritmo de las sílabas en la banda de la voz), en el doblaje y en el original, como se hizo a mano con los
# de Godzilla (Roku frente al DVD), que quedaron perfectos. El .srt que acompañaba al remux de Trailer Park Boys 1x01
# iba 17,3 s tarde: estaba hecho para otra edición.

FR_VOZ = 100            # muestras por segundo de las curvas de voz y de subtítulos
SUB_IDENTIDAD = 0.3     # s: un desfase menor no se toca (el subtítulo suele adelantarse un poco a la voz)
SUB_VENTANA, SUB_PASO, SUB_BUSCA = 60, 60, 45   # s: ventanas del subtítulo, su paso y la búsqueda alrededor del global
# sin solaparse: dos ventanas que comparten subtítulos coinciden por casualidad, y con 90 s cada 45 el .srt de otro
# episodio pasaba por «otra versión» (4 de 9 en cadena); así, 0 de 8
SUB_MIN_CADENA = 3      # ventanas en el mismo desfase que su vecina (±0,3 s) para fiarse, y al menos el 40 %
SUB_PEN = 1.0           # coste de cambiar de desfase entre subtítulos seguidos (en voz cubierta)
SUB_MIN_TRAMO = 4       # subtítulos de un tramo de otro desfase (con menos, al vecino)
# s que puede pisar un subtítulo al anterior al cambiar a un desfase menor: más, y saldría antes que él (el diálogo
# de otra versión va en el mismo orden; solo puede tener metraje de más entre dos subtítulos)
SUB_TOL_ORDEN = 0.2
SUB_MEJORA_TRAMO = 0.1  # encaje (correlación) que tiene que ganar un tramo con el desfase de un vecino para unirse a él
SUB_BLOQUE_MIN = 1.0    # s de solape con el vecino a partir de los cuales se busca un bloque desplazado
RE_SUB_COLOCADO = re.compile(rb"\{\\(an?\d|pos|move)")    # subtítulo colocado en pantalla: un cartel, solapa a propósito


def curva_voz(x, fs=AR):
    """Cuánto se habla en cada instante (FR_VOZ por segundo, de 0 a 1,5): la energía de la banda de la voz (300-3400
    Hz) y, de ella, su modulación al ritmo de las sílabas (2-8 Hz), que la música y los efectos apenas tienen. x: mono."""
    F = fs // FR_VOZ
    n = len(x) // F * F
    if n < 10 * fs:
        return np.zeros(n // F, np.float32)
    sos, e = butter(4, [300, 3400], btype="band", fs=fs, output="sos"), []
    zi = np.zeros((sos.shape[0], 2))
    for i in range(0, n, F * 100000):           # por bloques: una película entera filtrada de una vez no cabe
        y, zi = sosfilt(sos, np.asarray(x[i:min(i + F * 100000, n)], np.float64), zi=zi)
        e.append((y.reshape(-1, F) ** 2).mean(1))
    e = np.concatenate(e)
    le = np.log10(e + np.percentile(e, 20) + 1e-12)     # con ese piso, en los silencios el logaritmo no baila
    v = gaussian_filter1d(np.abs(sosfiltfilt(butter(2, [2, 8], btype="band", fs=FR_VOZ, output="sos"), le)), 15)
    lo, hi = np.percentile(v, 10), np.percentile(v, 95)
    return np.clip((v - lo) / max(hi - lo, 1e-12), 0, 1.5).astype(np.float32)


def voz_referencia(x, t0, escala=1.0):
    """Curva de voz de una pista leída a AR Hz, con su eje: la muestra i es el instante t0 + i·escala/FR_VOZ de su
    contenedor (escala: el original ya leído acelerado a la velocidad del doblaje)."""
    return dict(v=curva_voz(x[:, 0] + x[:, 1] if x.ndim == 2 else x), t0=float(t0), escala=float(escala))


def a_muestras(ref, t):
    """Instantes del contenedor de ref -> posición (fraccionaria) en su curva de voz."""
    return (np.asarray(t, np.float64) - ref["t0"]) * FR_VOZ / ref["escala"]


def voz_media(ref, ini, fin):
    """Voz media de ref entre los instantes ini y fin (arrays); 0 fuera de la curva."""
    if "cs" not in ref:
        ref["cs"] = np.concatenate([[0.0], np.cumsum(ref["v"], dtype=np.float64)])
    n = len(ref["v"])
    i = np.clip(np.round(a_muestras(ref, ini)).astype(np.int64), 0, n)
    j = np.clip(np.round(a_muestras(ref, fin)).astype(np.int64), 0, n)
    return (ref["cs"][np.maximum(i, j)] - ref["cs"][i]) / np.maximum(j - i, 1)


def presencia_sub(iv, ref, a=1.0, b=0.0):
    """Curva de subtítulos sobre el eje de ref (1 = hay uno en pantalla), con sus tiempos llevados a a·t + b."""
    s = np.zeros(len(ref["v"]), np.float32)
    ii = np.clip(np.round(a_muestras(ref, a * iv[:, 0] + b)).astype(np.int64), 0, len(s))
    jj = np.clip(np.round(a_muestras(ref, a * iv[:, 1] + b)).astype(np.int64), 0, len(s))
    for i, j in zip(ii, jj):
        s[i:j] = 1
    return s


def ncc_media(a, b):
    """Como ncc_curve, quitando también la media de cada tramo de b (para curvas siempre positivas, como la de voz)."""
    a = a - a.mean()
    na, W = np.linalg.norm(a), len(a)
    if na < 1e-6 or len(b) < W:
        return None
    c = fftconvolve(b, a[::-1], mode="valid")
    b = b.astype(np.float64)
    s1, s2 = np.concatenate([[0.0], np.cumsum(b)]), np.concatenate([[0.0], np.cumsum(b * b)])
    var = (s2[W:] - s2[:-W]) - (s1[W:] - s1[:-W]) ** 2 / W
    return c / (na * np.sqrt(np.maximum(var, 1e-4 * W)))


def desfase_global_sub(iv, ref, a, max_s=900):
    """Desfase b (s) con el que la curva de subtítulos, a la velocidad a, mejor encaja con la de voz de ref en todo el
    episodio (hasta ±max_s), y su parecido."""
    s, v = presencia_sub(iv, ref, a), ref["v"]
    s0, v0 = s - s.mean(), v - v.mean()
    ns, nv = np.linalg.norm(s0), np.linalg.norm(v0)
    if ns < 1e-6 or nv < 1e-6:
        return 0.0, 0.0
    c = fftconvolve(v0, s0[::-1], mode="full")
    lags = np.arange(-len(s) + 1, len(v))
    c[np.abs(lags) > max_s * FR_VOZ / ref["escala"]] = -np.inf
    i = int(np.argmax(c))
    return lags[i] * ref["escala"] / FR_VOZ, float(c[i] / (ns * nv))


def ventanas_sub(iv, ref, a, b0, busca=SUB_BUSCA):
    """(instante en el tiempo del subtítulo, desfase b, parecido) de ventanas de SUB_VENTANA s cada SUB_PASO s, a la
    velocidad a, cada una buscada en ±busca s alrededor de b0; solo las que tienen bastantes subtítulos."""
    f = FR_VOZ / ref["escala"]
    s, v = presencia_sub(iv, ref, a, b0), ref["v"]
    W, P, B = int(SUB_VENTANA * f), int(SUB_PASO * f), int(busca * f)
    out = []
    for w0 in range(0, max(len(s) - W, 0) + 1, P):
        win = s[w0:w0 + W]
        if win.sum() < 8 * f or int((np.diff(win) > 0).sum()) < 4:
            continue
        lo, hi = max(0, w0 - B), min(len(v), w0 + W + B)
        c = ncc_media(win, v[lo:hi])
        if c is None or not len(c):
            continue
        i = int(np.argmax(c))
        out.append(((ref["t0"] + (w0 + W / 2) / f - b0) / a, b0 + (lo + i - w0) / f, float(c[i])))
    return out


def en_cadena(bs, tol=0.3):
    """Ventanas cuyo desfase está a <= tol del de su vecina: una casualidad no se repite en la siguiente."""
    ok = np.zeros(len(bs), bool)
    for i in range(len(bs) - 1):
        if abs(bs[i] - bs[i + 1]) <= tol:
            ok[i] = ok[i + 1] = True
    return ok


def medir_subtitulo(iv, refs):
    """Con qué voz encaja un subtítulo (iv: sus intervalos en orden, en su propio tiempo): para cada referencia de refs
    ({"doblaje": ref, "original": ref}) y cada velocidad (la misma o una conversión habitual), las ventanas que caen en
    el mismo desfase que su vecina. Si una referencia encaja a la misma velocidad y sin desfase (hecho para ella), esa;
    si no, la que más encaje (a igualdad, el original, que es la imagen que se ve). Devuelve dict(ref, a, ventanas,
    cadena, n, suma, identidad) o None si no encaja con claridad con ninguna."""
    res = []
    for nombre, ref in refs.items():
        if ref is None or len(ref["v"]) < 60 * FR_VOZ:
            continue
        for a in [Fraction(1)] + VELOCIDADES:
            b0, _ = desfase_global_sub(iv, ref, float(a))
            w = ventanas_sub(iv, ref, float(a), b0)
            cad = en_cadena([b for _, b, _ in w])
            if cad.sum() >= SUB_MIN_CADENA and cad.sum() >= 0.4 * len(w):
                res.append(dict(ref=nombre, a=a, ventanas=w, cadena=cad, n=int(cad.sum()), total=len(w),
                                suma=float(sum(c for (_, _, c), o in zip(w, cad) if o))))
    if not res:
        return None

    def identidad(r):
        """A la misma velocidad y la mayoría de las ventanas (todas, no solo las de la cadena: una velocidad a un 0,1 %
        encadena más con una deriva lenta) sin desfase. Por casualidad no pasa: en otro episodio se van a decenas de s."""
        bs = np.abs([b for _, b, _ in r["ventanas"]])
        cerca = bs[bs <= 1.5 * SUB_IDENTIDAD]
        return (r["a"] == 1 and len(cerca) >= SUB_MIN_CADENA and len(cerca) >= 0.6 * len(bs)
                and np.median(cerca) <= SUB_IDENTIDAD)

    tope = max(r["suma"] for r in res)
    ident = [r for r in res if r["suma"] >= 0.5 * tope and identidad(r)]
    r = (max(ident, key=lambda r: r["suma"]) if ident
         else max(res, key=lambda r: r["suma"] * (1.05 if r["ref"] == "original" else 1.0)))
    r["identidad"] = bool(ident)
    r["sin_desfase"] = int((np.abs([b for _, b, _ in r["ventanas"]]) <= 1.5 * SUB_IDENTIDAD).sum())
    # las otras velocidades con la misma referencia que también encajan: entre dos parecidas (25/24 y 25/23,976, a un
    # 0,1 %) las ventanas no distinguen bien, y se decide luego con el subtítulo entero (tramos_subtitulo)
    r["alternativas"] = [x for x in res if x is not r and x["ref"] == r["ref"] and x["suma"] >= 0.6 * r["suma"]]
    return r


def agrupar(x, tol):
    """Valores que se repiten (al menos dos a <= tol), de más a menos repetidos: la mediana de cada grupo."""
    x, out = np.asarray(x, np.float64), []
    for xi in sorted(x, key=lambda xi: -int(np.sum(np.abs(x - xi) <= tol))):
        g = x[np.abs(x - xi) <= tol]
        if len(g) >= 2 and all(abs(np.median(g) - c) > tol for c in out):
            out.append(float(np.median(g)))
    return out


def encaje(ref, ini, fin, margen=5.0):
    """Parecido (correlación) entre la curva de los subtítulos ini-fin (instantes de ref) y la de voz, en la zona que
    cubren con `margen` s a cada lado: con qué se comparan dos formas de colocarlos."""
    if not len(ini):
        return -1.0
    n = len(ref["v"])
    a = int(np.clip(np.floor(a_muestras(ref, ini.min() - margen)), 0, n))
    b = int(np.clip(np.ceil(a_muestras(ref, fin.max() + margen)), 0, n))
    if b - a < 10 * FR_VOZ:
        return -1.0
    s = np.zeros(b - a, np.float32)
    for i, j in zip(np.clip(np.round(a_muestras(ref, ini)).astype(np.int64) - a, 0, b - a),
                    np.clip(np.round(a_muestras(ref, fin)).astype(np.int64) - a, 0, b - a)):
        s[i:j] = 1
    y = ref["v"][a:b]
    return float(np.corrcoef(s, y)[0, 1]) if s.std() > 0 and y.std() > 0 else -1.0


def afinar_desfase(ref, ini, fin, rango=0.6, paso=0.02):
    """Lo que hay que mover (s) unos subtítulos ya colocados para que encajen mejor con la voz, en ±rango."""
    ds = np.arange(-rango, rango + paso / 2, paso)
    return float(ds[int(np.argmax([encaje(ref, ini + d, fin + d) for d in ds]))])


def tramos_subtitulo(iv, ref, r):
    """Cómo se lleva un subtítulo de otra versión al tiempo de ref: (a, desfase de cada subtítulo), con t_ref = a·t + L.
    Para la velocidad elegida y sus alternativas, los tramos (tramos_velocidad); se queda la que mejor encaja con la
    voz con el subtítulo entero (T3 fabricado, a 25/24: las ventanas preferían 25/23,976, a un 0,1 %, y quedaba a 63 ms
    de media y 177 de máximo; con el encaje de todo, 10 y 11 ms)."""
    opciones = [tramos_velocidad(iv, ref, x) for x in [r] + r.get("alternativas", [])]
    return max(opciones, key=lambda o: encaje(ref, o[0] * iv[:, 0] + o[1], o[0] * iv[:, 1] + o[1]))


def tramos_velocidad(iv, ref, r):
    """tramos_subtitulo para una velocidad (la de r). Los desfases que se repiten (y quizá una deriva común) salen de
    las ventanas en cadena; cada subtítulo va al desfase con el que más voz cubre (Viterbi), sin cambiar por menos de
    SUB_MIN_TRAMO subtítulos; el desfase de cada tramo se afina con todos sus subtítulos. La deriva solo se queda si
    encaja mejor que sin ella (con dos tramos, una deriva casual de 600 ppm descolocaba el segundo 400 ms)."""
    pts = np.array([(t, b) for (t, b, _), o in zip(r["ventanas"], r["cadena"]) if o])
    t, b, k = pts[:, 0], pts[:, 1], 0.0
    for _ in range(2):
        niveles = agrupar(b - k * t, 0.3) or [float(np.median(b - k * t))]
        d = np.abs((b - k * t)[:, None] - np.array(niveles)[None, :])
        lab = np.where(d.min(1) <= 0.3, d.argmin(1), -1)
        m = lab >= 0
        if m.sum() >= 4 and np.ptp(t[m]) >= 120:
            X = np.zeros((int(m.sum()), len(niveles) + 1))
            X[np.arange(int(m.sum())), lab[m]] = 1
            X[:, -1] = t[m]
            k = float(np.linalg.lstsq(X, b[m], rcond=None)[0][-1])
    opciones = [_tramos_con_deriva(iv, ref, float(r["a"]), 0.0, t, b)]
    if abs(k) * np.ptp(iv) >= 0.08:          # menos de 80 ms en todo el subtítulo: ni se prueba
        opciones.append(_tramos_con_deriva(iv, ref, float(r["a"]) + k, k, t, b))
    puntua = lambda o: encaje(ref, o[0] * iv[:, 0] + o[1], o[0] * iv[:, 1] + o[1])
    return max(opciones, key=lambda o: puntua(o) + (0.005 if o is opciones[0] else 0.0))


def _tramos_con_deriva(iv, ref, a, k, t, b):
    """tramos_subtitulo con una deriva k ya decidida (t, b: las ventanas en cadena). Devuelve (a, L)."""
    niveles = agrupar(b - k * t, 0.3) or [float(np.median(b - k * t))]
    if len(niveles) == 1:
        L = np.full(len(iv), niveles[0])
        return a, L + afinar_desfase(ref, a * iv[:, 0] + L, a * iv[:, 1] + L)
    base = float(np.mean(ref["v"]))
    E = np.stack([voz_media(ref, a * iv[:, 0] + L, a * iv[:, 1] + L) - base for L in niveles], 1)
    n, S = E.shape
    niv = np.array(niveles)
    dp, bp, idx = E[0].copy(), np.zeros((n, S), np.int32), np.arange(S)
    # pasar a un desfase menor solo donde entre dos subtítulos cabe lo que se quita: si no, el subtítulo saldría antes
    # que el anterior (Black Mask, 01-11-2026: con diálogo casi continuo dos desfases cubrían voz igual y se alternaban
    # línea a línea; los subtítulos salían desordenados y solapados)
    for f in range(1, n):
        hueco = a * (iv[f, 0] - iv[f - 1, 1])
        cabe = niv[None, :] >= niv[:, None] - hueco - SUB_TOL_ORDEN       # [de, a]
        cand = np.where(cabe, dp[:, None] - SUB_PEN, -np.inf)
        cand[idx, idx] = dp                                                # seguir en el mismo no cuesta
        bp[f] = np.argmax(cand, 0)
        dp = cand[bp[f], idx] + E[f]
    camino = np.zeros(n, int); camino[-1] = int(np.argmax(dp))
    for f in range(n - 1, 0, -1):
        camino[f - 1] = bp[f, camino[f]]
    tramos, i0 = [], 0                       # [primero, último, nivel]
    for f in range(1, n + 1):
        if f == n or camino[f] != camino[f - 1]:
            tramos.append([i0, f - 1, int(camino[i0])]); i0 = f

    def huecos_para(c0, c1, d):
        """Subtítulos de c0 a c1 tras los que cabe bajar el desfase d (< 0) sin desordenar."""
        return [c for c in range(c0, c1 + 1) if a * (iv[c + 1, 0] - iv[c, 1]) >= -d - SUB_TOL_ORDEN]

    def cabe_junto(x, y):
        """¿Se puede pasar del tramo x al y (seguidos) sin que un subtítulo salga antes que el anterior?"""
        d = niveles[y[2]] - niveles[x[2]]
        return d >= -SUB_TOL_ORDEN or bool(huecos_para(x[0], y[1] - 1, d))

    def se_puede_unir(tramos, i, j):
        """¿Puede el tramo i pasar al desfase de su vecino j sin que un subtítulo salga antes que el anterior?"""
        unido = [min(tramos[j][0], tramos[i][0]), max(tramos[j][1], tramos[i][1]), tramos[j][2]]
        antes = tramos[min(i, j) - 1] if min(i, j) > 0 else None       # los que quedan pegados al unido
        despues = tramos[max(i, j) + 1] if max(i, j) + 1 < len(tramos) else None
        return (antes is None or cabe_junto(antes, unido)) and (despues is None or cabe_junto(unido, despues))

    def unir(tramos, i, j):
        """El tramo i pasa al desfase de su vecino j (y se juntan los seguidos que queden con el mismo)."""
        tramos[j][0], tramos[j][1] = min(tramos[j][0], tramos[i][0]), max(tramos[j][1], tramos[i][1])
        del tramos[i]
        unidos = [tramos[0]]
        for tr in tramos[1:]:
            if tr[2] == unidos[-1][2]:
                unidos[-1][1] = tr[1]
            else:
                unidos.append(tr)
        return unidos

    fijos = set()                            # tramos cortos que no se pueden unir a ningún vecino sin desordenar
    while len(tramos) > 1:                   # tramos de pocos subtítulos: al vecino
        libres = [i for i in range(len(tramos)) if (tramos[i][0], tramos[i][1]) not in fijos]
        if not libres:
            break
        i = min(libres, key=lambda i: tramos[i][1] - tramos[i][0])
        if tramos[i][1] - tramos[i][0] + 1 >= SUB_MIN_TRAMO:
            break
        vecinos = [j for j in (i - 1, i + 1) if 0 <= j < len(tramos) and se_puede_unir(tramos, i, j)]
        if not vecinos:
            fijos.add((tramos[i][0], tramos[i][1]))
            continue
        tramos = unir(tramos, i, max(vecinos, key=lambda j: tramos[j][1] - tramos[j][0]))
    # cada tramo, comprobado también con la forma de sus subtítulos (frases y pausas), no solo con la voz que cubren:
    # en una escena de acción hay voz (gritos, golpes) con cualquier desfase (Black Mask, 1:03:53: 8 líneas a -60,9 s
    # con encaje 0,05, frente a 0,38 con el desfase de sus vecinos)
    def encaje_con(tr, lv):
        sl = slice(tr[0], tr[1] + 1)
        return encaje(ref, a * iv[sl, 0] + niveles[lv], a * iv[sl, 1] + niveles[lv])

    cambiado = True
    while cambiado and len(tramos) > 1:
        cambiado = False
        for i, tr in enumerate(tramos):
            propio = encaje_con(tr, tr[2])
            mejor = max(((j, encaje_con(tr, tramos[j][2])) for j in (i - 1, i + 1) if 0 <= j < len(tramos)),
                        key=lambda x: x[1])
            if mejor[1] >= propio + SUB_MEJORA_TRAMO and se_puede_unir(tramos, i, mejor[0]):
                tramos = unir(tramos, i, mejor[0])
                cambiado = True
                break
    nivel = [niveles[lv] for _, _, lv in tramos]
    # dónde se cambia de desfase: si la otra versión tiene metraje de más ahí, entre dos subtítulos hay un hueco de al
    # menos lo que dura (T3 fabricado: Viterbi lo ponía 4 subtítulos tarde); si no, el corte que mejor encaja con la voz
    for q in range(len(tramos) - 1):
        frontera, d = tramos[q][1], nivel[q + 1] - nivel[q]
        cand = range(max(tramos[q][0], frontera - 8), min(tramos[q + 1][1] - 1, frontera + 8) + 1)
        huecos = huecos_para(cand.start, cand.stop - 1, d) if d < -0.3 else []
        if d < -0.3 and not huecos:          # más lejos, pero nunca desordenando
            huecos = huecos_para(tramos[q][0], tramos[q + 1][1] - 1, d)
        if huecos:
            nueva = min(huecos, key=lambda c: abs(c - frontera))
        else:
            zona = slice(max(0, frontera - 12), min(len(iv), frontera + 13))

            def puntua(c):
                L = np.where(np.arange(len(iv)) <= c, nivel[q], nivel[q + 1])[zona]
                return encaje(ref, a * iv[zona, 0] + L, a * iv[zona, 1] + L)

            nueva = max(cand, key=puntua) if len(cand) else frontera
        tramos[q][1], tramos[q + 1][0] = nueva, nueva + 1
    L = np.empty(len(iv))
    for (i0, i1, _), lv in zip(tramos, nivel):
        sl = slice(i0, i1 + 1)          # el desfase de cada tramo, afinado con todos sus subtítulos
        L[sl] = lv + afinar_desfase(ref, a * iv[sl, 0] + lv, a * iv[sl, 1] + lv)
    return a, L


def bloques_desplazados(ini, fin, ref, colocado=None):
    """Bloques de subtítulos seguidos desplazados respecto a sus vecinos (una errata en un trozo del archivo):
    [(primero, último, corrección en s, ¿lo confirma la voz?)]. Subtítulo a subtítulo la voz no lo dice (con diálogo
    seguido, moverlo dos segundos también cae sobre voz), pero un bloque desplazado deja huella en el propio archivo:
    un solape de más de SUB_BLOQUE_MIN s en un extremo y, en el otro, un hueco de al menos lo mismo. Entre los bloques
    posibles, el que mejor encaja con la voz (en un minuto alrededor), si no encaja claramente peor que como estaba: en
    algunos trozos la voz no distingue (Trailer Park Boys 1x01, 2:30-2:45) y la huella basta. ini, fin: los subtítulos
    ya en el tiempo de ref, en el orden del archivo, antes de recortar solapes. colocado: los que van colocados en
    pantalla (carteles), cuyos solapes son a propósito."""
    n = len(ini)
    huecos = ini[1:] - fin[:-1]
    g0 = float(np.clip(np.median(huecos[huecos > 0]) if (huecos > 0).any() else 0.1, 0.04, 0.5))
    colocado = np.zeros(n, bool) if colocado is None else colocado
    cand = []
    for k in range(n - 1):
        o = fin[k] - ini[k + 1]
        # a propósito: dos que empiezan a la vez, uno que cabe dentro del otro, un cartel colocado en pantalla. Si el
        # siguiente empieza antes que este, es justo lo que deja un bloque desplazado
        if (o < SUB_BLOQUE_MIN or abs(ini[k + 1] - ini[k]) < 0.3 or colocado[k] or colocado[k + 1]
                or (ini[k] <= ini[k + 1] and fin[k + 1] <= fin[k])):
            continue
        d = o + g0                       # lo que se ha movido el bloque
        # el bloque acaba en k y va d tarde: antes de su primero hay un hueco de al menos d (más la pausa que hubiera)
        cand += [(i, k, -d) for i in range(k - 1, max(0, k - 25), -1) if huecos[i - 1] >= d - 0.3]
        # el bloque empieza en k + 1 y va d pronto: después de su último hay un hueco de al menos d
        cand += [(k + 1, j, d) for j in range(k + 2, min(n - 1, k + 26)) if huecos[j] >= d - 0.3]
    por_solape = {}
    for i, j, d in cand:                 # de cada solape, el bloque que mejor encaja (a igualdad, el más corto)
        zona = (ini >= min(ini[i], ini[j]) - 30) & (fin <= max(fin[i], fin[j]) + 30)
        ini2, fin2 = ini.copy(), fin.copy()
        ini2[i:j + 1] += d
        fin2[i:j + 1] += d
        mejora = encaje(ref, ini2[zona], fin2[zona]) - encaje(ref, ini[zona], fin[zona])
        clave = j if d < 0 else i - 1    # el solape del que sale
        mejor = por_solape.get(clave)
        if mejora >= -0.02 and (mejor is None or (mejora, -(j - i)) > (mejor[0], -(mejor[2] - mejor[1]))):
            por_solape[clave] = (mejora, i, j, d)
    elegidos = []
    for mejora, i, j, d in sorted(por_solape.values(), reverse=True):    # sin que se pisen
        if all(j < i2 or i > j2 for i2, j2, _, _ in elegidos):
            elegidos.append((i, j, d, mejora > 0))
    return sorted(elegidos)


RE_SRT_LINEA = re.compile(rb"(\d+):(\d{1,2}):(\d{1,2})[,.](\d{1,3})\s*-->\s*(\d+):(\d{1,2}):(\d{1,2})[,.](\d{1,3})(.*)")


def leer_srt(data):
    """Las entradas de un .srt en el orden del archivo, [dict(s, e, cs, ce, resto, texto)], y su BOM. Aguanta saltos de
    línea raros (\\r\\r\\n de una doble conversión, como el de Trailer Park Boys), numeración que falte o esté mal y
    milisegundos con menos cifras. cs, ce: los campos (h, m, s, ms) tal cual, para arreglar una cifra equivocada."""
    bom = data[:3] if data.startswith(b"\xef\xbb\xbf") else b""
    lineas = data[len(bom):].replace(b"\r\r\n", b"\n").replace(b"\r\n", b"\n").replace(b"\r", b"\n").split(b"\n")
    seg = lambda h, m, s, ms: int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 10 ** len(ms)
    ents = []
    for ln in lineas:
        m = RE_SRT_LINEA.search(ln)
        if m:
            g = m.groups()
            if ents and ents[-1]["texto"] and ents[-1]["texto"][-1].strip().isdigit():
                ents[-1]["texto"].pop()         # el número de la entrada nueva
            ents.append(dict(s=seg(*g[0:4]), e=seg(*g[4:8]), cs=g[0:4], ce=g[4:8], resto=g[8].rstrip(), texto=[]))
        elif ents:
            ents[-1]["texto"].append(ln.rstrip(b"\r"))
    for e in ents:
        while e["texto"] and not e["texto"][-1].strip():
            e["texto"].pop()
        while e["texto"] and not e["texto"][0].strip():
            e["texto"].pop(0)
    return ents, bom


def tiempo_lectura(texto):
    """Lo que se tarda en leer un subtítulo (s): medio segundo más 15 letras por segundo, entre 0,8 y 7 s."""
    letras = len(re.sub(rb"<[^>]*>|\{[^}]*\}", b"", b" ".join(texto)).strip())
    return min(7.0, max(0.8, 0.5 + letras / 15))


def arreglo_de_cifra(campos, vecinos, lo, hi):
    """Un tiempo con una cifra equivocada (01:02:03 por 00:02:03; 00:12:03 por 00:02:03): el que sale poniéndole la
    hora y/o los minutos de un vecino, si cae entre lo y hi. Solo si hay uno. None si no."""
    h, m, s, ms = campos
    seg = lambda h, m: int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 10 ** len(ms)
    cand = {round(seg(h2, m2), 3) for vh, vm in vecinos for h2, m2 in ((vh, m), (h, vm), (vh, vm))}
    cand = [c for c in cand if lo <= c <= hi]
    return cand[0] if len(cand) == 1 else None


def corregir_erratas_srt(ents, notas=None):
    """Erratas de tiempos del propio .srt, en su propio tiempo (antes de llevarlo a ningún sitio): duplicados, tiempos
    muy fuera de orden (una cifra mal tecleada), inicio y final cambiados, duraciones imposibles o disparatadas y el
    orden. Los solapes y los subtítulos demasiado cortos van después (retocar_srt), cuando ya se han devuelto a su
    sitio los bloques desplazados, cuya huella es justo un solape; y se ordenan al final, porque un bloque desplazado
    solo va seguido en el orden del archivo. Devuelve (entradas en ese orden, {tipo de errata: cuántas})."""
    notas = {} if notas is None else notas
    nota = lambda k: notas.__setitem__(k, notas.get(k, 0) + 1)
    vistos, limpias = set(), []
    for e in ents:
        clave = (round(e["s"], 3), round(e["e"], 3), b"\n".join(e["texto"]))
        if clave in vistos:
            nota("duplicados")
            continue
        vistos.add(clave)
        limpias.append(e)
    ents = limpias
    for i, e in enumerate(ents):
        ant = ents[i - 1] if i > 0 else None
        sig = ents[i + 1] if i + 1 < len(ents) else None
        lo, hi = (ant["s"] if ant else 0.0), (sig["s"] if sig else float("inf"))
        if (ant and sig and lo > hi) or lo - 0.5 <= e["s"] <= hi + 0.5:
            continue
        # entradas cambiadas de sitio caen entre las de alrededor (aunque haya 22 s de pausa entre ellas: Trailer Park
        # Boys fabricado): eso lo arregla ordenar. Lejos de todas las de alrededor, entre dos vecinos que sí van en
        # orden, casi siempre es una cifra mal tecleada (una hora, unos minutos)
        cerca = [ents[j]["s"] for j in range(max(0, i - 4), min(len(ents), i + 5)) if j != i]
        if min(cerca) - 0.5 <= e["s"] <= max(cerca) + 0.5:
            continue
        vecinos = [(v["cs"][0], v["cs"][1]) for v in (ant, sig) if v]
        s2 = arreglo_de_cifra(e["cs"], vecinos, lo, hi if sig else lo + 3600)
        dur = e["e"] - e["s"]
        if s2 is None:              # se recoloca entre los dos, con su duración si cabe
            s2 = (ant["e"] + 0.1) if ant else max(0.0, hi - 2.0)
            if sig:
                s2 = min(s2, hi - 0.5)
            nota("fuera de orden recolocados")
        else:
            nota("tiempos con una cifra mal")
        # el final: el suyo si cuadra con el inicio arreglado; si no, con su duración (la misma errata en los dos)
        e["e"] = (e["e"] if 0 < e["e"] - s2 <= 15 else
                  s2 + (dur if 0 < dur <= 15 else tiempo_lectura(e["texto"])))
        e["s"] = s2
    for i, e in enumerate(ents):
        dur, lect = e["e"] - e["s"], tiempo_lectura(e["texto"])
        # un cartel colocado en pantalla puede durar lo que quiera (un rótulo que se queda en toda la escena)
        largo = dur > 15 and dur > 3 * lect and not RE_SUB_COLOCADO.search(b" ".join(e["texto"]))
        if dur > 0 and not largo:
            continue
        if -15 <= dur < 0:          # el final antes que el inicio: los dos cambiados de sitio
            e["s"], e["e"] = e["e"], e["s"]
            nota("con inicio y final cambiados")
            continue
        sig = next((x["s"] for x in ents[i + 1:] if x["s"] > e["s"]), float("inf"))
        e2 = arreglo_de_cifra(e["ce"], [(e["cs"][0], e["cs"][1])], e["s"] + 0.3, min(e["s"] + 15, sig + 0.5))
        e["e"] = e2 if e2 is not None else e["s"] + max(min(lect, sig - e["s"] - 0.04), 0.5)
        nota("duraciones imposibles" if dur <= 0 else "duraciones disparatadas")
    return ents, notas


def retocar_srt(ents, notas):
    """Lo último de las erratas, ya con los bloques en su sitio: solapes pequeños con el siguiente (los grandes se
    dejan: suelen ser a propósito, un cartel y un diálogo a la vez) y subtítulos demasiado cortos para leerlos."""
    nota = lambda k: notas.__setitem__(k, notas.get(k, 0) + 1)
    for a, b in zip(ents, ents[1:]):
        sol, dur = a["e"] - b["s"], a["e"] - a["s"]
        if 0 < sol <= min(1.0, 0.5 * dur) and b["s"] - a["s"] >= 0.3:
            a["e"] = max(b["s"] - 0.04, a["s"] + 0.2)
            nota("solapes")
    for i, e in enumerate(ents):
        if e["e"] - e["s"] < 0.3:
            sig = ents[i + 1]["s"] if i + 1 < len(ents) else float("inf")
            nuevo = min(e["s"] + tiempo_lectura(e["texto"]), sig - 0.04)
            if nuevo > e["e"] + 0.05:
                e["e"] = nuevo
                nota("demasiado cortos")
    return ents, notas


def escribir_srt(ents, bom=b""):
    """El .srt (bytes) con las entradas renumeradas, saltos de línea de Windows y el texto tal cual."""
    out = []
    for n, e in enumerate(ents, 1):
        out.append(b"%d\r\n%s --> %s%s\r\n%s\r\n" % (n, srt_tiempo(e["s"]).encode(), srt_tiempo(e["e"]).encode(),
                                                    e["resto"], b"\r\n".join(e["texto"])))
    return bom + b"\r\n".join(out)


def mismo_nombre(sub, video):
    """¿El subtítulo se llama como el vídeo (quizá con el idioma detrás: «x.es-es.srt»)?"""
    a, b = (os.path.splitext(os.path.basename(x))[0].lower() for x in (sub, video))
    return a == b or a.startswith(b + ".")


def preparar_subtitulo(src, mapa, refs, t_audio, defecto, nombre, datos=None, duracion=None):
    """Un subtítulo (.srt, o .ass si src termina así) llevado al tiempo del audio sincronizado, sin escribirlo. Con refs
    (curvas de voz del doblaje y del original) averigua para qué versión está hecho, corrige sus erratas y lo convierte;
    sin refs, se da por hecho que va con el doblaje (como antes). defecto: "doblaje" u "original", si no se puede saber.
    duracion: la del resultado (s), si se sabe: lo que caiga después tampoco está.
    Devuelve (bytes, líneas, lo que se ha visto para el informe, avisos)."""
    if datos is None:
        with open(src, "rb") as f:
            datos = f.read()
    # en los avisos, «subtítulo Archivo.srt», pero no «subtítulo subtítulo del doblaje 1»
    quien = nombre if nombre.startswith("subtítulo") else f"subtítulo {nombre}"
    ass = src.lower().endswith((".ass", ".ssa"))
    if refs is None:
        datos, n = (_ass_mapeado if ass else _srt_mapeado)(datos, mapa, t_audio)
        return datos, n, [], []
    vel = Fraction(*mapa["vel"]) if mapa.get("vel") else Fraction(1)
    if ass:
        mos = list(ASS_T.finditer(datos))
        t = lambda g: int(g[0]) * 3600 + int(g[1]) * 60 + int(g[2]) + int(g[3]) / 100
        iv0 = np.array([(t(m.groups()[1:5]), t(m.groups()[5:9])) for m in mos]).reshape(-1, 2)
        ents, notas = None, {}
        colocado = np.array([bool(RE_SUB_COLOCADO.search(datos[m.end():datos.find(b"\n", m.end())]))
                             or not m.group(1).startswith(b"Dialogue") for m in mos], bool)
    else:
        ents, bom = leer_srt(datos)
        if not ents:                # otro formato (un WebVTT sin horas...): se deja como está, en vez de vaciarlo
            return datos, 0, [f"{nombre}: no se ha encontrado ningún tiempo de .srt; se deja como está"], [
                f"{quien}: no parece un .srt (no se ha encontrado ningún tiempo); se ha dejado como estaba"]
        ents, notas = corregir_erratas_srt(ents)
        iv0 = np.array([(e["s"], e["e"]) for e in ents]).reshape(-1, 2)
        colocado = np.array([bool(RE_SUB_COLOCADO.search(b" ".join(e["texto"]))) for e in ents], bool)
    # los carteles colocados en pantalla (y los comentarios de un ASS) no son voz: no cuentan para averiguar a qué
    # versión pertenece (un cartel de 15 s estropeaba una ventana), pero se llevan igual que los de alrededor
    usar = ~colocado if (~colocado).sum() >= 20 else np.ones(len(iv0), bool)
    orden = np.flatnonzero(usar)[np.argsort(iv0[usar, 0], kind="stable")]
    iv = iv0[orden]
    informe, avisos = [], []
    r = medir_subtitulo(iv, refs) if len(iv) >= 20 else None
    a, L = 1.0, np.zeros(len(iv))
    if r is None:
        donde = defecto
        informe.append(f"{nombre}: no se puede comprobar para qué versión está hecho (se parece poco a la voz); se trata "
                       f"como del {donde}")
        avisos.append(f"{quien}: no se ha podido comprobar para qué versión está hecho; se ha tratado como "
                      f"del {donde}, conviene comprobarlo")
    else:
        donde = r["ref"]
        if r["identidad"]:
            informe.append(f"{nombre}: hecho para el {donde} (encaja con su voz sin desfase en {r['sin_desfase']} de "
                           f"{r['total']} minutos)")
        else:
            a, L = tramos_subtitulo(iv, refs[donde], r)
            vel_txt = ("a la misma velocidad" if abs(a - 1) < 5e-5 else
                       f"va un {abs(a - 1) * 100:.2f} % más {'rápida' if a > 1 else 'lenta'}")
            saltos = [i for i in range(1, len(L)) if abs(L[i] - L[i - 1]) >= 0.05]
            desf = (f"desfase {L[0]:+.2f} s" if not saltos else
                    f"{len(saltos) + 1} tramos, desfases de {L.min():+.2f} a {L.max():+.2f} s (cambia hacia "
                    + ", ".join(mmss(iv[i, 0]) for i in saltos[:6]) + (" ..." if len(saltos) > 6 else "") + ")")
            informe.append(f"{nombre}: hecho para otra versión; respecto al {donde}, {vel_txt}, {desf} ({r['n']} de "
                           f"{r['total']} minutos en el mismo desfase); se convierte")
            para = ("ni para este doblaje ni para el original" if set(refs) <= {"doblaje", "original"}
                    else "para este vídeo")
            avisos.append(f"{quien}: no estaba hecho {para} (otra versión); se ha convertido, conviene "
                          "comprobarlo")
    Lf = np.empty(len(iv0))             # el desfase de cada subtítulo, en el orden del archivo
    Lf[orden] = L
    fuera = np.flatnonzero(~usar)       # los que no han contado: el del subtítulo más cercano en el tiempo
    if len(fuera) and len(iv):
        cerca = np.clip(np.searchsorted(iv[:, 0], iv0[fuera, 0]), 0, len(iv) - 1)
        Lf[fuera] = L[cerca]
    if r is not None and not ass:
        # bloques desplazados: en el orden del archivo, donde van seguidos (ordenados por tiempo, los vecinos que no
        # se movieron se meten entre ellos). En un ASS los solapes son normales (capas, carteles): ahí no se buscan
        for i, j, d, voz in bloques_desplazados(a * iv0[:, 0] + Lf, a * iv0[:, 1] + Lf, refs[donde], colocado):
            Lf[i:j + 1] += d
            informe.append(f"{nombre}: {j - i + 1} subtítulos seguidos ({mmss(iv0[i, 0])}-{mmss(iv0[j, 1])}) iban "
                           f"{-d:+.2f} s desplazados respecto a los de alrededor: se devuelven a su sitio"
                           + ("" if voz else " (por la huella que dejaban; la voz ahí no lo distingue)"))
            if not voz:
                avisos.append(f"{quien}: {mmss(iv0[i, 0])}-{mmss(iv0[j, 1])} devueltos a su sitio solo por "
                              "la huella que dejaban en el archivo, conviene comprobarlo")
    final = ((lambda x: mapear(x - t_audio, mapa)) if donde == "doblaje" else (lambda x: max(0.0, x / float(vel))))
    nuevo = np.array([(final(a * s + l), final(a * e + l)) for (s, e), l in zip(iv0, Lf)]).reshape(-1, 2)
    if duracion:
        # lo de después del final del resultado tampoco está, como lo de antes del principio (Black Mask: el final
        # de la otra versión y su crédito, dos minutos después del final del vídeo, alargaban el .mkv)
        nuevo = np.minimum(nuevo, duracion)
    if ass:
        cuenta = iter(range(len(mos)))

        def rep(m):
            i = next(cuenta)
            return m.group(1) + ass_tiempo(nuevo[i, 0]) + b"," + ass_tiempo(nuevo[i, 1]) + b","

        return ASS_T.sub(rep, datos), len(mos), informe, avisos
    quedan = []
    for e, (s, f) in zip(ents, nuevo):
        if f - s >= 0.05:            # un subtítulo de un trozo que se ha quitado queda en nada: fuera
            e["s"], e["e"] = s, f
            quedan.append(e)
    if any(x["s"] > y["s"] for x, y in zip(quedan, quedan[1:])):
        notas["fuera de orden (ordenados)"] = sum(x["s"] > y["s"] for x, y in zip(quedan, quedan[1:]))
        quedan.sort(key=lambda e: e["s"])
    if len(quedan) < len(ents):
        informe.append(f"{nombre}: {len(ents) - len(quedan)} subtítulos caen en trozos que no están en el resultado; "
                       "se quitan")
    retocar_srt(quedan, notas)
    if notas:
        informe.append(f"{nombre}: erratas del archivo corregidas: "
                       + ", ".join(f"{v} {k}" for k, v in notas.items()))
    if b"\r\r\n" in datos:
        informe.append(f"{nombre}: saltos de línea mal formados (\\r\\r\\n): se escriben bien")
    return escribir_srt(quedan, bom), len(quedan), informe, avisos


def ruta_subs_solo(video, idioma="es-ES", carpeta=None):
    """Subtítulo corregido del modo «solo subtítulos»: junto al vídeo o en `carpeta` (si ya hay uno con la etiqueta
    de antes, «[spa]», ese: lo ya hecho se reconoce)."""
    base = os.path.splitext(os.path.basename(video))[0]
    ruta = os.path.join(carpeta or os.path.dirname(video), f"{base}_[{idioma}]_SUBS_SYNC.srt")
    viejo = os.path.join(os.path.dirname(ruta), f"{base}_[spa]_SUBS_SYNC.srt")
    return viejo if not os.path.exists(ruta) and os.path.exists(viejo) else ruta


def sincronizar_subtitulos(video, sub_path, out_path, p=print):
    """Modo «solo subtítulos»: el vídeo ya está hecho, con su audio (un final ya muxeado), y se le ajusta un subtítulo.
    Se compara con la voz del propio vídeo (con la primera pista y con la primera en otro idioma: la doblada y la
    versión original van con la misma imagen), se corrigen sus erratas y, si estaba hecho para otra versión, su
    desfase, velocidad o montaje; se guarda en out_path con su informe al lado. Devuelve los avisos."""
    log = []

    def p2(msg=""):
        p(msg)
        log.append(msg)

    p2(f"Vídeo: {os.path.basename(video)}")
    p2(f"Subtítulo: {os.path.basename(sub_path)}")
    pistas = pistas_audio(video)
    if not pistas:
        raise RuntimeError("el vídeo no tiene audio con el que comparar el subtítulo")
    elegidas = [pistas[0]] + [s for s in pistas[1:] if idioma_pista(s) != idioma_pista(pistas[0])][:1]
    refs = {}
    for s in elegidas:
        refs[f"vídeo ({idioma_iso(idioma_pista(s)) or 'pista ' + str(s['index'])})"] = voz_referencia(
            cargar(video, s, AR, 2), max(0.0, float(s.get("start_time") or 0)))
    p2("Se compara con la voz de: " + ", ".join(k[len("vídeo ("):-1] for k in refs))
    mapa = dict(pre=0.0, k=0.0, L=[0.0], inicios=[0.0], fines=[1e12], vel=[1, 1])     # el vídeo tal cual
    # si no se puede comprobar, se deja como está (en el tiempo del vídeo)
    fin_video = max(r["t0"] + len(r["v"]) * r["escala"] / FR_VOZ for r in refs.values())
    datos, n, informe, avisos = preparar_subtitulo(sub_path, mapa, refs, 0.0, next(iter(refs)),
                                                   os.path.basename(sub_path), duracion=fin_video)
    for x in informe:
        p2(f"Subtítulos: {x}")
    p2("Avisos: " + ("ninguno" if not avisos else ""))
    for a in avisos:
        p2(f"  - {a}")
    with open(out_path, "xb") as f:
        f.write(datos)
    p2(f"Subtítulos: {n} líneas ajustadas -> {out_path}")
    with open(os.path.splitext(out_path)[0] + "_informe.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(log) + "\n")
    return avisos


def muxear_subtitulo(video, srt, mkv, idioma="es-ES", titulo="Castellano", p=print):
    """MKV nuevo con el vídeo tal cual (todas sus pistas) y el subtítulo añadido detrás de los que ya tuviera, sin
    marcarlo como predeterminado. El vídeo de partida no se toca nunca. Devuelve la línea del informe."""
    if os.path.exists(mkv):
        linea = f"Ya existe el vídeo muxeado, no se toca: {mkv}"
        p(linea)
        return linea
    cod, mkvmerge = codificacion_texto(srt), ruta_mkvmerge()
    if mkvmerge:
        r = subprocess.run([mkvmerge, "-o", mkv, video, "--language", f"0:{idioma}", "--track-name", f"0:{titulo}",
                            "--default-track-flag", "0:no", "--sub-charset", f"0:{cod}", srt],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", **SIN_VENTANA)
        if r.returncode >= 2:           # 1 = terminó con advertencias
            borrar_si_existe(mkv)
            raise RuntimeError("mkvmerge falló: " + " ".join((r.stdout or r.stderr).strip().splitlines()[-2:]))
        etiqueta, con = idioma, "mkvmerge"
    else:
        etiqueta = (LEGADO.get(idioma.split("-")[0].lower(), idioma[:3].lower())
                    if "-" in idioma or len(idioma) == 2 else idioma)
        n = len(pistas_sub_doblaje(video))      # el nuevo va detrás de los que ya tenga
        r = subprocess.run(["ffmpeg", "-v", "error", "-n", "-i", video, "-sub_charenc", cod, "-i", srt, "-map", "0",
                            "-map", "1:s:0", "-c", "copy", f"-metadata:s:s:{n}", f"language={etiqueta}",
                            f"-metadata:s:s:{n}", f"title={titulo}", f"-disposition:s:{n}", "0", mkv],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", **SIN_VENTANA)
        if r.returncode != 0:
            borrar_si_existe(mkv)
            raise RuntimeError("ffmpeg falló al muxear: " + " ".join(r.stderr.strip().splitlines()[-2:]))
        con = f"ffmpeg; sin MKVToolNix el idioma queda «{etiqueta}» en vez de «{idioma}»"
    linea = (f"Muxeado: {mkv} (primer audio sin tocar; subtítulo {etiqueta} «{titulo}» añadido detrás de los que "
             f"tuviera; con {con})")
    p(linea)
    return linea


# ---------------------------------------------------------------- forzados quemados en la imagen
# Algunos doblajes (emisiones de TV) traen los forzados (carteles, canciones) quemados en la imagen. Se buscan
# en la parte de abajo: letra blanca con borde negro que se queda quieta mientras el fondo cambia. Se leen
# con el OCR de Windows y pasan a un .srt con los mismos cortes que el audio.
# Crash Canyon 1x01 (MTV, 720x400): 49 forzados en ~40 s, a la vez que su cambio de plano; los carteles en
# mayúsculas sin errores, alguna palabra de las canciones en cursiva mal leída.

FZ_FRANJA = 0.55                 # se busca de esta altura hacia abajo
FZ_CLARO, FZ_OSCURO = 205, 90    # luma de la letra (blanca) y de su borde (negro)
FZ_NEUTRO = 10                   # la letra es blanca sin color: el crema de un cartel dibujado no vale
FZ_PASO = 5                      # se mira 1 de cada 5 fotogramas; los cambios se afinan al fotograma
FZ_ALTO = 576                    # los vídeos más altos se reducen a esta altura (sobra para leer)
FZ_ESCALA, FZ_MARGEN = 3, 20     # ampliación y margen blanco de las imágenes que lee el OCR
RE_PTS = re.compile(rb"\bn:\s*\d+\s+pts:\s*-?\d+\s+pts_time:\s*(-?[\d.]+)")
_NEUTRO = np.zeros(256, bool)
_NEUTRO[128 - FZ_NEUTRO:128 + FZ_NEUTRO + 1] = True
# también letra amarilla con borde oscuro (Jeff y unos aliens, Comedy Central: Y ~206 con p10 ~177, U 39-86,
# V 125-132): menos clara que la blanca, así que lleva su propio umbral de luma. El margen de color es estrecho: con
# V hasta 165 entraban la piel, los beis y los naranjas de los dibujos (223 tramos falsos en un episodio, y los
# subtítulos de las escenas con esos colores se perdían entre ellos)
FZ_CLARO_AM = 165
_AM_U = np.arange(256) <= 95
_AM_V = (np.arange(256) >= 120) & (np.arange(256) <= 138)


def _cerca(m, eje, r):
    """True donde hay un True a menos de r píxeles antes y también después, a lo largo del eje."""
    a, d = np.zeros_like(m), np.zeros_like(m)
    for k in range(1, r + 1):
        if eje == 1:
            a[:, k:] |= m[:, :-k]; d[:, :-k] |= m[:, k:]
        else:
            a[k:] |= m[:-k]; d[:-k] |= m[k:]
    return a & d


def _iou(a, b):
    u = np.count_nonzero(a | b)
    return np.count_nonzero(a & b) / u if u else 0.0


def escanear_quemados(path, idx, deco="cpu", p=print):
    """Tramos de la franja inferior con texto quemado. Devuelve ([dict(t0, t1, img, off)], ancho, alto):
    tiempos del contenedor; img, la letra en negro sobre blanco y ampliada; off, su esquina en el fotograma.
    deco: con qué se decodifica (clave de DECODIFICADORES); si la GPU falla, se usa la CPU."""
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", str(idx), "-show_entries",
                        "stream=width,height", "-of", "json", path],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", check=True, **SIN_VENTANA)
    s = json.loads(r.stdout)["streams"][0]
    f = min(1.0, FZ_ALTO / s["height"])
    W, H = int(s["width"] * f) // 4 * 4, int(s["height"] * f) // 4 * 4
    Y0 = int(H * FZ_FRANJA) // 4 * 4
    BH = H - Y0
    esc = H / 400
    R = int(np.clip(round(5 * esc), 3, 8))          # grosor máximo del trazo, a cada lado
    c_min = int(150 * esc * esc)                    # píxeles de letra para que cuente como texto
    vf = SIN_COLOR + (f"scale={W}:{H}:flags=area," if f < 1 else "") + f"crop={W}:{BH}:0:{Y0},format=yuv420p,showinfo"

    def rasgos(fr):
        """Píxeles de letra: claros, blancos sin color o amarillos, y con negro a los dos lados a menos de R (trazo
        fino con borde). Devuelve (letra, (blanco, amarillo)), los colores a media resolución, como el croma."""
        y, u, v = fr
        neu = _NEUTRO[u] & _NEUTRO[v]
        ama = _AM_U[u] & _AM_V[v]
        umbral = np.where(ama, FZ_CLARO_AM, FZ_CLARO).astype(np.uint8)
        claro = ((y.reshape(BH // 2, 2, W // 2, 2) >= umbral[:, None, :, None])
                 & (neu | ama)[:, None, :, None]).reshape(BH, W)
        osc = y <= FZ_OSCURO
        return claro & (_cerca(osc, 1, R) | _cerca(osc, 0, R)), (neu, ama)

    def reducir(t):
        return t[::2, ::2] | t[1::2, 1::2]

    def encaja(fr, ref):
        t = rasgos(fr)[0]
        return np.count_nonzero(t) >= c_min and _iou(reducir(t), ref) >= 0.5

    def imagen(ev):
        """Imagen limpia del texto: (imagen, esquina, color) o None si no parece un subtítulo. Un subtítulo es de un
        solo color: se prueba primero amarillo (un color tan concreto, centrado y en bloque, es el subtítulo) y si
        no, blanco. Decidirlo por el número de píxeles fallaba: lo blanco del dibujo (un plano con líneas, camisas)
        superaba a la letra amarilla y el subtítulo se perdía; y juntos, el texto en inglés del propio dibujo se
        colaba como una línea ilegible («1 o N ortTV IT 011FU O | PRIMER CONTACTO...»)."""
        nmin = max(1, 0.7 * ev["n"])
        neu = (ev["neu"] >= nmin).repeat(2, 0).repeat(2, 1)
        ama = (ev["ama"] >= nmin).repeat(2, 0).repeat(2, 1)
        # la luma de la letra: el mínimo de los fotogramas mirados o, con 5 o más, el percentil 20. Con el mínimo, un
        # fotograma del fundido de entrada (la letra medio transparente) borraba las letras finas: «T es a ens
        # cayeron del elo» en vez de «Tres aliens cayeron del cielo»
        Y = ev["ymin"] if len(ev["ys"]) < 5 else np.percentile(np.stack(ev["ys"]), 20, axis=0)
        base = ev["tsum"] >= nmin
        for color, mascara, umbral in (("amarillo", ama, FZ_CLARO_AM), ("blanco", neu, FZ_CLARO)):
            r = componer(base & mascara & (Y >= umbral), Y, color == "amarillo")
            if r is not None:
                return r + (color,)
        return None

    def componer(est, Y, amarillo):
        """La imagen del bloque de texto de la máscara est (letra de un color), o None."""
        lab, nl = label(est, structure=np.ones((3, 3)))
        if nl == 0:
            return None
        vale = np.bincount(lab.ravel()) >= 4
        vale[0] = False
        est = vale[lab]
        if np.count_nonzero(est) < c_min * 0.5:
            return None
        # el bloque de texto: letras, palabras y líneas cercanas entre sí; lo que queda aparte y lejos (el «+18» o el
        # logo de la cadena, fijos en una esquina) no cuenta: descentraba la caja y el subtítulo se descartaba
        # (Jeff y unos aliens: las canciones de 7:17 y 9:17, con el «+18» abajo a la derecha)
        # (en vertical, hasta una línea de separación: con 0,05 se partían los subtítulos de dos líneas)
        # (un filtro de máximos rectangular, que es separable: con binary_dilation y ese rectángulo se iba el 80 % del
        # tiempo de la lectura de forzados, 7 min por episodio 720p)
        juntos, nj = label(maximum_filter(est.view(np.uint8), size=(max(3, int(0.14 * BH)), max(3, int(0.04 * W)))))
        if nj > 1:
            est &= juntos == int(np.argmax(np.bincount(juntos[est], minlength=nj + 1)[1:]) + 1)
        ys, xs = np.nonzero(est)
        x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
        if abs((x0 + x1) / 2 - W / 2) > 0.12 * W:      # los subtítulos van centrados
            return None
        # la letra entera: desde lo seguro crece solo por lo que siempre es claro; el borde negro la frena
        # en un rótulo amarillo los trazos finos (r, l, i en cursiva) mezclan su color con el borde y quedan más
        # oscuros: se deja crecer por lo bastante claro sin mirar el color (el borde negro sigue frenándolo)
        cand = Y >= (130 if amarillo else 180)
        g = est
        for _ in range(12):
            g2 = binary_dilation(g) & cand
            if np.array_equal(g2, g):
                break
            g = g2
        g = binary_dilation(g)
        m0, m1, n0, n1 = max(0, y0 - 8), min(BH, y1 + 9), max(0, x0 - 12), min(W, x1 + 13)
        v = np.clip((Y[m0:m1, n0:n1].astype(np.float32) - 100) / 100, 0, 1) * g[m0:m1, n0:n1]
        v = zoom(v, FZ_ESCALA, order=1)
        img = np.pad((255 * (1 - v)).clip(0, 255).astype(np.uint8), FZ_MARGEN, constant_values=255)
        return img, (int(n0), int(m0 + Y0))

    NY, NC = W * BH, (W // 2) * (BH // 2)
    TAM = NY + 2 * NC

    def pasada(entrada):
        """Lee el vídeo una vez (entrada: opciones de decodificación). Devuelve (tramos brutos, tiempos, fotogramas)."""
        proc = subprocess.Popen(["ffmpeg", "-hide_banner", "-nostats", "-v", "info"] + entrada + ["-copyts", "-i", path,
                                 "-map", f"0:{idx}", "-an", "-sn", "-dn", "-fps_mode", "passthrough", "-vf", vf,
                                 "-f", "rawvideo", "-"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, **SIN_VENTANA)
        pts = []

        def leer_tiempos():
            for ln in proc.stderr:
                m = RE_PTS.search(ln)
                if m:
                    pts.append(float(m[1]))
        hilo = threading.Thread(target=leer_tiempos, daemon=True)
        hilo.start()
        buf = deque(maxlen=FZ_PASO)     # los últimos fotogramas, para afinar dónde empieza o acaba un texto
        brutos, ev, i, fin_ant = [], None, 0, 0

        def cerrar(ev):
            img = imagen(ev)
            if img is not None:
                brutos.append((ev["i0"], ev["i1"], img[0], img[1], img[2]))
        try:
            while True:
                b = proc.stdout.read(TAM)
                if len(b) < TAM:
                    break
                a = np.frombuffer(b, np.uint8)
                fr = (a[:NY].reshape(BH, W), a[NY:NY + NC].reshape(BH // 2, W // 2),
                      a[NY + NC:].reshape(BH // 2, W // 2))
                buf.append((i, fr))
                if i % FZ_PASO == 0:
                    t, (neu, ama) = rasgos(fr)
                    m = reducir(t)
                    hay = np.count_nonzero(t) >= c_min
                    sigue = ev is not None and hay and _iou(m, ev["ref"]) >= 0.5
                    if ev is not None and not sigue:
                        # acaba entre el fotograma mirado antes y este: en el primero que ya no encaja
                        fin = i
                        for j, f2 in list(buf)[:-1]:
                            if j >= ev["i1"] and not encaja(f2, ev["ref"]):
                                fin = j
                                break
                        ev["i1"] = fin_ant = fin
                        cerrar(ev)
                        ev = None
                    if hay and ev is None:
                        ini = i
                        for j, f2 in reversed(list(buf)[:-1]):
                            if j < fin_ant or not encaja(f2, m):
                                break
                            ini = j
                        ev = dict(i0=ini, n=0, ymin=fr[0].copy(), tsum=np.zeros((BH, W), np.uint16),
                                  neu=np.zeros(neu.shape, np.uint16), ama=np.zeros(ama.shape, np.uint16), ys=[],
                                  ref=m)
                    if ev is not None:
                        ev["n"] += 1
                        np.minimum(ev["ymin"], fr[0], out=ev["ymin"])
                        ev["tsum"] += t
                        ev["neu"] += neu        # en cuántos fotogramas mirados es blanco o amarillo
                        ev["ama"] += ama
                        ev["ys"].append(fr[0].copy())
                        if len(ev["ys"]) > 40:      # un rótulo largo: con uno de cada dos basta
                            ev["ys"] = ev["ys"][::2]
                        ev["i1"] = i + 1
                i += 1
        finally:
            proc.stdout.close()
            proc.wait()
            hilo.join(5)
        if ev is not None:
            cerrar(ev)
        return brutos, pts, i

    # con GPU solo se decodifica allí (la franja se recorta en la CPU: los píxeles son los mismos)
    esperados = fotogramas_esperados(path, idx) if deco not in (None, "cpu") else None
    for nombre, entrada, _ in intentos_decodificar(deco):
        t_ini = time.time()
        brutos, pts, i = pasada(entrada)
        if nombre == "CPU" or (i > 0 and (not esperados or i >= 0.97 * esperados)):
            break
        p(f"  No se ha podido decodificar con {nombre} ({i} fotogramas); se prueba de otra forma")
    if deco not in (None, "cpu"):
        p(f"  Vídeo del doblaje decodificado con {nombre} en {time.time() - t_ini:.0f} s")
    if i == 0:
        raise RuntimeError(f"no se ha podido leer el vídeo de {os.path.basename(path)}")
    pts = np.sort(np.array(pts[:i], float))
    paso = float(np.median(np.diff(pts))) if len(pts) > 1 else 0.04
    tiempo = lambda k: float(pts[k]) if k < len(pts) else float((pts[-1] if len(pts) else 0) + (k - len(pts) + 1) * paso)
    tramos = [dict(t0=tiempo(i0), t1=tiempo(i1), img=img, off=off, color=color) for i0, i1, img, off, color in brutos
              if tiempo(i1) - tiempo(i0) >= 0.3]
    return tramos, W, H


def guardar_bmp(ruta, g):
    """Imagen en gris (uint8) como BMP de 24 bits, que el OCR de Windows lee sin más librerías."""
    h, w = g.shape
    fila = (w * 3 + 3) // 4 * 4
    datos = np.zeros((h, fila), np.uint8)
    datos[:, :w * 3] = np.repeat(g[::-1], 3, axis=1)
    cab = b"BM" + (54 + datos.size).to_bytes(4, "little") + bytes(4) + (54).to_bytes(4, "little")
    cab += (40).to_bytes(4, "little") + w.to_bytes(4, "little") + h.to_bytes(4, "little") + b"\1\0\x18\0"
    cab += bytes(4) + datos.size.to_bytes(4, "little") + (2835).to_bytes(4, "little") * 2 + bytes(8)
    with open(ruta, "wb") as f:
        f.write(cab + datos.tobytes())


# OCR de Windows (Windows.Media.Ocr) desde Windows PowerShell 5, que viene con Windows 10 y 11: nada que instalar.
# Primera línea de la salida: el idioma con el que se ha leído; después, por imagen, sus líneas con su caja.
OCR_PS = r"""
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics, ContentType = WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime]
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Esperar($op, [Type]$tipo) {
    $t = $asTask.MakeGenericMethod($tipo).Invoke($null, @($op)); $null = $t.Wait(-1); $t.Result
}
$motor = $null
if ([Windows.Globalization.Language]::IsWellFormed('__IDIOMA__')) {
    $motor = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new('__IDIOMA__'))
}
if (-not $motor) { $motor = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
if (-not $motor) { throw 'el OCR de Windows no tiene ningún idioma instalado' }
$out = New-Object System.Collections.Generic.List[string]
$out.Add($motor.RecognizerLanguage.LanguageTag)
foreach ($ruta in [IO.File]::ReadAllLines('__LISTA__', [Text.Encoding]::UTF8)) {
    $f = Esperar ([Windows.Storage.StorageFile]::GetFileFromPathAsync($ruta)) ([Windows.Storage.StorageFile])
    $s = Esperar ($f.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    $d = Esperar ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($s)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $b = Esperar ($d.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $r = Esperar ($motor.RecognizeAsync($b)) ([Windows.Media.Ocr.OcrResult])
    $lineas = @(foreach ($l in $r.Lines) {
        $x0 = 1e9; $y0 = 1e9; $x1 = -1e9; $y1 = -1e9
        foreach ($w in $l.Words) {
            $c = $w.BoundingRect
            $x0 = [Math]::Min($x0, $c.X); $y0 = [Math]::Min($y0, $c.Y)
            $x1 = [Math]::Max($x1, $c.X + $c.Width); $y1 = [Math]::Max($y1, $c.Y + $c.Height)
        }
        ,@($l.Text, [int]$x0, [int]$y0, [int]$x1, [int]$y1)
    })
    $out.Add((ConvertTo-Json -InputObject $lineas -Compress -Depth 3))
    $b.Dispose(); $s.Dispose()
}
[IO.File]::WriteAllLines('__SALIDA__', $out, (New-Object System.Text.UTF8Encoding $false))
"""


def ocr_windows(imagenes, idioma, carpeta):
    """Lee las imágenes con el OCR de Windows. Devuelve (idioma usado, [[(texto, x0, y0, x1, y1)] por imagen])."""
    if os.name != "nt":
        raise RuntimeError("el OCR de los forzados usa el de Windows")
    rutas = []
    for k, img in enumerate(imagenes):
        rutas.append(os.path.join(carpeta, f"{k:04d}.bmp"))
        guardar_bmp(rutas[-1], img)
    lista, salida = os.path.join(carpeta, "lista.txt"), os.path.join(carpeta, "ocr.txt")
    with open(lista, "w", encoding="utf-8") as f:
        f.write("\n".join(rutas))
    q = lambda s: s.replace("'", "''")
    script = OCR_PS.replace("__LISTA__", q(lista)).replace("__SALIDA__", q(salida)).replace("__IDIOMA__", q(idioma))
    ps = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "WindowsPowerShell", "v1.0",
                      "powershell.exe")
    r = subprocess.run([ps if os.path.isfile(ps) else "powershell.exe", "-NoProfile", "-NonInteractive",
                        "-EncodedCommand", base64.b64encode(script.encode("utf-16-le")).decode("ascii")],
                       capture_output=True, **SIN_VENTANA)
    if r.returncode != 0 or not os.path.exists(salida):
        try:
            err = (r.stderr or r.stdout).decode("oem", "replace")
        except LookupError:
            err = (r.stderr or r.stdout).decode("latin-1", "replace")
        linea = next((x.strip() for x in err.splitlines() if x.strip()), f"código {r.returncode}")
        raise RuntimeError(f"falló el OCR de Windows: {linea[:200]}")
    with open(salida, encoding="utf-8-sig") as f:
        filas = f.read().splitlines()
    return filas[0].strip(), [[tuple(l) for l in json.loads(x)] for x in filas[1:]]


def bloque_subtitulo(lineas, ancho):
    """Las líneas centradas de más abajo y seguidas: el subtítulo. Fuera el texto del propio dibujo."""
    cen = sorted((l for l in lineas if abs((l[1] + l[3]) / 2 - ancho / 2) <= 0.12 * ancho), key=lambda l: l[4])
    if not cen:
        return []
    bloque = [cen[-1]]
    for l in reversed(cen[:-1]):
        if bloque[-1][2] - l[4] > 0.8 * (bloque[-1][4] - bloque[-1][2]):
            break
        bloque.append(l)
    return bloque[::-1]


CORTAS = {"y", "a", "o", "e", "u", "de", "el", "la", "lo", "en", "un", "se", "me", "te", "le", "no", "si", "sí", "ya",
          "mi", "mí", "tu", "tú", "su", "es", "al", "ha", "he", "os", "ni", "eh", "ah", "oh", "ay", "yo", "va", "da",
          "di", "ve", "fe", "ti"}


def texto_valido(t):
    letras = sum(c.isalpha() for c in t)
    if not (letras >= 2 and letras >= 0.5 * sum(not c.isspace() for c in t)):
        return False
    # lecturas sin sentido (texto del propio dibujo, garabatos): varias «palabras» de una o dos letras que no son
    # palabras cortas del castellano, o con números («eunu TUE V 1»)
    pal = re.findall(r"\w+", t)
    raras = [w for w in pal if any(c.isdigit() for c in w) or (len(w) <= 2 and w.lower() not in CORTAS)]
    return len(raras) < max(2, 0.4 * len(pal))


RE_ABRE = re.compile(r"(^|[\s\"'(«])([iíìj|]{1,3})(\s?)(?=[A-ZÁÉÍÓÚÑ¿]|lJ)")
RE_RARO = re.compile(r"[@#$%^&*_=+{}\[\]|<>~`•€£§]|\b(?=\w*\d)(?=\w*[^\W\d_])\w+\b")
RE_MAYUS_L = re.compile(r"\b[A-ZÁÉÍÓÚÑÜl]*l[A-ZÁÉÍÓÚÑÜl]*\b")
# vocales que el castellano no usa: con circunflejo o tilde son la vocal sin más; con grave, la aguda
VOCALES_RARAS = str.maketrans("ÂÊÎÔÛÃÕâêîôûãõÀÈÌÒÙàèìòù", "AEIOUAOaeiouaoÁÉÍÓÚáéíóú")


def corregir_ocr(t, idioma):
    """Lo que el OCR confunde siempre en castellano: «¡» leído como i, el «!» que la cierra como ' / f l,
    la I como l en palabras en mayúsculas y letras sueltas en minúscula en un cartel todo en mayúsculas."""
    if idioma.lower().startswith("es"):
        t = t.translate(VOCALES_RARAS)
        t = RE_ABRE.sub(lambda m: m[1] + "¡" * len(m[2]), t).replace("¡lJ", "¡U")
        partes = re.split(r"(?=¡)", t)
        for k, s in enumerate(partes):
            if s.startswith("¡") and "!" not in s:
                partes[k] = re.sub(r"[’'/|fl1](\s*)$", r"!\1", s)
        t = "".join(partes)
        t = re.sub(r"(?<=\w)(,?)[.\-–—·•]{3}(?=\s|$)", r"\1...", t)        # «...» leído como «.--»
        lineas = []
        for x in t.split("\n"):
            x = RE_MAYUS_L.sub(lambda m: m[0].replace("l", "I") if sum(c.isupper() for c in m[0]) >= 2 else m[0], x)
            letras = [c for c in x if c.isalpha()]
            if len(letras) >= 4 and sum(c.isupper() for c in letras) >= 0.8 * len(letras):
                x = x.upper()
            lineas.append(x)
        t = "\n".join(lineas)
    return "\n".join(y for y in (re.sub(r"[ \t]+", " ", x).strip() for x in t.split("\n")) if y)


def forzados_quemados(es_path, t_audio, idioma="es-ES", deco="cpu", p=print):
    """Subtítulos quemados en la imagen del doblaje: ([(t0, t1, texto)] en el tiempo de su pista de audio,
    que empieza en t_audio dentro del contenedor; idioma con el que se han leído). (None, None) sin vídeo."""
    idx = pista_video(es_path)
    if idx is None:
        return None, None
    tramos, W, H = escanear_quemados(es_path, idx, deco, p)
    if not tramos:
        return [], idioma
    with tempfile.TemporaryDirectory(prefix="forzados_") as carpeta:
        usado, lecturas = ocr_windows([t["img"] for t in tramos], idioma, carpeta)
    ev = []
    for tr, lineas in zip(tramos, lecturas):
        ox, oy = tr["off"]
        cajas = [(tx, (a - FZ_MARGEN) / FZ_ESCALA + ox, (b - FZ_MARGEN) / FZ_ESCALA + oy,
                  (c - FZ_MARGEN) / FZ_ESCALA + ox, (d - FZ_MARGEN) / FZ_ESCALA + oy) for tx, a, b, c, d in lineas]
        bloque = bloque_subtitulo(cajas, W)
        if bloque:
            ev.append(dict(t0=tr["t0"] - t_audio, t1=tr["t1"] - t_audio, bloque=bloque, color=tr["color"],
                           texto=corregir_ocr("\n".join(l[0] for l in bloque), usado)))
    # el estilo de los subtítulos del episodio (altura de la línea y dónde acaban) deja fuera los rótulos de los
    # créditos y el texto suelto del dibujo. Manda el color con más subtítulos claros: los del otro color tienen que
    # parecerse a ellos (Jeff y unos aliens: todos amarillos; las letras blancas de una pantalla del dibujo, «Tur T»,
    # «OMMEN», iban a otra altura y con otra letra). Si manda el amarillo, sus rótulos pueden ir más arriba (la
    # traducción de un cartel: «INVASIÓN ALIENÍGENA», a media altura): un amarillo tan concreto ya es el subtítulo
    buenos = [e for e in ev if sum(c.isalpha() for c in e["texto"]) >= 6 and texto_valido(e["texto"])]
    colores = [e["color"] for e in buenos]
    manda = max(set(colores), key=colores.count) if colores else None
    buenos = [e for e in buenos if e["color"] == manda]
    if len(buenos) >= 3:
        fondo = float(np.median([e["bloque"][-1][4] for e in buenos]))
        alto = float(np.median([l[4] - l[2] for e in buenos for l in e["bloque"]]))
        letra = lambda e: all(0.6 * alto <= l[4] - l[2] <= 1.6 * alto for l in e["bloque"])
        sitio = lambda e: fondo - 1.5 * alto <= e["bloque"][-1][4] <= fondo + alto
        estilo = lambda e: letra(e) and (sitio(e) or (e["color"] == manda == "amarillo"))
    else:
        estilo = lambda e: e["bloque"][-1][4] >= 0.75 * H
    subs = []
    for e in ev:
        if not (texto_valido(e["texto"]) and estilo(e)):
            continue
        # el mismo texto partido en dos (cambia el fondo por debajo): uno solo
        if subs and e["t0"] - subs[-1][1] <= 0.25 and \
                difflib.SequenceMatcher(None, subs[-1][2], e["texto"]).ratio() >= 0.85:
            a = subs[-1]
            subs[-1] = (a[0], e["t1"], a[2] if a[1] - a[0] >= e["t1"] - e["t0"] else e["texto"])
        else:
            subs.append((e["t0"], e["t1"], e["texto"]))
    return subs, usado


def ruta_forzados(out_path):
    return os.path.splitext(out_path)[0] + "_forzados.srt"


def generar_forzados(es_path, t_audio, mapa, out_path, idioma="es-ES", p=print, deco="cpu"):
    """Lee los forzados quemados del doblaje y los guarda en _forzados.srt con los mismos cortes que el audio.
    Si ya existe (quizá corregido a mano), se deja. Devuelve (ruta o None, avisos)."""
    ruta = ruta_forzados(out_path)
    if os.path.exists(ruta):
        p(f"Forzados: ya existe {ruta}; se usa ese")
        return ruta, []
    p("Buscando subtítulos quemados en la imagen del doblaje (forzados)...")
    try:
        subs, usado = forzados_quemados(es_path, t_audio, idioma, deco, p)
    except Exception as e:
        p(f"Forzados: no se han podido leer ({e})")
        return None, [f"forzados: no se han podido leer ({e})"]
    if subs is None:
        p("Forzados: el doblaje no es un vídeo; no hay subtítulos quemados que leer")
        return None, []
    subs = [(mapear(a, mapa), mapear(b, mapa), tx) for a, b, tx in subs]
    subs = [s for s in subs if s[1] - s[0] >= 0.2]          # lo que cae en un trozo recortado se va
    if not subs:
        p("Forzados: no hay subtítulos quemados en la imagen del doblaje")
        return None, []
    with open(ruta, "x", encoding="utf-8-sig", newline="\r\n") as f:
        for n, (a, b, tx) in enumerate(subs, 1):
            f.write(f"{n}\n{srt_tiempo(a)} --> {srt_tiempo(b)}\n{tx}\n\n")
    p(f"Forzados quemados: {len(subs)} subtítulos leídos con OCR ({usado}) -> {ruta}")
    avisos = []
    if usado.split("-")[0].lower() != idioma.split("-")[0].lower():
        avisos.append(f"forzados: el OCR de Windows no tiene el idioma {idioma}; se han leído con {usado}")
    raros = 0
    for a, b, tx in subs:
        raro = bool(RE_RARO.search(tx))
        raros += raro
        p(f"Forzado {mmss(a):>9}-{mmss(b)}  {tx.replace(chr(10), ' | ')}" + ("   <- revisar" if raro else ""))
    if raros:
        avisos.append(f"forzados: {raros} con caracteres raros del OCR, conviene revisarlos en el .srt")
    return ruta, avisos


# ---------------------------------------------------------------- flujo principal

def mmss(t):
    return f"{int(t // 60)}:{t % 60:05.2f}"


PARECIDO_ORIGINAL = 0.8     # una pista que se parece tanto al original es la versión original
# con menos ventanas fiables que esto, y si los dos archivos son vídeos, se mide con los cambios de plano:
# Crash Canyon 1x01 (castellano MP3, ~3 % de ventanas) salía 68 ms desviado con audio y exacto con vídeo
AUDIO_FIABLE = 0.25


def parecido_pista(a, b):
    """Parecido (0-1) de una pista del doblaje con el original, para saber si es la versión original: la mejor
    correlación de ventanas de 20 s. Una deriva de reloj la baja (40 ppm son 0,8 ms en 20 s: la versión original de
    un doblaje fabricado daba 0,71 y parecía otra mezcla), así que, si no llega, se prueba también con el original
    estirado hasta ±300 ppm alrededor del desfase encontrado. Una mezcla distinta no sube: difiere en el diálogo."""
    lag, c = desfase_inicial(a, b)
    if c >= PARECIDO_ORIGINAL:
        return c
    W, S = 20 * AR, AR                  # ventana y búsqueda de ±1 s alrededor del desfase
    for t0 in (60, 180, 300, 420, 600):
        s = t0 * AR
        o = s + int(round(lag * AR)) - S
        if s + W > len(a) or o < 0:
            continue
        for d in np.arange(-300, 301, 20) * 1e-6:
            pos = o + np.arange(W + 2 * S) * (1 + d)
            if not d or pos[-1] >= len(b) - 1:
                continue
            i0 = int(pos[0])
            trozo = b[i0:int(pos[-1]) + 2]
            cc = ncc_curve(a[s:s + W], np.interp(pos - i0, np.arange(len(trozo)), trozo))
            if cc is not None:
                c = max(c, float(cc.max()))
        if c >= PARECIDO_ORIGINAL:
            break
    return c


CASTELLANO = re.compile(r"castellano|espa[ñn]a|spain|europe|es-es", re.I)
LATINO = re.compile(r"latin|latam|m[ée]xic|hispanoam|419", re.I)


def elegir_pistas(es_path, en8, pista=None, guia=None, p=print, audios=None, idioma_ori="", objetivo="spa",
                  con_envolvente=False):
    """Pista del doblaje que se sincroniza y, si el mismo archivo trae la versión original
    (p. ej. un ripeo dual), la pista que sirve de guía: se mide contra el original con mucha
    más precisión que la música y los efectos, y los cortes se aplican a la pista doblada,
    que va sincronizada con ella dentro del archivo. pista/guia: 1, 2...; guia=0 = sin guía.
    idioma_ori: el de la pista del original (ISO 639-2/B o ''); objetivo: el del muxeado (spa), que es el que
    se sincroniza si hay varias dobladas.
    con_envolvente: el doblaje tiene el tono corregido (detectar_velocidad): el parecido, con las envolventes, y
    la versión original solo se reconoce por el idioma (con la envolvente, una doblada con la misma música y efectos
    se parece casi tanto).
    Devuelve (pista doblada, pista guía o None, audio a 8 kHz con el que medir, avisos, otras pistas
    dobladas, que se sincronizan con los mismos cortes, y la duración en s de la doblada)."""
    st = pistas_audio(es_path)
    if not st:
        raise RuntimeError(f"no hay audio en {es_path}")
    for n in (pista, guia):
        if n and n > len(st):
            raise RuntimeError(f"{os.path.basename(es_path)} solo tiene {len(st)} pista(s) de audio")
    if len(st) == 1:
        x = audios[0] if audios else cargar(es_path, st[0], AR, 2)
        return st[0], None, x, [], [], len(x) / AR

    en_m = en8[:, 0] + en8[:, 1]
    audio = audios or [cargar(es_path, s, AR, 2) for s in st]      # ya cargadas al mirar la velocidad
    if con_envolvente:
        en_e = envolvente_ar(en_m)
        parecido = [parecido_pista(envolvente_ar(x[:, 0] + x[:, 1]), en_e) for x in audio]
    else:
        parecido = [parecido_pista(x[:, 0] + x[:, 1], en_m) for x in audio]
    idiomas = [idioma_iso(idioma_pista(s)) for s in st]
    def por_el_idioma(l):
        """¿Versión original, según su idioma? None si el idioma no lo dice. Una pista en otro idioma que el
        original es un doblaje aunque comparta con él la música y los efectos y se le parezca mucho (Barbie:
        castellano y portugués 5.1 a 0,98). «qaa» es la versión original en la TDT."""
        if l == "qaa":
            return True
        if l and idioma_ori:
            return l == idioma_ori
        if l and l == objetivo:
            return False
        return None

    por_idioma = [por_el_idioma(l) for l in idiomas]
    vo = [t if t is not None else c >= PARECIDO_ORIGINAL and not con_envolvente for t, c in zip(por_idioma, parecido)]
    if con_envolvente:
        # con la envolvente un doblaje con la misma música también se parece mucho, así que sin idioma que lo diga no
        # se daba nunca por versión original; pero si se parece casi igual y mucho más que la del idioma del doblaje,
        # lo es (La pelu del señor Pan 3x14: la inglesa sin idioma, 0,98; la castellana, 0,56)
        dobladas_idioma = [c for l, c in zip(idiomas, parecido) if l == objetivo]
        for i, (t, c) in enumerate(zip(por_idioma, parecido)):
            if t is None and dobladas_idioma and c >= ENV_MISMO_SONIDO and c >= max(dobladas_idioma) + 0.2:
                vo[i] = True
    avisos = []
    p("Pistas del doblaje: " + " · ".join(
        f"{describir_pista(s)} (parecido al original {c:.2f}; "
        f"{'versión original' if v else 'doblada'}{' por el idioma' if t is not None else ''})"
        for s, c, v, t in zip(st, parecido, vo, por_idioma)))
    if pista:
        ip = pista - 1
    else:
        otras = [i for i in range(len(st)) if not guia or i != guia - 1]
        dobladas = [i for i in otras if not vo[i]]
        # la del idioma del muxeado (y, entre varias en castellano, la que no diga latino)
        dobladas.sort(key=lambda i: (idiomas[i] != objetivo, bool(LATINO.search(pista_titulo(st[i]))),
                                     not CASTELLANO.search(pista_titulo(st[i]))))
        ip = dobladas[0] if dobladas else otras[0]
        # una etiqueta equivocada (la versión original marcada como castellano) no debe acabar muxeada como
        # castellano: si la elegida tiene los mismos diálogos que el original, las pistas se eligen por el audio
        # (con el tono corregido la onda no coincide nunca, ni con la versión original: se compara la envolvente)
        igual_a = ((lambda x: dialogo_igual(envolvente_ar(x[:, 0] + x[:, 1]), en_e)) if con_envolvente else
                   (lambda x: dialogo_igual(x[:, 0] + x[:, 1], en_m)))
        if not vo[ip] and igual_a(audio[ip]) >= DIALOGO_IGUAL:
            igual = [igual_a(x) for x in audio]
            vo = [g >= DIALOGO_IGUAL for g in igual]
            p(f"Las etiquetas de idioma no cuadran con el audio: la pista {ip + 1} suena igual que el original "
              f"(diálogos iguales {igual[ip]:.2f}); se eligen las pistas por el audio: "
              + " · ".join(f"{i + 1}: {'versión original' if v else 'doblada'} ({g:.2f})"
                           for i, (v, g) in enumerate(zip(vo, igual))))
            por_idioma = [None] * len(st)
            dobladas = [i for i in otras if not vo[i]]
            malo = ip
            ip = dobladas[0] if dobladas else otras[0]
            avisos.append(f"las etiquetas de idioma del doblaje están mal: la pista {malo + 1} "
                          f"[{idiomas[malo] or 'sin idioma'}] es la versión original; se ha usado la pista {ip + 1} "
                          f"[{idiomas[ip] or 'sin idioma'}], que es la que suena distinta: conviene comprobarlo")
    if guia is not None and guia > 0:
        ig = guia - 1
    elif guia == 0:
        ig = None
    else:
        # la versión original que más se parezca: con el mismo montaje, aunque sea otra mezcla, se mide mejor que
        # con el doblaje (si se le parece claramente más)
        cand = [i for i in range(len(st)) if i != ip and vo[i] and (
            parecido[i] >= PARECIDO_ORIGINAL or (por_idioma[i] and parecido[i] >= 0.5 and parecido[i] > parecido[ip] + 0.1))]
        ig = max(cand, key=lambda i: parecido[i]) if cand else None
    if ig == ip:
        ig = None
    if vo[ip]:
        avisos.append(f"la pista {ip + 1} parece la versión original: ¿seguro que es la doblada?")
    p(f"Se sincroniza la pista {ip + 1}" + (
        f"; guía: pista {ig + 1} (versión original, se mide con ella y se da por hecho que va "
        f"sincronizada con la {ip + 1} dentro del archivo)" if ig is not None else "; sin pista guía"))
    # las versiones originales no se repiten: ya van en el vídeo original
    otras = [st[i] for i in range(len(st)) if i not in (ip, ig) and not vo[i]]
    return (st[ip], (st[ig] if ig is not None else None), audio[ig if ig is not None else ip], avisos, otras,
            len(audio[ip]) / AR)


DIALOGO_IGUAL = 0.8     # una pista con los diálogos tan iguales al original es la versión original


def dialogo_igual(a, b):
    """Cuánto de la película suena igual que el original (0-1): el cuartil bajo de 40 ventanas de 5 s repartidas por
    toda ella. La versión original de la misma mezcla da ~1 en casi todas; un doblaje, aunque comparta la música y
    los efectos (y en ventanas de 20 s llegue a 0,98), baja donde hay diálogo. Un corte grande antes de una ventana
    la baja también: solo puede dar de menos, nunca confundir un doblaje con la versión original."""
    lag = int(round(desfase_inicial(a, b)[0] * AR))
    W, S = 5 * AR, 3 * AR
    cs = []
    for f in np.linspace(0.05, 0.95, 40):
        s = int(f * max(len(a) - W, 0))
        o = s + lag
        if o - S < 0 or o + W + S > len(b):
            continue
        c = ncc_curve(a[s:s + W], b[o - S:o + W + S])
        if c is not None and len(c):
            cs.append(float(c.max()))
    return float(np.percentile(cs, 25)) if len(cs) >= 10 else 0.0


def pista_titulo(s):
    return next((v for k, v in (s.get("tags") or {}).items() if k.lower() == "title"), "")


PREGUNTA_SIN_CORTES = "PREGUNTA_SIN_CORTES: "      # la GUI la reconoce y contesta por la entrada estándar


def convertir_sin_cortes(sin_cortes, formato, st, p=print):
    """Sin cortes ni rellenos el doblaje puede ir tal cual: ¿se pasa al formato elegido? sin_cortes: "intacto",
    "convertir" o "preguntar" (en la GUI, una ventana; en una consola, aquí; sin nadie que conteste, intacto).
    Si ya va en ese formato no se pregunta: recodificarlo solo perdería calidad."""
    if sin_cortes == "intacto" or st.get("codec_name") == formato:
        return False
    if sin_cortes == "convertir":
        return True
    actual = texto_formato(st.get("codec_name", "?"), int(st["bit_rate"]) if st.get("bit_rate") else None)
    if sys.stdin is None:
        return False
    if sys.stdin.isatty():
        r = input(f"No hay cortes: el castellano puede ir intacto ({actual}). ¿Convertirlo a "
                  f"{texto_formato(formato)}? [s/N] ")
    else:
        print(f"{PREGUNTA_SIN_CORTES}{actual}|{texto_formato(formato)}", flush=True)
        r = sys.stdin.readline()
    return r.strip().lower() in ("s", "si", "sí", "convertir")


def sincronizar(es_path, en_path, out_path, sub_path=None, pista=None, guia=None, pista_original=None,
                medir="auto", rellenar_original=True, forzados=False, forz_idioma="es-ES", decodificar="cpu",
                otras_pistas=True, formato="flac", sin_cortes="intacto", estirar_variable=False, correcciones=(),
                limpiar=False, canales="igual", kbps=None):
    """medir: "audio", "video" (cambios de plano) o "auto" (audio y, si no coincide, vídeo).
    pista_original: 1, 2...; None = la versión original según los idiomas (elegir_original).
    rellenar_original: lo que le falte al doblaje (1 s o más) se rellena con el audio original.
    forz_idioma: el idioma del muxeado: el de los forzados y el de la pista que se sincroniza si hay varias dobladas.
    forzados: los subtítulos quemados en la imagen del doblaje se leen con OCR (idioma forz_idioma)
    y se guardan en _forzados.srt, con los mismos cortes.
    decodificar: con qué se decodifica el vídeo (clave de DECODIFICADORES; la CPU si la GPU falla).
    otras_pistas: las demás pistas dobladas del archivo (no las versiones originales) se sincronizan también,
    con los mismos cortes, en _pistaN_[idioma].
    estirar_variable: si la velocidad del doblaje varía (VHS), el castellano se estira siguiendo la del original en
    vez de cortarlo (opción del usuario para ese caso; solo los saltos de verdad se cortan).
    correcciones: ajustes a mano sobre lo medido (leer_correcciones), en tiempos del resultado.
    limpiar: la pista doblada se limpia del ruido de la cinta (limpiar_vhs) al cargarla para montarla; nunca va tal
    cual. Las demás pistas dobladas (otras_pistas) no se limpian.
    canales: "igual" (los del doblaje) o "2.0" (codificar). kbps: los del audio doblado (kbps_elegido) o None,
    automáticos. Pedidos y distintos de los del doblaje, se recodifica aunque no haya cortes (motivo_recodificar)."""
    log = []
    def p(msg=""):
        print(msg, flush=True); log.append(msg)

    t_inicio = time.time()
    CRONO.clear()
    p(f"Doblaje : {os.path.basename(es_path)}")
    p(f"Original: {os.path.basename(en_path)}")
    objetivo = idioma_iso(forz_idioma) or "spa"
    if pista_original:
        st_en = probe_audio(en_path, pista_original - 1)
        p(f"Pista del original: {describir_pista(st_en)} (elegida a mano)")
    else:
        st_en = elegir_original(en_path, es_path, objetivo, p)
    pre_s = max(0.0, float(st_en.get("start_time") or 0))
    pistas_es = pistas_audio(es_path)
    con_envolvente = False  # el doblaje tiene el tono corregido: se mide con envolvente_ar (detectar_velocidad)
    if medir == "video":
        en8 = cargar(en_path, st_en, AR, 2)
        vel, audios8 = None, None
    else:
        # el original y las pistas del doblaje se leen a la vez
        en8, audios_es = en_paralelo(lambda f: f(), [lambda: cargar(en_path, st_en, AR, 2),
                                                      lambda: [cargar(es_path, s, AR, 2) for s in pistas_es]])
        # si el doblaje va a otra velocidad, todo se mide con el original llevado a la del doblaje
        vel, audios8, con_envolvente = detectar_velocidad(es_path, en_path, en8, pistas_es, p, audios_es)
        del audios_es
    if vel and vel != 1:
        en8 = acelerar(en8, vel)
        pre_s /= float(vel)
    v_en8 = vel if vel and vel != 1 else Fraction(1)        # a qué velocidad queda en8 (desfase_imagen_sonido)
    en_len = len(en8) / AR
    st_es, st_guia, es8, avisos_pistas, otras, dur_es = elegir_pistas(es_path, en8, pista, guia, p, audios8,
                                                                      idioma_iso(idioma_pista(st_en)), objetivo,
                                                                      con_envolvente)
    # con guía, la pista doblada y las demás dobladas en mono a AR (ya leídas): para contrastarlas con el original
    # (contrastar_doblada), que no se da por hecho que vayan a la par de la guía
    mono8 = {}
    if audios8:
        usar = ({st_es["index"]} if st_guia is not None else set()) | (
            {s["index"] for s in otras} if otras_pistas else set())
        for s_, x_ in zip(pistas_es, audios8):
            if s_["index"] in usar:
                mono8[s_["index"]] = (x_[:, 0] + x_[:, 1]).astype(np.float32)
    del audios8
    if st_guia is not None:
        # dentro del archivo, la guía puede empezar en otro momento que la doblada (un retraso puesto con mkvmerge por
        # quien sincronizó el dual): el reproductor las alinea con él, pero cada pista se lee desde su primera muestra
        # y se perdía (el castellano salía desplazado justo eso, y la verificación, hecha con la guía, no lo veía).
        # La guía se lleva al tiempo de la doblada. Un inicio negativo es el retardo de codificación de un Opus o un AAC
        # que ya se descarta al decodificar: su primera muestra suena en 0 (como en el original, pre_s)
        inicio = lambda s: max(0.0, float(s.get("start_time") or 0))
        d = inicio(st_guia) - inicio(st_es)
        n = int(round(d * AR))
        if n:
            es8 = np.concatenate([np.zeros((n, es8.shape[1]), np.float32), es8]) if n > 0 else es8[-n:]
            p(f"La guía empieza {abs(d) * 1000:.0f} ms {'después' if d > 0 else 'antes'} que la pista doblada "
              "dentro del archivo: se tiene en cuenta")
    if not otras_pistas:
        otras = []
    # subtítulos: para saber para qué versión está hecho cada uno, cuándo se habla en el doblaje y en el original (la
    # guía va en el tiempo del doblaje; el original quizá leído ya acelerado a su velocidad). Solo si hay subtítulos
    t_audio = float(st_es.get("start_time") or 0)
    voces = None
    if sub_path or any(s["ext"] for s in pistas_sub_doblaje(es_path)):
        voces = dict(doblaje=voz_referencia(es8, t_audio),
                     original=voz_referencia(en8, max(0.0, float(st_en.get("start_time") or 0)),
                                             float(vel) if vel and vel != 1 else 1.0))

    video = medir == "video"
    if not video:
        lat = lambda z: z[:, 0] - z[:, 1]
        mono = lambda z: z[:, 0] + z[:, 1]
        rel = lambda z: np.sqrt((lat(z) ** 2).mean() / max((mono(z) ** 2).mean(), 1e-12))
        # por debajo de ~0,1 la lateral de una pista casi mono es ruido de codificación y no correlaciona
        estereo = min(rel(es8), rel(en8))
        lateral = estereo > 0.1
        # con el tono corregido, la envolvente (envolvente_ar): la onda no coincide nunca
        ana = envolvente_ar if con_envolvente else (lambda x: x)
        a, b = (ana(lat(es8)), ana(lat(en8))) if lateral else (ana(mono(es8)), ana(mono(en8)))
        mezcla, nombre = None, "lateral L-R (sin diálogo)" if lateral else "mono (mezcla casi mono)"
        if lateral:
            # la lateral es la señal de un doblaje frente a su original (otro diálogo; la música y los efectos van a los
            # lados), pero con el mismo sonido (una guía) la mezcla también encaja, y si la lateral de un archivo está
            # estropeada solo encaja la mezcla (La pelu del señor Pan 3x02: guía en AAC con el tono corregido, su
            # lateral 0,31 con la envolvente y la mezcla 0,97; con la lateral se daba por «otro sonido» y se medía con
            # la imagen). Unas ventanas de cada una lo dicen; la lateral, también invertida (canales cambiados)
            mezcla = ana(mono(es8)), ana(mono(en8))
            parecido = lambda x, y: float(np.median([c for _, c in ventanas_desfase(x, y, 150)] or [0.0]))
            m_mezcla, m_lat = parecido(*mezcla), max(parecido(a, b), parecido(-a, b))
            if m_mezcla >= (ENV_CONFIRMADA if con_envolvente else 0.5) and m_mezcla >= m_lat + 0.2:
                lateral, (a, b) = False, mezcla
                nombre = (f"mezcla L+R (encaja mucho mejor que la lateral: {m_mezcla:.2f} frente a {m_lat:.2f}; "
                          "una lateral estropeada o el mismo sonido)")
        p(f"Señal de análisis: {nombre}"
          f" [lateral/mono {estereo:.2f}]" + (", su envolvente (la onda del doblaje no coincide con la del original)"
                                              if con_envolvente else ""))

        signo = 1               # -1: lateral invertida (canales izquierdo y derecho cambiados en uno de los archivos)
        invertida = lambda: p("Señal de análisis: lateral invertida (uno de los dos archivos tiene los canales "
                              "izquierdo y derecho cambiados)")
        lag0, sc0 = desfase_inicial(a, b, primero=True)
        if lateral:
            # con los canales cambiados en uno de los dos archivos la lateral va con el signo al revés: la correlación
            # de verdad sale negativa y lo que se ve es un lóbulo de al lado, flojo, unos ms desplazado y el mismo en
            # todas las ventanas, así que también parece coherente (Buzz 1x01 fabricado así: +6 ms con 0,23, y la
            # invertida 0,9 en 0 ms). Se prueba siempre invertida y se queda la que encaje claramente mejor
            lag2, sc2 = desfase_inicial(-a, b, primero=True)
            if sc2 >= 0.4 and sc2 >= sc0 + 0.2:
                signo, a, lag0, sc0 = -1, -a, lag2, sc2
                invertida()
        if sc0 < 0.4:
            # parecido flojo: si varias ventanas separadas caen en el mismo desfase, ese es (Buzz 1x06: 0,2-0,3 en
            # +1,01 s una y otra vez; el mejor pico suelto podía ser una casualidad)
            n, media, Lc = coherencia(ventanas_desfase(a, b, 150))
            if lateral and signo == 1:
                # las dos flojas: la invertida, si es coherente y bastante mejor (o la normal no lo es)
                n2, media2, Lc2 = coherencia(ventanas_desfase(-a, b, 150))
                vale = n >= 2 and media >= 0.15
                if n2 >= 2 and media2 >= 0.15 and (media2 >= media + 0.1 if vale else (n2, media2) > (n, media)):
                    signo, a, n, media, Lc = -1, -a, n2, media2, Lc2
                    invertida()
            if n >= 2 and media >= 0.15:
                lag0, sc0 = Lc, media
        p(f"Desfase inicial aprox.: {lag0 * 1000:+.0f} ms (confianza {sc0:.2f})")
        con_video = medir == "auto" and pista_video(es_path) is not None and pista_video(en_path) is not None
        # la envolvente solo es precisa con el mismo sonido (una guía, la misma mezcla: 0,98-0,99); con otra mezcla el
        # diálogo también la mueve (Kojak 4x24 latino: mediana 0,53, y diez saltos de ida y vuelta de 0,18 s que no
        # estaban); la imagen, siguiendo luego al sonido por trozos, lo midió limpio. Con unas pocas ventanas se sabe,
        # sin seguir todo el audio (en una película eran minutos)
        # Con una guía (la versión original) se sigue todo el audio y decide envolvente_precisa: una guía con otra
        # codificación da 0,85-0,94 y el desfase igual de estable (La pelu del señor Pan 3x14: mediana 0,89 en las 5
        # ventanas, ±2 ms en todo el episodio; con el 0,9 de las ventanas se medía con la imagen, a 17 ms)
        muestra = ([c for _, c in ventanas_desfase(a, b, 150)] if con_envolvente and con_video and st_guia is None
                   else [])
        otro_sonido = bool(muestra) and float(np.median(muestra)) < ENV_MISMO_SONIDO
        if otro_sonido:
            pts = np.zeros((0, 3))
        elif lateral:           # el lateral y la mezcla, a la vez
            pts = np.concatenate(en_paralelo(lambda xy: seguir(xy[0], xy[1], lag0), [(a, b), mezcla]))
        else:
            pts = seguir(a, b, lag0)
        mezcla = None           # (en una película, cientos de MB)
        fiable = float((pts[:, 2] > 0.4).mean()) if len(pts) else 0.0
        # ventanas flojas (>= 0,2) que caen en un desfase que se repite (buscar_niveles: 5 en un minuto) también valen:
        # una casualidad no repite el desfase minuto a minuto (Buzz 1x06: solo el 5 % pasaba de 0,4, pero las demás
        # daban +1,01 s una y otra vez; medido con la imagen salía 210 ms desplazado y el usuario lo notó)
        niv0 = buscar_niveles(pts, 0.0) if len(pts) else []
        coherentes = float(np.mean([s >= 0.2 and any(abs(l - n) <= 0.03 for n in niv0)
                                    for _, l, s in pts])) if niv0 else 0.0
        if not otro_sonido:
            p(f"Coincidencias del audio con el original: {fiable:.0%} de las ventanas"
              + (f" ({coherentes:.0%} contando las flojas que caen en el mismo desfase)" if coherentes > fiable else ""))
        fiable = max(fiable, coherentes)
        if otro_sonido:
            p(f"Con la envolvente el audio se parece al original, pero no es el mismo sonido (parecido mediano "
              f"{float(np.median(muestra)):.2f}): se mide con los cambios de plano del vídeo, y luego se sigue al sonido")
            video = True
        elif fiable < 0.03 and not con_video:
            raise RuntimeError("apenas hay coincidencias entre las pistas: ¿es el mismo episodio?"
                               + ("" if medir == "audio" else " (y no hay vídeo en los dos archivos para medir con él)"))
        elif con_video and fiable < AUDIO_FIABLE:
            p("El audio del doblaje apenas se parece al del original (otra mezcla de música o risas): "
              "se mide con los cambios de plano del vídeo" if fiable < 0.03 else
              "El audio del doblaje coincide poco con el original: se mide con los cambios de plano del vídeo, "
              "que en este caso es más fiable")
            video = True
        elif con_video and con_envolvente and not envolvente_precisa(pts):
            p(f"Con la envolvente el audio se parece al original en el {fiable:.0%} de las ventanas, pero no es el mismo "
              f"sonido (parecido mediano {float(np.median(pts[:, 2])):.2f}): se mide con los cambios de plano del vídeo, "
              "y luego se sigue al sonido")
            video = True

    CRONO["audio"] = time.time() - t_inicio     # (leer los audios, la velocidad y, si se ha hecho, la medida con él)
    musica = []
    zonas = []              # trozos con otro montaje en el doblaje (medir_video/sin_encaje): van con el original
    dudosas = None          # con velocidad variable (medir_deriva): trechos que la imagen no deja comprobar; se avisa
    curva = None            # con velocidad variable y estirar_variable: el desfase continuo con que se estira
    voz8 = None             # con la imagen, el doblaje a AR en mono: para ver si su sonido va desfasado de su imagen
    avisos_sonido = []      # si ese desfase cambia a lo largo del episodio (seguir_al_sonido)
    if video:
        voz8 = es8.mean(1).astype(np.float32)
        del es8
        p("Señal de análisis: vídeo (cambios de plano)")
        v_previa = vel if vel and vel != 1 else Fraction(1)
        segs, k, L, cambios, vel_v, pts, zonas, dudosas, curva, avisos_v = medir_video(
            es_path, en_path, st_es, st_en, p, decodificar, v_previa if v_previa != 1 else None, estirar_variable)
        if vel_v != v_previa:       # la velocidad (o lo que se suma a la del audio) la han dado los cambios de plano
            en_len /= float(vel_v / v_previa)
            pre_s /= float(vel_v / v_previa)
        vel = vel_v
        # (con el castellano estirado los saltos ya son de 0,1 s o más, y el reajuste no sabría de la curva)
        segs2, L2 = sin_microexcursiones(segs, L) if curva is None else (segs, L)
        if len(L2) < len(L):
            # sin esos tramos, la deriva y los desfases se vuelven a ajustar con todos los cambios de plano (quedarse
            # con el desfase del primero dejaba el resto a 8-11 ms: 232, 225 y 221 ms en Godzilla 1x09)
            ev_, ref_ = cambios[0][cambios[1] > 0.3], cambios[2][cambios[3] > 0.15]
            k, L, _n = ajustar(puntos_video(ev_, ref_, k, segs2), segs2, k, margen=0.0)
            segs = segs2
            for sg, Li in zip(segs, L):
                sg[2] = Li
    else:
        k, vetados = 0.0, []
        for it in range(8):
            niveles = [n for n in buscar_niveles(pts, k) if all(abs(n - v) > 0.1 for v in vetados)]
            if not niveles:
                # ningún desfase coherente (un audio degenerado, como un tono puro): sin esto viterbi se caía. La
                # primera vez, el desfase inicial; después, lo de la vuelta anterior (idea de Lowitle, v1.0.1)
                if it:
                    break
                niveles = [lag0]
            segs = viterbi(a, b, niveles, k)
            k, L, npts = ajustar(pts, segs, k)
            for sg, Li in zip(segs, L):
                sg[2] = Li
            segs = fusionar_iguales(segs)
            k, L, npts = ajustar(pts, segs, k)
            exc = excursiones([sg[:2] + [Li] for sg, Li in zip(segs, L)])
            if exc:                         # se repite sin esos niveles
                vetados += [e[3] for e in exc]
                musica += exc
            elif it >= 1:
                break
    entre_video = {}        # saltos que ha puesto la imagen donde el audio no encontraba nada: se cortan entre cortes
    avisos_imagen = avisos_v if video else []   # donde la imagen no coincide con lo medido (doble medida o revisión)
    doble = not video and medir != "audio" and pista_video(es_path) is not None and pista_video(en_path) is not None
    if doble and st_guia is not None:
        # con una guía que encaja en todo el episodio la imagen no tiene trozos que medir (los huecos del audio) y no
        # puede corregir al audio, que es más preciso (redondea al fotograma); leer los dos vídeos era más de la mitad
        # del tiempo (La pelu del señor Pan 3x02: 1 min 5 s de 2 min 20 s). Elegido por el usuario, 27-10-2026
        cubierto = float((pts[:, 2] > 0.4).mean()) if len(pts) else 0.0
        if cubierto >= GUIA_SIN_IMAGEN and not huecos_audio(pts, dur_es):
            p(f"Comprobación con la imagen: no hace falta (la guía encaja en el {cubierto:.0%} del episodio, sin "
              f"trozos de {MIN_HUECO_AUDIO:.0f} s sin coincidencias); no se leen los vídeos")
            doble = False
    if doble:
        # doble medida: también con la imagen. Mide los trozos donde el audio no encuentra nada y comprueba el resto,
        # con los cambios de plano y con el contenido de la imagen (revisar_con_imagen, como al medir con la imagen:
        # pedido del usuario, 21-10-2026)
        tmp_mini = tempfile.mkdtemp(prefix="miniaturas_")
        try:
            mini = (os.path.join(tmp_mini, "doblaje.gris"), os.path.join(tmp_mini, "original.gris"))
            cv = cortes_de_los_dos(es_path, en_path, st_es, st_en, vel or Fraction(1), p, decodificar, mini)
            if cv is not None:
                segs = [sg[:2] + [Li] for sg, Li in zip(segs, L)]
                segs, entre_video = completar_con_video(segs, k, pts, dur_es, p, cv)
                avisos_imagen, c_img, niveles_img = comprobar_con_imagen(segs, k, pts, cv, p)
                md, mo = leer_miniaturas(mini[0]), leer_miniaturas(mini[1])
                if md and mo and c_img is not None:
                    segs, entre_video, mas = revisar_audio_con_imagen(segs, entre_video, k, pts, cv, c_img,
                                                                      (md, (mo[0] / float(vel or 1), mo[1])), p,
                                                                      niveles_img)
                    avisos_imagen += mas
                md = mo = None              # (sueltan los archivos para poder borrarlos)
                L = [sg[2] for sg in segs]
        finally:
            shutil.rmtree(tmp_mini, ignore_errors=True)
    vel = vel or Fraction(1)
    p(f"Deriva de velocidad: {round(k * 1e6, 1) + 0.0:+.1f} ppm "      # + 0.0: sin "-0.0"
      f"({round(k * en_len * 1000) + 0:+d} ms en todo el episodio)")

    fs = int(st_es["sample_rate"]); ch = int(st_es["channels"])
    # el doblaje a calidad completa solo hace falta si hay cortes o rellenos (sin ellos se copia tal cual); si es
    # grande (una película 5.1), se trabaja en disco
    tmp = carpeta_temporal(dur_es * fs * ch * 4)
    avisos_limpieza = []

    def cargar_es():
        """El doblaje a calidad completa; con limpiar, sin el ruido de la cinta: se limpia por trozos, y si es grande
        (una película) lo leído y lo limpio van en disco, como el montaje."""
        if not limpiar:
            return cargar_pista(es_path, st_es, fs, ch, tmp)
        x, av = limpiar_vhs.limpiar(cargar_pista(es_path, st_es, fs, ch, tmp), fs, p=p, lienzo=lienzo(tmp),
                                    avance=lambda s: print(s, flush=True))
        avisos_limpieza.extend(av)
        return x
    es = db = None
    if len(L) > 1:
        es = cargar_es()
        db = niveles_db(es, fs)
    if video:       # entre el último cambio de plano de un tramo y el primero del siguiente
        cortes = [punto_entre(db, s0[1], s1[0], L[i + 1] - L[i]) for i, (s0, s1) in enumerate(zip(segs, segs[1:]))]
    else:           # los saltos que ha puesto la imagen (completar_con_video), también entre cambios de plano
        cortes = [punto_entre(db, entre_video[i][0], entre_video[i][1], L[i + 1] - L[i]) if i in entre_video
                  else punto_silencio(db, sg[1]) for i, sg in enumerate(segs[:-1])]
    if rellenar_original:
        # donde al doblaje le falta metraje y se va a rellenar con el original, el corte va justo en
        # el empalme: en un silencio cercano, ese trozo sonaría fuera de sitio o repetido
        for i in range(len(cortes)):
            if L[i + 1] - L[i] < MIN_ORIGINAL or curva is not None:     # empalme_video no sabe de la curva
                continue
            if video:
                t = empalme_video(cambios, k, L[i], L[i + 1], segs[i][1], segs[i + 1][0])
            elif i in entre_video:
                t = empalme_video(entre_video[i][2], k, L[i], L[i + 1], entre_video[i][0], entre_video[i][1])
            else:
                t = afinar_salto(a, b, segs[i][1], L[i], L[i + 1], k)
            if t is not None:
                cortes[i] = corte_exacto(db, t)

    # el castellano no se estira nunca (decisión del usuario): si va a otra velocidad que el original, aunque sea
    # poco (23,976 frente a 24 son 1000 ppm, 3,6 s por hora), se adapta el original, como con el PAL. Una deriva
    # que en todo el episodio no llega a DERIVA_REPARTIR_MS no merece tocar nada: se reparte entre los tramos. Si el
    # original ya se adapta a otra velocidad, lo que quede se mete también en ella, que no cuesta nada (una velocidad
    # medida con los cambios de plano queda a unos 8 ppm: precisión de fotograma)
    f, vel_medida = Fraction(1), vel
    if abs(k) * en_len * 1000 > DERIVA_REPARTIR_MS or vel != 1:
        nueva = velocidad_final(vel * Fraction(1 + k), en_len)
        f, vel = nueva / vel, nueva
    resto = (1 + k) / float(f) - 1
    bordes = [0.0] + [c["c"] for c in cortes] + [dur_es]
    if curva is None:
        L = [Li / float(f) + resto * (bordes[i] + bordes[i + 1]) / 2 for i, Li in enumerate(L)]
    else:                   # castellano estirado: lo que quede de la velocidad va en la curva, no por tramos
        L = [Li / float(f) for Li in L]
        curva = np.column_stack([curva[:, 0], curva[:, 1] / float(f) + resto * curva[:, 0]])
    for z in zonas:         # en el tiempo del resultado (el original a su velocidad final), dentro del episodio
        z["z0"], z["z1"] = max(0.0, z["z0"] / float(f)), min(en_len / float(f), z["z1"] / float(f))
    zonas = [z for z in zonas if z["z1"] - z["z0"] >= 1.0]
    if f != 1:
        # todo lo medido en el tiempo del original pasa a su nueva velocidad
        en_len /= float(f)
        pre_s /= float(f)
        if video:
            cambios = cambios[:2] + (cambios[2] / float(f), cambios[3])
        else:
            b = acelerar(b, f)
        pts = np.asarray(pts).reshape(-1, 3)
        pts = np.column_stack([pts[:, 0], (pts[:, 0] + pts[:, 1]) / float(f) - pts[:, 0], pts[:, 2]])
        cual = "afinada con la deriva" if vel_medida != 1 else "por la deriva"
        p(f"Velocidad ({cual}): {texto_velocidad(vel, es_path, en_path)}; se adapta el original al doblaje"
          if vel != 1 else f"Velocidad ({cual}): al final, la misma que el original")
    if round(abs(resto) * en_len * 1000) and curva is None:
        err = max(abs(resto) * (y - x) / 2 for x, y in zip(bordes, bordes[1:])) * 1000
        p(f"Deriva{' que queda' if f != 1 else ''}: {resto * en_len * 1000:+.0f} ms en todo el episodio; se "
          f"reparte entre los tramos, sin estirar el castellano (como mucho ±{err:.0f} ms)")
    if curva is not None:
        # cuánto se acelera (+) o se frena (-) el castellano al estirarlo, a lo largo del episodio
        cambio = -np.diff(curva[:, 1]) / np.diff(curva[:, 0]) * 100
        pct = lambda x: f"{x:+.1f}".replace(".", ",")
        n = len(L) - 1
        p(f"Velocidad variable: el castellano se estira siguiendo la del original (entre {pct(cambio.min())} % y "
          f"{pct(cambio.max())} %, de media {pct(float(np.mean(cambio)))} %)"
          + (f" y se cortan {n} salto{'s' if n > 1 else ''}" if n else ", sin cortes") + "; el original no se toca")
    k = 0.0
    L_medido, cortes_medidos = list(L), list(cortes)       # para comprobarlo con la imagen, que no ve lo de a mano
    # con guía: ¿la pista doblada va de verdad a la par de ella? Se contrasta con el original (contrastar_doblada)
    contraste = y8 = x_contraste = None     # x_contraste: la pista doblada en mono a AR con que se ha contrastado
    L_base, cortes_base = list(L), list(cortes)             # (las demás pistas dobladas se contrastan desde lo medido)
    ref_contraste, estricto = "la guía", False
    avisos_contraste = []

    def dame_db():
        nonlocal es, db
        if db is None:
            es = cargar_es()
            db = niveles_db(es, fs)
        return db

    def original_contraste():
        """El original en mono a AR, a la velocidad del resultado. Con el tono corregido, la onda del doblaje no se
        parece a la del original remuestreado, pero en los graves sí a la del original acelerado sin cambiar el tono
        (como al comparar la imagen con el sonido; si no se parece, el contraste lo dice y no toca nada); atempo lo
        retrasa unos ms, y la guía se ha colocado contra el remuestreado: se descuenta (sin_retardo)."""
        y = cargar_sin_tono(en_path, st_en, AR, vel) if con_envolvente else None
        y_res = en8.mean(1).astype(np.float32)
        if vel != v_en8:
            y_res = acelerar(y_res, vel / v_en8)
        return y_res if y is None else sin_retardo(y, y_res)

    if st_es["index"] in mono8 and not video and curva is None:
        t_c = time.time()
        y8, x_contraste = original_contraste(), mono8[st_es["index"]]
        L, cortes, contraste = contrastar_doblada(x_contraste, y8, L, cortes, dur_es, dame_db, con_envolvente)
        for linea in texto_contraste(contraste):
            p(linea)
        if contraste["estado"] == "corregido":
            ds = [abs(x[2]) for x in contraste["partes"]]
            avisos_contraste.append(f"el castellano no iba a la par de la guía dentro del doblaje (hasta {max(ds) * 1000:.0f}"
                                    " ms según el trozo); se ha corregido por trozos contrastándolo con el original")
            avisos_contraste += avisos_dudas(contraste)
        elif contraste["estado"] == "sin_medida":
            avisos_contraste.append("no se ha podido comprobar que el castellano vaya a la par de la guía dentro del "
                                    "doblaje (se parece demasiado poco al original): se ha dado por hecho")
        CRONO["contraste"] = time.time() - t_c
    if voz8 is not None:
        # medido con la imagen: ¿el sonido del doblaje va desfasado de su imagen? (desfase_imagen_sonido)
        en8m = en8.mean(1).astype(np.float32)
        if vel != v_en8:
            en8m = acelerar(en8m, vel / v_en8)
        ini_, fin_ = limites(cortes, L, dur_es)
        desf_ = lambda i: (lambda t: L[i] + (float(deriva_en(t, curva)) if curva is not None else 0.0))
        tramos_av = [(a_, b_, desf_(i)) for i, (a_, b_) in enumerate(zip(ini_, fin_))]
        if abs(vel - 1) > 0.01:
            # los DVD PAL suelen traer el audio con el tono corregido (sin el 4 % de más del vídeo acelerado), y con el
            # original remuestreado apenas se parecía (Kojak 4x24: 104 ventanas encajaban al final frente a 464): se
            # prueba también el original acelerado sin cambiar el tono (en la banda grave de estas ventanas, la onda
            # de dos aceleraciones hechas por separado sí se parece)
            otro = cargar_sin_tono(en_path, st_en, AR, vel)
            if otro is not None and (len(ventanas_sonido(voz8, otro, tramos_av))
                                     > 1.2 * len(ventanas_sonido(voz8, en8m, tramos_av))):
                p("Para comparar el sonido con su imagen: el audio del doblaje tiene el tono corregido (como en muchos "
                  "DVD PAL); se compara con el original acelerado sin cambiar el tono")
                en8m = otro
            otro = None
        av = desfase_imagen_sonido(voz8, en8m, tramos_av)
        seguido = None
        if curva is None and dudosas is None:      # (velocidad fija: con la variable, los tramos son de segundos)
            v_av = ventanas_sonido(voz8, en8m, tramos_av, *VENTANA_AV_TRAMO)
            if len(v_av) >= MIN_AV_TRAMO * SOLAPE_AV_TRAMO:
                if db is None:
                    es = cargar_es()
                    db = niveles_db(es, fs)
                seguido = seguir_al_sonido(v_av, L, cortes, db, dur_es, p)
        voz_c, voz8, en8m = voz8, None, None
        if seguido:
            L, cortes, partes_av, comun = seguido
            pct = lambda d: f"{abs(d) * 1000:.0f} ms {'tarde' if d < 0 else 'adelantado'}"
            p(f"Desfase entre la imagen y el sonido del propio doblaje: no es el mismo en todo el episodio (de "
              f"{min(x[2] for x in partes_av) * 1000:+.0f} a {max(x[2] for x in partes_av) * 1000:+.0f} ms); se sigue al "
              f"sonido en cada trozo, con cortes en los silencios:")
            for a_, b_, d, n in partes_av:
                p(f"  {mmss(a_):>9}-{mmss(b_)} del doblaje: su sonido va {pct(d)} respecto a su imagen ({n} ventanas)")
            if comun is not None:
                p(f"  lo que no se puede medir va con el más repetido ({pct(comun)})")
            avisos_sonido.append("el sonido del doblaje no va igual de desfasado de su imagen en todo el episodio (lo "
                                 "suelen tener los audios puestos a mano sobre otro vídeo); se ha seguido al sonido por "
                                 "trozos, conviene comprobarlo")
        elif av and abs(av[0]) >= MIN_AV:
            L = [x + av[0] for x in L]
            p(f"Desfase entre la imagen y el sonido del propio doblaje: su sonido va {abs(av[0]) * 1000:.0f} ms "
              f"{'tarde' if av[0] < 0 else 'adelantado'} respecto a su imagen (lo dicen {av[1]} de las {av[2]} "
              "ventanas en que los dos audios se parecen algo); se corrige")
        # lo de seguir al sonido solo ve partes que se apartan 0,2 s o más (con la banda grave y ventanas de 6 s no da
        # para menos), y en Diagnóstico asesinato se notaban 100-180 ms: el contraste, más fino, lo mira también aquí,
        # estricto (otra mezcla: menos que compartir; lo que no mida, donde lo pone la imagen)
        if curva is None and dudosas is None:
            t_c = time.time()
            x_contraste = mono8.get(st_es["index"], voz_c)
            y8 = original_contraste()
            L_base, cortes_base = list(L), list(cortes)
            ref_contraste, estricto = "su imagen", True
            L, cortes, contraste = contrastar_doblada(x_contraste, y8, L, cortes, dur_es, dame_db, con_envolvente,
                                                      estricto=True)
            for linea in texto_contraste(contraste, ref="su imagen"):
                p(linea)
            if contraste["estado"] == "corregido":
                ds = [abs(x[2]) for x in contraste["partes"]]
                avisos_contraste.append(f"el sonido del doblaje no iba a la par de su imagen en algunos trozos (hasta "
                                        f"{max(ds) * 1000:.0f} ms); se ha corregido por trozos contrastándolo con el "
                                        "original")
                avisos_contraste += avisos_dudas(contraste)
            CRONO["contraste"] = time.time() - t_c
        voz_c = None
    if correcciones:        # a mano, sobre lo medido (leer_correcciones); los cortes nuevos, en un silencio
        if db is None:
            es = cargar_es()
            db = niveles_db(es, fs)
        L, cortes = aplicar_correcciones(leer_correcciones(correcciones) if isinstance(correcciones, str)
                                         else correcciones, L, cortes, db, dur_es, p, curva)
    inicio = L[0] + (float(deriva_en(0.0, curva)) if curva is not None else 0.0)     # desfase al principio
    # con la velocidad variable (y sin estirar), el hueco de un corte que inserta se tapa alargando lo de alrededor, y
    # lo que se quita y no cabe en una pausa se acorta: en 16:05 de Ninja Sasuke 2, 0,9 s donde lo más flojo era la voz
    # a -11 dB (una pausa de verdad está cerca del fondo de ruido del doblaje: su soplido, a -29 dB)
    piso = float(np.percentile(db, 5)) if db is not None and len(db) else -120.0
    con_puente = lambda i, d: (0 < d < MIN_ORIGINAL
                               or (-MIN_ORIGINAL < d < 0 and (cortes[i]["q1"] - cortes[i]["q0"] < -d
                                                              or cortes[i]["suelo"] > piso + 6)))
    puentes = ([i for i in range(len(cortes)) if con_puente(i, L[i + 1] - L[i])]
               if dudosas is not None and curva is None else [])

    pre = int(round(pre_s * fs))
    # lo que le falte al doblaje se rellena con la pista original (convertida a su formato)
    original = (lambda tramos: cargar_tramos(en_path, st_en, fs, ch, tramos, vel)) if rellenar_original else None
    ext = os.path.splitext(out_path)[1].lower()
    hueco = (rellenar_original and (inicio >= MIN_ORIGINAL or en_len - inicio - dur_es >= MIN_ORIGINAL)) or bool(zonas)
    # el formato: el de la extensión si se ha pedido un .ac3/.eac3; si no, el elegido (FLAC de serie)
    formato = {".ac3": "ac3", ".eac3": "eac3"}.get(ext, formato if formato in FORMATOS else "flac")
    # estirado o limpio nunca va tal cual
    tal_cual = len(L) == 1 and not hueco and ext == ".mka" and curva is None and not limpiar
    # canales o kb/s pedidos que no son los suyos: se recodifica sin preguntar (intacto no puede cambiarlos)
    pedido = motivo_recodificar(canales, kbps, formato, st_es, es_path) if tal_cual else None
    convertir = tal_cual and (bool(pedido) or convertir_sin_cortes(sin_cortes, formato, st_es, p))
    if tal_cual and not convertir:
        out, coloc, rellenos = None, [(L[0], L[0] + dur_es)], []     # va tal cual: no hay nada que montar
    else:
        if es is None:
            es = cargar_es()
        out, coloc, rellenos = montar(es, fs, k, L, cortes, en_len, pre, original, lienzo(tmp),
                                      [(z["z0"], z["z1"], z["a"]) for z in zonas], curva, puentes, p)

    p("")
    p(f"Inicio: {'recortados' if inicio < 0 else 'añadidos'} {abs(inicio) * 1000:.0f} ms")
    avisos = list(avisos_pistas) + avisos_imagen + avisos_sonido + avisos_contraste + avisos_limpieza
    for z in zonas:
        con = "el audio original" if rellenar_original else "silencio (sin relleno con el original)"
        p(f"Montaje distinto {mmss(z['z0'])}-{mmss(z['z1'])}: va con {con}; en el doblaje ({mmss(z['a'])}-"
          f"{mmss(z['b'])}) la escena está montada de otra forma y solo encajan {z['m']} de sus {z['n']} cambios de "
          "plano")
        avisos.append(f"{mmss(z['z0'])}-{mmss(z['z1'])}: el doblaje tiene ahí otro montaje (otro resumen, otra "
                      f"edición); va con {con}, conviene comprobarlo")
    for d0, d1, desvio in dudosas or []:
        if desvio is None:
            avisos.append(f"{mmss(d0)}-{mmss(d1)} del doblaje: la imagen no deja comprobar ahí la sincronía (fundidos, "
                          "destellos o algún plano montado de otra forma); va con el desfase de al lado, conviene "
                          "escucharlo")
        else:
            avisos.append(f"{mmss(d0)}-{mmss(d1)} del doblaje: corregido con el contenido de la imagen ("
                          f"{desvio[0] * 1000:+.0f} a {desvio[1] * 1000:+.0f} ms; los cambios de plano no bastaban), "
                          "conviene escucharlo")
    _, fines_ = limites(cortes, L, dur_es)
    sin_silencio = []
    for i, c in enumerate(cortes):
        d = L[i + 1] - L[i]
        tipo = "silencio digital" if c["suelo"] < -90 else ("cortinilla" if c["suelo"] < -40 else "cambio de escena sin negro")
        if c.get("exacto"):
            tipo = "empalme con lo que falta"
        if i in puentes:            # no se repite ni se corta nada: da igual que no haya silencio
            tipo = "se alarga lo de alrededor, sin repetir" if d > 0 else "se acorta lo de alrededor, sin cortar"
        if c.get("manual"):
            tipo = f"corrección a mano; {tipo}"
        extra = ""
        if i in puentes:
            pass
        elif recorte_desplazado(c, L, i, fines_):
            extra = f"  <- no cabe centrado: se quita desde {mmss(fines_[i])}"
            avisos.append(f"corte {mmss(c['c'])}: el recorte de {-d:.1f} s no cabe centrado en el corte, "
                          f"conviene escucharlo")
        elif d < 0 and (c["q1"] - c["q0"]) < -d:
            extra = "  <- se recorta más de lo que dura el silencio"; avisos.append(f"corte {mmss(c['c'])}: recorte fuera del silencio")
        if c["suelo"] >= -40 and not c.get("exacto") and i not in puentes:
            sin_silencio.append(mmss(c["c"]))
        p(f"Corte {mmss(c['c']):>9}  {'inserta' if d >= 0 else 'recorta'} {abs(d) * 1000:6.0f} ms  "
          f"[{tipo}, suelo {c['suelo']:.0f} dB]{extra}")
    # muchos (un doblaje de VHS con velocidad variable: decenas de cortes pequeños con música o ruido de fondo
    # continuo): un solo aviso; la lista de cortes ya dice cuáles
    if len(sin_silencio) > 10:
        avisos.append(f"{len(sin_silencio)} cortes sin silencio claro (de {sin_silencio[0].strip()} a "
                      f"{sin_silencio[-1].strip()}, en la lista de cortes): conviene escuchar alguno")
    else:
        avisos += [f"corte {t}: sin silencio claro, conviene escucharlo" for t in sin_silencio]
    for t0, t1, d, _ in musica:
        p(f"Sin corte {mmss(t0):>9}-{mmss(t1)}  la música del doblaje va {d:+.1f} s desplazada; "
          f"el diálogo sigue en su sitio")
        avisos.append(f"{mmss(t0)}-{mmss(t1)}: música desplazada {d:+.1f} s en el doblaje, no se corta; conviene escucharlo")
    for t_dob, a0, a1, gdb in rellenos:
        o0, o1 = (a0 - pre) / fs, (a1 - pre) / fs
        p(f"Relleno {mmss(t_dob):>9}  {(a1 - a0) / fs * 1000:6.0f} ms  con el audio original "
          f"({mmss(o0)}-{mmss(o1)} del original, {gdb:+.1f} dB)")
        avisos.append(f"relleno {mmss(o0)}-{mmss(o1)}: {o1 - o0:.1f} s con el audio original, "
                      f"conviene escuchar las uniones")
    p(f"Final: longitud ajustada a la del original ({en_len:.3f} s)")
    p(f"Retraso de la pista original aplicado al principio: {pre_s * 1000:.0f} ms (muxear con delay 0)")

    inicios, fines = limites(cortes, L, dur_es)
    mapa = dict(pre=pre / fs, k=k, L=L, inicios=inicios, fines=fines, vel=[vel.numerator, vel.denominator])
    if curva is not None:       # castellano estirado: mapear() sigue la curva (desfase continuo cada segundo)
        mapa["curva"] = [[round(float(a), 3), round(float(b), 4)] for a, b in curva]
    subs_dob = pistas_sub_doblaje(es_path)
    if forzados:
        if any(s["ext"] for s in subs_dob):
            p("Forzados: el doblaje ya trae subtítulos; no se leen con OCR")
        else:
            avisos += generar_forzados(es_path, float(st_es.get("start_time") or 0), mapa, out_path, forz_idioma,
                                       p, decodificar)[1]
    if video:
        # los cambios de plano del doblaje, llevados con el mapa final, frente a los del original
        # con lo medido: con las correcciones a mano, la imagen daría su ajuste como desfase en todos los tramos
        ini_m, fin_m = limites(cortes_medidos, L_medido, dur_es)
        v = verificar_video(cambios, dict(mapa, L=L_medido, inicios=ini_m, fines=fin_m), ini_m, fin_m,
                            [(z["a"], z["b"]) for z in zonas])
        desf_m = lambda t, i: L_medido[i] + (float(deriva_en(t, curva)) if curva is not None else 0.0)
        lugar_v = [(a + desf_m(a, i), b + desf_m(b, i)) for i, (a, b) in enumerate(zip(ini_m, fin_m))]
    else:
        # la señal con la que se ha medido (la guía o el propio doblaje, a 8 kHz), montada con los mismos cortes
        pre8 = int(round(pre_s * AR))
        g_out, lugar_v, _ = montar(es8, AR, k, L_medido, cortes_medidos, en_len, pre8)
        v = verificar(g_out, AR, pre8, b, lateral * signo, lugar_v,
                      [((a0 - pre) / fs, (a1 - pre) / fs) for _, a0, a1, _ in rellenos],
                      envolvente_ar if con_envolvente else None)
        # sin guía, esa verificación es con la misma señal con que se ha medido: el doblaje se guarda para
        # verificarlo también con el contraste, que es otra medida (ventanas de 15 s, la mezcla y los graves)
        x_sin_guia = es8.sum(1).astype(np.float32) if st_guia is None and curva is None else None
        del g_out, es8
    # con guía, la verificación con la guía no dice nada de la pista doblada (la guía se mide consigo misma): también
    # con la propia pista doblada, montada como va a quedar, frente al original
    vc = None
    excl_rellenos = [((a0 - pre) / fs, (a1 - pre) / fs) for _, a0, a1, _ in rellenos]
    if contraste is not None and contraste["estado"] != "sin_medida":
        t_c = time.time()
        vc = verificar_contraste(x_contraste, y8, L, cortes, en_len, excl_rellenos, con_envolvente)
        CRONO["contraste"] = CRONO.get("contraste", 0.0) + time.time() - t_c
    elif not video and x_sin_guia is not None:
        # (Diagnóstico asesinato 6x09 solo con el castellano, 9 % de ventanas que se parecen: su verificación decía 4,6
        # ms y una medida aparte, 21; no se corrige nada con esto, se dice y se avisa si un tramo pasa de 25 ms)
        t_c = time.time()
        vc = verificar_contraste(x_sin_guia, original_contraste(), L, cortes, en_len, excl_rellenos, con_envolvente)
        CRONO["contraste"] = CRONO.get("contraste", 0.0) + time.time() - t_c
    x_sin_guia = None
    # una medida disparatada no se guarda (película en la que el seguimiento se perdió y encajó cortes al azar:
    # 42 tramos con desfases de horas y casi todo relleno en inglés)
    problemas = []
    if video and v.get("total") and v["n"] < 0.3 * v["total"]:
        problemas.append(f"tras el montaje solo encajan {v['n']} de {v['total']} cambios de plano del doblaje")
    relleno_s = sum((a1 - a0) / fs for _, a0, a1, _ in rellenos)
    if relleno_s > 0.5 * en_len:
        problemas.append(f"{relleno_s / 60:.0f} de sus {en_len / 60:.0f} minutos serían audio del original")
    if problemas:
        diag = escribir_diagnostico(out_path, log, L, pts, video)
        raise RuntimeError("la medida no es fiable (" + "; ".join(problemas) + "), así que no se guarda nada. "
                           "¿Son el mismo montaje? Diagnóstico: " + diag)
    # subtítulos: para qué versión está hecho cada uno, sus erratas y su conversión. Se preparan aquí para que sus
    # avisos salgan con los demás, y se escriben al final, con el audio ya guardado
    subs_pendientes = []
    if sub_path:
        p("")
        sub_out = os.path.splitext(out_path)[0] + os.path.splitext(sub_path)[1]
        # si no se puede comprobar: el del original si se llama como él (la GUI lo coge sola así); si no, del doblaje
        defecto = "original" if mismo_nombre(sub_path, en_path) and not mismo_nombre(sub_path, es_path) else "doblaje"
        datos, n, informe, av = preparar_subtitulo(sub_path, mapa, voces, t_audio, defecto, os.path.basename(sub_path),
                                                   duracion=en_len)
        for x in informe:
            p(f"Subtítulos: {x}")
        avisos += av
        subs_pendientes.append((sub_out, datos, f"Subtítulos: {n} líneas ajustadas -> {sub_out}"))
    if subs_dob:
        pend, av, _ = preparar_subs_doblaje(es_path, t_audio, mapa, out_path, p, voces, duracion=en_len)
        subs_pendientes += pend
        avisos += av
    p("")
    if v["n"]:
        con = " (con el vídeo)" if video else (" (con la pista guía)" if st_guia else "")
        p(f"Verificación{con}: mediana {v['p50']:.1f} ms, p90 {v['p90']:.1f} ms "
          + (f"({v['n']} de {v['total']} cambios de plano encajan)" if video else
             f"({v['n']} de {v['total']} ventanas encajan en su sitio)"))
        if not video and v["n"] < max(10, 0.15 * v["total"]):
            # con audio flojo la cifra sale de unas pocas ventanas: que no parezca más de lo que es
            p(f"  (solo {v['n']} de {v['total']} ventanas se parecen lo bastante al original para comprobarlo: es una "
              "cifra orientativa)")
    elif not video:
        p("Verificación: ninguna ventana se parece lo bastante al original para comprobarlo (el audio del doblaje se "
          "parece poco)")
    if vc is not None:
        if vc["n"]:
            p(f"Verificación (con el castellano): mediana {vc['p50']:.1f} ms, p90 {vc['p90']:.1f} ms ({vc['n']} de "
              f"{vc['total']} ventanas encajan: su música y sus efectos frente a los del original, ya montado)")
        else:
            p("Verificación (con el castellano): ninguna ventana se parece lo bastante al original para comprobarlo")
    # con velocidad variable cada tramo admite ±TOL_DERIVA por diseño: avisar a partir de 25 ms sería avisar de todo.
    # Medido con la imagen, la precisión es un fotograma: 37-40 ms a 25 fps eran el redondeo (Kojak 4x24, «tramo 2:
    # desfase residual +37 ms», y el episodio estaba bien); se avisa a partir de un fotograma y 10 ms
    if dudosas is not None:
        residuo_max = TOL_DERIVA * 1000
    elif video:
        residuo_max = max(25.0, 1000 / float(fps_video(es_path) or 25) + 10)
    else:
        residuo_max = 25
    for i, (n, med) in enumerate(v["por_seg"]):
        if med is not None and n >= 3 and abs(med) > residuo_max:
            avisos.append(f"tramo {i + 1} ({mmss(lugar_v[i][0])}-{mmss(lugar_v[i][1])}): desfase residual {med:+.0f} ms")
    for (n, med), (a0, a1) in zip(vc["por_seg"] if vc else [], vc["coloc"] if vc else []):
        # (positivo: en el original suena más tarde, así que el castellano va adelantado)
        if med is not None and n >= 3 and abs(med) > residuo_max:
            avisos.append(f"{mmss(a0)}-{mmss(a1)}: el castellano queda {abs(med):.0f} ms "
                          f"{'adelantado' if med > 0 else 'tarde'} del original (desfase residual, contrastado con él)")
    # trechos que tras el montaje no encajan en su sitio pero sí más lejos (la guía o el propio doblaje, como se haya
    # medido; y el castellano, si se ha contrastado)
    avisos += avisos_descolocados(v.get("descolocados", []), "de la guía" if st_guia else "del doblaje")
    avisos += avisos_descolocados(vc.get("descolocados", []) if vc else [])
    for d0, d1, a_, b_, n in v.get("sueltos", []):
        if any(z0 < d1 and d0 < z1 for z0, z1, desvio in dudosas or [] if desvio is None):
            continue            # (ya avisado: la imagen no deja comprobar ahí la sincronía)
        avisos.append(f"{mmss(a_)}-{mmss(b_)}: {n} cambios de plano seguidos del doblaje no encajan con el original; "
                      "puede estar descolocado, conviene comprobarlo")
    p("Avisos: " + ("ninguno" if not avisos else ""))
    for a_ in [a for a in avisos if para_revisar(a)] + [a for a in avisos if not para_revisar(a)]:
        p(f"  - {'[revisar] ' if para_revisar(a_) else ''}{a_}")

    # sin cortes ni rellenos, el doblaje va tal cual (sin recodificar: no pierde nada), solo con su desfase, salvo
    # que se haya pedido pasarlo al formato elegido; si hay que editarlo, en ese formato (FLAC de serie: el usuario
    # trabaja así). Su velocidad no se toca nunca: la deriva ya la ha absorbido el original o se ha repartido
    motivos =[x for x, c in (("hay cortes", len(L) > 1), ("se rellena con el original", bool(rellenos)),
                             ("convertido a petición; no había cortes", convertir and not pedido),
                             (f"{pedido}; no había cortes", bool(pedido)),
                             ("se estira por la velocidad variable", curva is not None)) if c]
    intacto = not motivos and ext == ".mka"
    if intacto:
        copiar_intacto(es_path, st_es, pre_s + L[0], out_path)
        p(f"Audio doblado: intacto, sin recodificar (no hay cortes); va con {round((pre_s + L[0]) * 1000) + 0:+d} ms "
          f"de desfase")
    else:
        layout = st_es.get("channel_layout") or {1: "mono", 2: "stereo", 6: "5.1"}.get(ch, f"{ch}c")
        # los kb/s pedidos o, en el mismo formato y canales que el doblaje, los suyos (medidos si el MKV no los apunta)
        bitrate = bitrate_salida(formato, st_es, es_path, canales, kbps)
        cambio_canales = codificar(out, fs, layout, formato, bitrate, out_path, canales)
        p(f"Audio doblado: en {texto_formato(formato, bitrate)}" + (f", {cambio_canales}" if cambio_canales else "")
          + " (" + (", ".join(motivos) if motivos else "el archivo de salida no es .mka") + ")")
    p(f"Guardado: {out_path}")
    p(f"Tiempo: {texto_tiempo(time.time() - t_inicio)}")
    out = es = None                 # una película 5.1 son varios GB por pista: de una en una
    if tmp:
        shutil.rmtree(tmp, ignore_errors=True)
    if otras:
        for s in otras:
            ruta = ruta_pista_extra(out_path, s)
            if os.path.exists(ruta):
                p(f"Pista del doblaje {describir_pista(s)}: ya existe {ruta}; se deja")
                continue
            p(f"Sincronizando también la pista {describir_pista(s)} del doblaje...")
            try:
                L_s, cortes_s = L, cortes
                if contraste is not None and s["index"] in mono8:
                    # tampoco se da por hecho que esta vaya a la par de la guía: su propio contraste, desde lo medido
                    # con la guía, y los cortes nuevos en sus silencios (a AR basta para encontrarlos)
                    d_n = int(round((float(s.get("start_time") or 0) - float(st_es.get("start_time") or 0)) * AR))
                    x_s = mono8[s["index"]]
                    x_s = np.concatenate([np.zeros(d_n, np.float32), x_s]) if d_n > 0 else x_s[-d_n:]
                    db_s = niveles_db(x_s.reshape(-1, 1), AR)
                    L_s, cortes_s, inf_s = contrastar_doblada(x_s, y8, L_base, cortes_base, dur_es, lambda: db_s,
                                                              con_envolvente, estricto)
                    for linea in texto_contraste(inf_s, f"de la pista {describir_pista(s)}", ref_contraste):
                        p(linea)
                    for a_ in avisos_dudas(inf_s, f"de la pista {describir_pista(s)}"):
                        p(f"  - {a_}")
                    if correcciones:
                        L_s, cortes_s = aplicar_correcciones(leer_correcciones(correcciones)
                                                             if isinstance(correcciones, str) else correcciones,
                                                             L_s, cortes_s, db_s, dur_es, lambda *a, **kw: None, curva)
                    x_s = db_s = None
                br, cambio_canales = sincronizar_otra_pista(es_path, s, st_es, en_path, st_en, k, L_s, cortes_s, en_len,
                                                    pre_s, rellenar_original, ruta, vel, intacto and len(L_s) == 1,
                                                    formato, curva, puentes, canales, kbps)
                p(f"Pista del doblaje {describir_pista(s)}: sincronizada con los mismos cortes -> {ruta}"
                  + (" (intacta)" if br is False else f" ({texto_formato(formato, br)}"
                     + (f", {cambio_canales}" if cambio_canales else "") + ")"))
            except Exception as e:
                borrar_si_existe(ruta)
                p(f"Pista del doblaje {describir_pista(s)}: no se ha podido sincronizar ({e})")

    escribir_pendientes(subs_pendientes, p)
    # el mapa permite ajustar más subtítulos de este episodio aunque se borre el audio
    p("Mapa: " + json.dumps(mapa))
    with open(os.path.splitext(out_path)[0] + "_informe.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(log) + "\n")
    return avisos


def escribir_diagnostico(out_path, log, L, pts, video):
    """Cuando la medida no es fiable: el registro, los desfases de cada tramo y el seguimiento completo
    (tiempo del doblaje, desfase, confianza), para estudiar el caso sin tener los archivos."""
    ruta = os.path.splitext(out_path)[0] + "_diagnostico.txt"
    with open(ruta, "w", encoding="utf-8") as f:
        f.write("\n".join(log) + "\n\n")
        f.write(f"Tramos: {len(L)}; desfases (s): " + ", ".join(f"{x:+.3f}" for x in L) + "\n\n")
        f.write(f"Seguimiento ({'cambios de plano' if video else 'audio'}): t_doblaje_s desfase_s confianza\n")
        for t, lag, c in np.asarray(pts).reshape(-1, 3):
            f.write(f"{t:9.2f} {lag:+10.3f} {c:.3f}\n")
    return ruta


def base_salida(es_path):
    return re.split(r"_track\d+", os.path.splitext(os.path.basename(es_path))[0])[0]


def nombre_salida(es_path, idioma, ext):
    """«..._[es-ES]_SYNC.mka» (el idioma, el del castellano: el del muxeado). Hasta el 21-10-2026 era
    «..._[spa]_SYNC_ENG»: el ENG confundía (el original no siempre es inglés) y la etiqueta se ponía aparte."""
    return os.path.join(os.path.dirname(es_path), f"{base_salida(es_path)}_[{idioma}]_SYNC.{ext}")


DERIVA_REPARTIR_MS = 20     # una deriva menor en todo el episodio se reparte (±10 ms) sin cambiar velocidades


def ruta_salida(es_path, idioma="es-ES", carpeta=None, pista=None):
    """Audio sincronizado, en .mka: la pista del doblaje tal cual si no hay cortes, o en FLAC; junto al doblaje
    o en `carpeta`. Si ya hay uno de antes, se devuelve ese: con otra extensión (.flac, .ac3, .eac3) o con el nombre
    antiguo («..._[spa]_SYNC_ENG»), para que lo ya hecho se reconozca (no se repite, y «solo muxear» lo encuentra)."""
    ruta = nombre_salida(es_path, idioma, "mka")
    if carpeta:
        ruta = os.path.join(carpeta, os.path.basename(ruta))
    if os.path.exists(ruta):
        return ruta
    sitio, base = os.path.dirname(ruta), base_salida(es_path)
    for etiqueta in dict.fromkeys([idioma, idioma_iso(idioma) or "spa", "spa"]):
        for fin in ("_SYNC", "_SYNC_ENG"):
            for ext in ("mka", "flac", "ac3", "eac3"):
                vieja = os.path.join(sitio, f"{base}_[{etiqueta}]{fin}.{ext}")
                if os.path.exists(vieja):
                    return vieja
    return ruta


def copiar_intacto(path, st, inicio, ruta):
    """La pista st de path sin recodificar, en un .mka, con su primera muestra en `inicio` s (negativo: se
    quita lo que sobra del principio, por paquetes enteros)."""
    with tempfile.TemporaryDirectory(prefix="intacto_") as tmp:
        bruto = os.path.join(tmp, "pista.mka")
        r = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-map", f"0:{st['index']}", "-c", "copy", bruto],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", **SIN_VENTANA)
        if r.returncode != 0:
            raise RuntimeError("no se ha podido copiar la pista: " + " ".join(r.stderr.strip().splitlines()[-1:]))
        s0 = float(probe_audio(bruto).get("start_time") or 0)
        mkvmerge = ruta_mkvmerge()
        if mkvmerge:
            r = subprocess.run([mkvmerge, "-q", "-o", ruta, "--sync", f"0:{round((inicio - s0) * 1000)}", bruto],
                               capture_output=True, text=True, encoding="utf-8", errors="replace", **SIN_VENTANA)
            if r.returncode >= 2:
                borrar_si_existe(ruta)
                raise RuntimeError("mkvmerge falló: " + " ".join((r.stdout or r.stderr).strip().splitlines()[-1:]))
        else:
            d = inicio - s0
            r = subprocess.run(["ffmpeg", "-v", "error", "-n"] + (["-itsoffset", f"{d:.3f}"] if d >= 0 else
                                                                   ["-ss", f"{-d:.3f}"]) + ["-i", bruto, "-c", "copy", ruta],
                               capture_output=True, text=True, encoding="utf-8", errors="replace", **SIN_VENTANA)
            if r.returncode != 0:
                borrar_si_existe(ruta)
                raise RuntimeError("ffmpeg falló: " + " ".join(r.stderr.strip().splitlines()[-1:]))


def idioma_pista(s):
    return idioma_valido(next((v for k, v in (s.get("tags") or {}).items() if k.lower() == "language"), ""))


def ruta_pista_extra(out_path, s):
    """Otra pista doblada del mismo archivo, junto a la principal: ..._SYNC_pista3_[cat].mka (tal cual si
    no hay cortes, o en FLAC)."""
    idioma = idioma_pista(s)
    return f"{os.path.splitext(out_path)[0]}_pista{s['_n']}" + (f"_[{idioma}]" if idioma else "") + ".mka"


def sincronizar_otra_pista(es_path, s, st_ref, en_path, st_en, k, L, cortes, en_len, pre_s, rellenar, ruta,
                           vel=Fraction(1), intacto=False, formato="flac", curva=None, puentes=(), canales="igual",
                           kbps=None):
    """Otra pista doblada del mismo archivo con los mismos cortes que la principal (van a la par dentro del
    archivo; si empieza en otro momento, se alinea con ella). Lo que le falte, del original, como a la principal.
    intacto: la principal va sin recodificar (no hay cortes): esta también, con su mismo desfase, salvo que se hayan
    pedido canales o kb/s que no son los suyos (motivo_recodificar). Si no, en `formato`, `canales` y `kbps`, como la
    principal. curva: estirada como la principal (velocidad variable).
    Devuelve (bitrate con que se ha codificado (None en FLAC; False si va intacta), cambio de canales)."""
    d_s = float(s.get("start_time") or 0) - float(st_ref.get("start_time") or 0)
    codec = {".ac3": "ac3", ".eac3": "eac3"}.get(os.path.splitext(ruta)[1].lower(), formato)
    if intacto and not motivo_recodificar(canales, kbps, codec, s, es_path):
        copiar_intacto(es_path, s, pre_s + L[0] + d_s, ruta)
        return False, ""
    fs, ch = int(s["sample_rate"]), int(s["channels"])
    tmp = carpeta_temporal(en_len * fs * ch * 4)
    x = cargar_pista(es_path, s, fs, ch, tmp, int(round(d_s * fs)))
    original = (lambda tramos: cargar_tramos(en_path, st_en, fs, ch, tramos, vel)) if rellenar else None
    out = montar(x, fs, k, L, cortes, en_len, int(round(pre_s * fs)), original, lienzo(tmp), curva=curva,
                 puentes=puentes)[0]
    x = None
    layout = s.get("channel_layout") or {1: "mono", 2: "stereo", 6: "5.1"}.get(ch, f"{ch}c")
    bitrate = bitrate_salida(codec, s, es_path, canales, kbps)
    cambio = codificar(out, fs, layout, codec, bitrate, ruta, canales)
    out = None
    if tmp:
        shutil.rmtree(tmp, ignore_errors=True)
    return bitrate, cambio


def audios_para_muxear(es_path, out_path):
    """Las otras pistas del doblaje ya sincronizadas (en el orden del archivo), con su idioma y título."""
    try:
        pistas = pistas_audio(es_path)
    except Exception:
        return []
    out = []
    for s in pistas:
        ruta = ruta_pista_extra(out_path, s)
        if os.path.exists(ruta) and os.path.normcase(ruta) != os.path.normcase(out_path):
            titulo = next((v for k, v in (s.get("tags") or {}).items() if k.lower() == "title"), "")
            out.append(dict(ruta=ruta, idioma=idioma_pista(s), titulo=titulo))
    return out


# ---------------------------------------------------------------- muxear en el vídeo original

# código ISO 639-2 para cuando no hay mkvmerge (ffmpeg no escribe la etiqueta IETF, p. ej. es-ES)
LEGADO = {"es": "spa", "en": "eng", "ca": "cat", "gl": "glg", "eu": "baq", "fr": "fre", "de": "ger",
          "it": "ita", "pt": "por", "ja": "jpn"}


def ruta_mkvmerge():
    """mkvmerge del PATH o de la instalación normal de MKVToolNix (no siempre se añade al PATH)."""
    for c in (shutil.which("mkvmerge"),
              os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"), "MKVToolNix", "mkvmerge.exe"),
              os.path.join(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"), "MKVToolNix", "mkvmerge.exe")):
        if c and os.path.isfile(c):
            return c
    return None


RE_EPISODIO = re.compile(r"[Ss](\d{1,2})[ ._-]?[Ee](\d{1,3})|(?<!\d)(\d{1,2})x(\d{1,3})(?!\d)")


def titulo_contenedor(path):
    """Título del archivo (el que muestran los reproductores), o "" si no tiene."""
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format_tags", "-of", "json", path],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", **SIN_VENTANA)
    tags = (json.loads(r.stdout or "{}").get("format") or {}).get("tags") or {}
    return next((str(v).strip() for k, v in tags.items() if k.lower() == "title"), "")


def limpiar_nombre(texto, exige_ep):
    """Lo que va detrás de 2x03 / S02E03, sin [etiquetas] ni separadores. Sin 2x03 en el texto
    solo vale si exige_ep es falso (un título que ya es solo el nombre)."""
    t = texto.replace("_", " ")
    if " " not in t:
        t = t.replace(".", " ")         # nombres con puntos en vez de espacios
    m = RE_EPISODIO.search(t)
    if m:
        t = t[m.end():]
    elif exige_ep:
        return ""
    t = re.sub(r"\[[^\]]*\][^\W\d_]{0,2}(?![^\W_])|\{[^}]*\}", " ", t)     # [TDTrip]l -> ""
    t = re.sub(r"\s+", " ", t).strip(" -–_.,")
    while (m := BASURA_FINAL.search(t)):                                   # "... dual esp ale", "... 720p"
        t = t[:m.start()].rstrip(" -–_.,")
    return t if re.search(r"[^\W\d_]", t) else ""


# restos habituales al final de los nombres de archivo que no son parte del título del episodio
BASURA_FINAL = re.compile(r"(?i)[\s(-]+(tdt ?rip|tdt|dvd ?rip|hdtv|web(-?dl|rip)?|low|dual|vose?|esp|spa|cast|eng|"
                          r"ale|ger|ingl[eé]s|\d{3,4}[pi]|[xh] ?26[45]|xvid|divx|aac|ac3|mp3|rip)\)?$")


def nombre_episodio(es_path):
    """Nombre del episodio: del título del castellano si lo tiene; si no, de su nombre de archivo."""
    return (limpiar_nombre(titulo_contenedor(es_path), False)
            or limpiar_nombre(os.path.splitext(os.path.basename(es_path))[0], True))


def expandir_plantilla(plantilla, ep, nombre):
    """{ep} = 1x03, {sxe} = S01E03, {temporada} = 1, {episodio} = 03, {nombre} = nombre del episodio."""
    valores = {"ep": f"{ep[0]}x{ep[1]:02d}" if ep else "", "sxe": f"S{ep[0]:02d}E{ep[1]:02d}" if ep else "",
               "temporada": str(ep[0]) if ep else "", "episodio": f"{ep[1]:02d}" if ep else "", "nombre": nombre or ""}
    s = re.sub(r"\{(ep|sxe|temporada|episodio|nombre)\}", lambda m: valores[m[1]], plantilla)
    s = re.sub(r'""|“”|\(\s*\)', "", s)          # comillas o paréntesis que se han quedado vacíos
    return re.sub(r"\s+", " ", s).strip()


def nombre_valido(texto):
    """El texto como nombre de archivo de Windows."""
    t = texto.replace(":", " -")
    t = re.sub(r'[<>"/\\|?*\x00-\x1f]', "", t)
    return re.sub(r"\s+", " ", t).strip(" .")[:200]


def ruta_mux(en_path, carpeta=None, titulo="Castellano", nombre=None):
    """MKV final: `nombre` o el del original, en .mkv, junto al original o en `carpeta`. Nunca es el
    propio original: si lo fuera (el original ya es un .mkv en esa carpeta) se añade « [título]»."""
    base = (nombre_valido(nombre) if nombre else "") or os.path.splitext(os.path.basename(en_path))[0]
    ruta = os.path.join(carpeta or os.path.dirname(en_path), base + ".mkv")
    if os.path.normcase(os.path.abspath(ruta)) == os.path.normcase(os.path.abspath(en_path)):
        limpio = re.sub(r'[<>:"/\\|?*]', "", titulo)
        ruta = os.path.join(os.path.dirname(ruta), f"{base} [{limpio}].mkv")
    return ruta


def muxear(en_path, audio_path, mkv_path, idioma="es-ES", titulo="Castellano", p=print, titulo_video=None,
           forzados=None, forz_titulo="Forzados", subtitulos=(), audios=(), vel=Fraction(1)):
    """Mete el audio sincronizado en el vídeo original como primera pista de audio y predeterminada,
    con idioma y título; el resto de pistas se copian tal cual y dejan de ser predeterminadas.
    titulo_video: título del archivo nuevo (None = el que tenga el original).
    forzados: .srt que va como primer subtítulo, forzado y predeterminado, con el mismo idioma.
    subtitulos: los del doblaje ya ajustados (subs_para_muxear), detrás, con su idioma, título y marcas.
    Si alguno de los nuevos es predeterminado, los subtítulos del original dejan de serlo.
    audios: las otras pistas dobladas ya sincronizadas (audios_para_muxear), detrás de la principal y antes
    de las del original, con su idioma y título, sin ser predeterminadas.
    vel: velocidad del doblaje frente al original (mapa["vel"]); si no es 1, el original se adapta: el vídeo
    cambia de fps sin recodificar, sus subtítulos y capítulos se reescalan y sus audios se aceleran (en AC3).
    Devuelve la línea para el informe."""
    subtitulos, audios, vel = list(subtitulos), list(audios), Fraction(vel)
    pred_nuevo = bool(forzados) or any(s["pred"] for s in subtitulos)
    if not os.path.exists(en_path):
        raise RuntimeError(f"ya no existe el original {en_path}")
    if pista_video(en_path) is None:
        raise RuntimeError("el original no tiene vídeo")
    if os.path.exists(mkv_path):
        raise RuntimeError(f"ya existe {mkv_path}")
    p(f"Muxeando en {os.path.basename(mkv_path)}...")
    mkvmerge = ruta_mkvmerge()
    if vel != 1 and not mkvmerge:
        raise RuntimeError("para adaptar la velocidad del original hace falta MKVToolNix (mkvmerge)")
    tmp = tempfile.mkdtemp(prefix="muxeado_") if vel != 1 else None
    try:
        return _muxear(en_path, audio_path, mkv_path, idioma, titulo, p, titulo_video, forzados, forz_titulo,
                       subtitulos, audios, vel, pred_nuevo, mkvmerge, tmp)
    finally:
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)


def audios_acelerados(en_path, pistas, vel, carpeta, p=print):
    """Los audios del original a la velocidad del doblaje (más rápidos y agudos, como una emisión PAL), en AC3:
    al usuario le da igual su calidad y así es rápido. Devuelve [(pista de mkvmerge, archivo, retraso en ms)]."""
    st = {s["index"]: s for s in pistas_audio(en_path)}
    out = []
    for t in pistas:
        if t["type"] != "audio":
            continue
        s = st.get(t["id"]) or {}
        sr = int(s.get("sample_rate") or t["properties"].get("audio_sampling_frequency") or 48000)
        ch = min(int(t["properties"].get("audio_channels") or s.get("channels") or 2), 6)
        ruta = os.path.join(carpeta, f"audio{t['id']}.ac3")
        p(f"  Acelerando el audio {t['id']} del original ({ch} canales)...")
        r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", en_path, "-map", f"0:{t['id']}", "-af",
                            HUECOS + "," + filtro_velocidad(sr, vel, sr), "-ac", str(ch),
                            "-c:a", "ac3", "-b:a", "448k" if ch > 2 else "192k", ruta],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", **SIN_VENTANA)
        if r.returncode != 0:
            raise RuntimeError("no se ha podido acelerar un audio del original: "
                               + " ".join(r.stderr.strip().splitlines()[-1:]))
        # donde empezaba, a la nueva velocidad, menos las 256 muestras que adelanta el codificador AC3
        retraso = round((float(s.get("start_time") or 0) / float(vel) - 256 / sr) * 1000)
        out.append((t, ruta, retraso))
    return out


def _muxear(en_path, audio_path, mkv_path, idioma, titulo, p, titulo_video, forzados, forz_titulo, subtitulos,
            audios, vel, pred_nuevo, mkvmerge, tmp):
    if mkvmerge:
        r = subprocess.run([mkvmerge, "-J", en_path], capture_output=True, text=True, encoding="utf-8",
                           errors="replace", **SIN_VENTANA)
        pistas = json.loads(r.stdout or "{}").get("tracks") or []
        if not pistas:
            raise RuntimeError(f"mkvmerge no reconoce {os.path.basename(en_path)}")
        acelerados = audios_acelerados(en_path, pistas, vel, tmp, p) if vel != 1 else []
        variable = vel != 1 and fps_variable(en_path)
        n_forz = 2 + len(audios) + len(acelerados)      # números de archivo: forzados y primer subtítulo
        primero = n_forz + (1 if forzados else 0)
        cmd = [mkvmerge, "-o", mkv_path] + (["--title", titulo_video] if titulo_video else [])
        for t in pistas:
            if t["type"] == "audio" or (pred_nuevo and t["type"] == "subtitles"):
                cmd += ["--default-track-flag", f"{t['id']}:no"]
        fps_nuevo = None
        if vel != 1:
            # el original, a la velocidad del doblaje: el vídeo cambia de fps sin recodificar; sus subtítulos y
            # capítulos se reescalan; sus audios se sustituyen por los acelerados
            cmd += ["--no-audio", "--chapter-sync", f"0,{vel.denominator}/{vel.numerator}"]
            # con fps variable no se puede fijar una duración de fotograma: se reescalan sus marcas de tiempo, que
            # conservan las diferencias entre fotogramas
            fps = None if variable else fps_video(en_path)
            for t in pistas:
                if t["type"] == "video" and fps:
                    fps_nuevo = fps * vel
                    cmd += ["--default-duration", f"{t['id']}:{fps_nuevo.numerator}/{fps_nuevo.denominator}p",
                            "--fix-bitstream-timing-information", f"{t['id']}:1"]
                elif t["type"] in ("video", "subtitles"):
                    cmd += ["--sync", f"{t['id']}:0,{vel.denominator}/{vel.numerator}"]
        cmd += [en_path, "--language", f"0:{idioma}", "--track-name", f"0:{titulo}",
                "--default-track-flag", "0:yes", audio_path]
        for a in audios:
            cmd += ((["--language", f"0:{a['idioma']}"] if a["idioma"] else [])
                    + (["--track-name", f"0:{a['titulo']}"] if a["titulo"] else [])
                    + ["--default-track-flag", "0:no", a["ruta"]])
        for t, ruta, retraso in acelerados:
            pr = t["properties"]
            leng = pr.get("language_ietf") or pr.get("language")
            cmd += ((["--language", f"0:{leng}"] if leng and leng != "und" else [])
                    + (["--track-name", f"0:{pr['track_name']}"] if pr.get("track_name") else [])
                    + ["--default-track-flag", "0:no", "--sync", f"0:{retraso}", ruta])
        if forzados:
            cmd += ["--language", f"0:{idioma}", "--track-name", f"0:{forz_titulo}", "--forced-display-flag", "0:yes",
                    "--default-track-flag", "0:yes", "--sub-charset", "0:UTF-8", forzados]
        for s in subtitulos:
            si = lambda x: "yes" if x else "no"
            cmd += (["--language", f"0:{s['idioma']}"] + (["--track-name", f"0:{s['titulo']}"] if s["titulo"] else [])
                    + ["--default-track-flag", f"0:{si(s['pred'])}", "--forced-display-flag", f"0:{si(s['forz'])}"]
                    + (["--sub-charset", f"0:{s['cod']}"] if s["ruta"].lower().endswith(".srt") else []) + [s["ruta"]])
        tipo = lambda *ts: [f"0:{t['id']}" for t in pistas if t["type"] in ts]
        audios_orig = ([f"{2 + len(audios) + k}:0" for k in range(len(acelerados))] if vel != 1
                       else tipo("audio"))
        orden = (tipo("video") + ["1:0"] + [f"{2 + k}:0" for k in range(len(audios))] + audios_orig
                 + ([f"{n_forz}:0"] if forzados else [])
                 + [f"{primero + k}:0" for k in range(len(subtitulos))] + tipo("subtitles")
                 + [f"0:{t['id']}" for t in pistas if t["type"] not in ("video", "audio", "subtitles")])
        cmd += ["--track-order", ",".join(orden)]
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", **SIN_VENTANA)
        if r.returncode >= 2:           # 1 = terminó con advertencias
            borrar_si_existe(mkv_path)
            raise RuntimeError("mkvmerge falló: " + " ".join((r.stdout or r.stderr).strip().splitlines()[-2:]))
        etiqueta, con = idioma, "mkvmerge"
    else:
        legado = lambda x: LEGADO.get(x.split("-")[0].lower(), x[:3].lower()) if "-" in x or len(x) == 2 else x
        etiqueta = legado(idioma)
        n_forz = 2 + len(audios)                        # números de archivo: forzados y primer subtítulo
        primero = n_forz + (1 if forzados else 0)
        cmd = ["ffmpeg", "-v", "error", "-n", "-i", en_path, "-i", audio_path]
        cmd += [x for a in audios for x in ("-i", a["ruta"])] + (["-i", forzados] if forzados else [])
        for s in subtitulos:
            cmd += (["-sub_charenc", s["cod"]] if s["ruta"].lower().endswith(".srt") else []) + ["-i", s["ruta"]]
        cmd += ["-map", "0:v", "-map", "1:a:0"] + [x for k in range(len(audios)) for x in ("-map", f"{2 + k}:a:0")]
        cmd += ["-map", "0:a?"] + (["-map", f"{n_forz}:s:0"] if forzados else [])
        cmd += [x for k in range(len(subtitulos)) for x in ("-map", f"{primero + k}:s:0")]
        cmd += ["-map", "0:s?", "-map", "0:t?", "-c", "copy",
                "-disposition:v:0", "default", "-disposition:a", "0", "-disposition:a:0", "default",
                "-metadata:s:a:0", f"language={etiqueta}", "-metadata:s:a:0", f"title={titulo}"]
        for k, a in enumerate(audios, 1):
            cmd += ([f"-metadata:s:a:{k}", f"language={legado(a['idioma'])}"] if a["idioma"] else [])
            cmd += [f"-metadata:s:a:{k}", f"title={a['titulo']}"] if a["titulo"] else []
        if pred_nuevo:
            cmd += ["-disposition:s", "0"]
        if forzados:
            cmd += ["-disposition:s:0", "default+forced",
                    "-metadata:s:s:0", f"language={etiqueta}", "-metadata:s:s:0", f"title={forz_titulo}"]
        for k, s in enumerate(subtitulos, 1 if forzados else 0):
            marcas = "+".join(x for x, v in (("default", s["pred"]), ("forced", s["forz"])) if v) or "0"
            cmd += [f"-disposition:s:{k}", marcas, f"-metadata:s:s:{k}", f"language={legado(s['idioma'])}"]
            cmd += [f"-metadata:s:s:{k}", f"title={s['titulo']}"] if s["titulo"] else []
        cmd += (["-metadata", f"title={titulo_video}"] if titulo_video else []) + [mkv_path]
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", **SIN_VENTANA)
        if r.returncode != 0:
            borrar_si_existe(mkv_path)
            raise RuntimeError("ffmpeg falló al muxear: " + " ".join(r.stderr.strip().splitlines()[-2:]))
        con = f"ffmpeg; sin MKVToolNix el idioma queda «{etiqueta}» en vez de «{idioma}»"
    extra = ""
    if vel != 1:
        extra += ("; original adaptado a la velocidad del doblaje"
                  + (f" (vídeo a {float(fps_nuevo):.3f} fps sin recodificar" if fps_nuevo else
                     " (vídeo de fps variable, marcas de tiempo reescaladas sin recodificar" if mkvmerge and variable
                     else " (")
                  + ", sus audios acelerados en AC3)")
    extra += f"; {len(audios)} audio(s) más del doblaje" if audios else ""
    extra += f"; forzados {etiqueta} «{forz_titulo}»" if forzados else ""
    extra += f"; {len(subtitulos)} subtítulo(s) del doblaje" if subtitulos else ""
    extra += f"; título del vídeo «{titulo_video}»" if titulo_video else ""
    linea = f"Muxeado: {mkv_path} (primer audio y predeterminado: {etiqueta} «{titulo}»{extra}; con {con})"
    p(linea)
    return linea


def leer_mapa(salida):
    """El mapa de cortes que guardó el informe del audio sincronizado, o None."""
    informe = os.path.splitext(salida)[0] + "_informe.txt"
    if not os.path.exists(informe):
        return None
    with open(informe, encoding="utf-8") as f:
        return next((json.loads(x[6:]) for x in reversed(f.read().splitlines()) if x.startswith("Mapa: ")), None)


def velocidad_del_mapa(mapa):
    return Fraction(*mapa["vel"]) if mapa and mapa.get("vel") else Fraction(1)


def borrar_si_existe(ruta):
    try:
        os.remove(ruta)
    except OSError:
        pass


def episodio(nombre):
    """(temporada, episodio) del nombre de un archivo: S01E03 o 1x03. Si no lleva ninguno, el último número suelto
    como episodio de la temporada 1 (numeración absoluta: «Goleadores 01», «Moero! Top Striker 02»; antes todos se
    quedaban sin episodio y en la misma fila), sin contar lo que va entre corchetes o paréntesis (grupo, año),
    resoluciones, códecs ni canales; o None."""
    m = re.search(r"[Ss](\d{1,2})[ ._-]?[Ee](\d{1,3})", nombre) or re.search(r"(?<!\d)(\d{1,2})x(\d{1,3})(?!\d)", nombre)
    if m:
        return int(m[1]), int(m[2])
    t = re.sub(r"\[[^\]]*\]|\([^)]*\)", " ", os.path.splitext(nombre)[0])
    t = re.sub(r"(?i)\d{3,4}[pi]\b|\b[xh]\.?26[45]\b|\d+ ?bits?\b|\d\.\d\b", " ", t)
    nums = re.findall(r"(?<![^\W_])(\d{1,3})(?![^\W_])", t)
    return (1, int(nums[-1])) if nums else None


def main():
    ap = argparse.ArgumentParser(description="Sincroniza un doblaje con la pista original usando música y efectos.")
    ap.add_argument("doblaje", nargs="?")
    ap.add_argument("original", nargs="?")
    ap.add_argument("-o", "--salida")
    ap.add_argument("--subs", help="subtítulo .srt del doblaje, del original o de otra versión (se averigua con la voz); "
                                   "se corrigen sus erratas de tiempos y se lleva al audio sincronizado")
    ap.add_argument("--solo-subs", metavar="VIDEO",
                    help="solo subtítulos: ajusta el de --subs a un vídeo ya hecho (con su audio, p. ej. el final ya "
                         "muxeado), comparándolo con su voz; con --muxear, además, en un MKV nuevo (el vídeo no se toca)")
    ap.add_argument("--lote", nargs=2, metavar=("CARPETA_DOBLAJES", "CARPETA_ORIGINALES"),
                    help="los .srt con el mismo nombre que cada MKV se ajustan también")
    ap.add_argument("--idioma", default=None,
                    help="etiqueta del nombre del audio sincronizado (…_[es-ES]_SYNC.mka); por defecto, --mux-idioma")
    ap.add_argument("--formato", choices=("flac", "aac", "ac3", "opus"), default="flac",
                    help="formato del audio doblado cuando hay que recodificarlo (cortes o rellenos); por defecto flac. "
                         "Los kb/s, automáticos (los del doblaje si ya iba en ese formato) salvo que se pidan con --kbps")
    ap.add_argument("--canales", choices=CANALES_SALIDA, default="igual",
                    help="canales del audio doblado: los suyos (igual, por defecto) o 2.0 (un mono va igual a los dos "
                         "lados; un 5.1 se mezcla a estéreo); con 2.0 se recodifica aunque no haya cortes")
    ap.add_argument("--kbps", type=int, default=None,
                    help="kb/s del audio doblado en AAC, AC3 u Opus (se lleva al admitido más cercano); por defecto, "
                         "automáticos. Si no son los que ya tiene, se recodifica aunque no haya cortes")
    ap.add_argument("--sin-cortes", choices=("intacto", "convertir", "preguntar"), default="intacto",
                    help="sin cortes ni rellenos, el doblaje puede ir tal cual: dejarlo intacto (por defecto), "
                         "convertirlo al formato elegido o preguntar cada vez")
    ap.add_argument("--pista", type=int, help="pista de audio del doblaje que se sincroniza (1, 2...); por defecto se detecta")
    ap.add_argument("--guia", type=int, help="pista del archivo del doblaje en versión original, para medir con ella "
                                             "(0 = ninguna); por defecto se detecta")
    ap.add_argument("--pista-original", type=int,
                    help="pista de audio del original con la que se mide (1, 2...); por defecto, si trae varias, la "
                         "del idioma que también está en el doblaje (su versión original) o, si no se sabe, la 1")
    ap.add_argument("--medir", choices=("auto", "audio", "video"), default="auto",
                    help="con qué se mide: audio (música y efectos), video (cambios de plano) o auto "
                         "(audio y, si el doblaje lleva otra mezcla, vídeo)")
    ap.add_argument("--correcciones", default="",
                    help="ajustes a mano del castellano en ms, en todo el episodio o entre dos tiempos del vídeo final "
                         "(mm:ss), separados con ';': p. ej. \"-100; 15:44-16:09 +700\" (+ lo retrasa, - lo adelanta)")
    ap.add_argument("--estirar-variable", action="store_true",
                    help="si la velocidad del doblaje varía (VHS), estirar el castellano siguiendo la del original en "
                         "vez de cortarlo (solo los saltos de verdad se cortan; el original no se toca)")
    ap.add_argument("--limpiar", action="store_true",
                    help="quita el ruido de la cinta de la pista doblada (VHS: continua, cortes de la captura, "
                         "chasquidos, zumbido y siseo) antes de montarla; tarda unos minutos")
    ap.add_argument("--sin-relleno-original", action="store_true",
                    help="no rellenar con el audio original lo que le falte al doblaje (queda en silencio o con "
                         "el ruido de fondo del doblaje)")
    ap.add_argument("--muxear", nargs="?", const="", metavar="MKV",
                    help="mete el audio sincronizado en el vídeo original como primera pista de audio y "
                         "predeterminada; sin ruta, se crea junto al original con su nombre en .mkv")
    ap.add_argument("--solo-muxear", action="store_true",
                    help="no sincroniza: muxea el audio ya sincronizado (el de -o o el nombre por defecto)")
    ap.add_argument("--mux-idioma", default="es-ES", help="idioma de la pista muxeada (por defecto es-ES)")
    ap.add_argument("--mux-titulo", default="Castellano", help="título de la pista muxeada (por defecto Castellano)")
    ap.add_argument("--plantilla", help="nombre y título del vídeo muxeado, p. ej. \"Serie (1995) {ep} {nombre} [Dual]\"; "
                                        "{ep} = 1x03, {temporada}, {episodio} = 03, {nombre} = nombre del episodio "
                                        "(del título del castellano o de su nombre de archivo)")
    ap.add_argument("--titulo-video", help="título del vídeo muxeado tal cual (por defecto: el de la plantilla o, "
                                           "sin plantilla, el del castellano si lo tiene)")
    ap.add_argument("--forzados", action="store_true",
                    help="lee con el OCR de Windows los subtítulos quemados en la imagen del doblaje y los guarda "
                         "en _forzados.srt con los mismos cortes; al muxear van como subtítulo forzado")
    ap.add_argument("--forz-titulo", default="Forzados", help="título de la pista de forzados (por defecto Forzados)")
    ap.add_argument("--solo-pista-principal", action="store_true",
                    help="no sincronizar las demás pistas dobladas del doblaje (por defecto se sincronizan todas "
                         "menos las versiones originales, con los mismos cortes, y se muxean detrás de la principal)")
    ap.add_argument("--decodificar", choices=list(DECODIFICADORES), default="cpu",
                    help="con qué se decodifica el vídeo al medir con los cambios de plano o leer forzados: "
                         + ", ".join(f"{k} = {v[0]}" for k, v in DECODIFICADORES.items())
                         + ". Si la GPU falla, se usa la CPU (por defecto: cpu)")
    args = ap.parse_args()
    # análisis en marcha: el actualizador no cambia el programa mientras tanto (si no está o falla, da igual)
    try:
        import actualizador
        args.en_marcha = actualizador.registrar_instancia(os.path.dirname(os.path.abspath(__file__)), "motor", True)
    except Exception:
        args.en_marcha = None
    args.idioma = args.idioma or args.mux_idioma or "es-ES"
    if args.solo_muxear and args.muxear is None:
        args.muxear = ""
    try:
        correcciones = leer_correcciones(args.correcciones)
    except ValueError as e:
        ap.error(f"--correcciones: {e}")
    if args.solo_subs:
        if not args.subs:
            ap.error("--solo-subs necesita el subtítulo en --subs")
        salida = args.salida or ruta_subs_solo(args.solo_subs, args.idioma)
        mkv = (args.muxear or ruta_mux(args.solo_subs, titulo="con subtítulos")) if args.muxear is not None else None
        # hecho: el subtítulo o, si se muxea, el vídeo con él (al muxear no se deja copia del subtítulo)
        hecho = next((x for x in (salida, mkv) if x and os.path.exists(x)), None)
        if hecho:
            print(f"Ya existe, lo salto: {hecho}")
            return
        try:
            sincronizar_subtitulos(args.solo_subs, args.subs, salida)
        except Exception as e:
            import traceback
            aqui = [f for f in traceback.extract_tb(e.__traceback__) if f.filename == os.path.abspath(__file__)]
            donde = f"  [{aqui[-1].name}, línea {aqui[-1].lineno}]" if aqui and not isinstance(e, RuntimeError) else ""
            print(f"ERROR: {e}{donde}")
            return
        if mkv:
            lineas = []
            try:
                lineas = [muxear_subtitulo(args.solo_subs, salida, mkv, args.mux_idioma, args.mux_titulo)]
                lineas += sin_copia_subs([salida], mkv)
            except Exception as e:
                lineas = [f"No se pudo muxear: {e}"]
                print(lineas[0])
            with open(os.path.splitext(salida)[0] + "_informe.txt", "a", encoding="utf-8") as f:
                f.write("".join(x + "\n" for x in lineas))
        return

    trabajos = []
    if args.lote:
        dob, ori = args.lote
        originales = {episodio(os.path.basename(f)): f for f in glob.glob(os.path.join(ori, "*.mkv"))}
        for f in sorted(glob.glob(os.path.join(dob, "*"))):
            if not f.lower().endswith(AUDIO_EXT) or "_SYNC" in f:
                continue
            ep = episodio(os.path.basename(f))
            if ep in originales:
                srt = os.path.splitext(originales[ep])[0] + ".srt"
                trabajos.append((f, originales[ep], None, srt if os.path.exists(srt) else None))
            else:
                print(f"Sin original para {os.path.basename(f)}")
    elif args.doblaje and args.original:
        trabajos.append((args.doblaje, args.original, args.salida, args.subs))
    else:
        ap.error("indica DOBLAJE ORIGINAL o --lote")

    def mux(es_path, en_path, salida):
        """Muxea si se pidió y aún no existe; lo apunta en el informe. Un fallo aquí no invalida el audio."""
        if args.muxear is None:
            return ""
        try:
            nombre = None
            if args.plantilla:
                ep = episodio(os.path.basename(es_path)) or episodio(os.path.basename(en_path))
                nombre = expandir_plantilla(args.plantilla, ep, nombre_episodio(es_path))
            # sin plantilla ni título explícito se copia el del castellano o, si no tiene, el del original
            # (mkvmerge no pasa solo el título de un .avi)
            titulo_video = (args.titulo_video or nombre or titulo_contenedor(es_path)
                            or titulo_contenedor(en_path) or None)
            mkv = (args.muxear if args.muxear and len(trabajos) == 1
                   else ruta_mux(en_path, titulo=args.mux_titulo, nombre=nombre))
            if os.path.exists(mkv):
                print(f"Ya existe el vídeo muxeado, no se toca: {mkv}")
                return ", vídeo muxeado ya existía"
            forz = ruta_forzados(salida) if args.forzados and os.path.exists(ruta_forzados(salida)) else None
            subs = subs_para_muxear(es_path, salida, args.mux_idioma)
            linea = muxear(en_path, salida, mkv, args.mux_idioma, args.mux_titulo, titulo_video=titulo_video,
                           forzados=forz, forz_titulo=args.forz_titulo, subtitulos=subs,
                           audios=[] if args.solo_pista_principal else audios_para_muxear(es_path, salida),
                           vel=velocidad_del_mapa(leer_mapa(salida)))
        except Exception as e:
            print(f"No se pudo muxear: {e}")
            return f", SIN muxear ({e})"
        anotar(salida, [linea] + sin_copia_subs([s["ruta"] for s in subs], mkv))
        return ", muxeado"

    def anotar(salida, lineas):
        informe = os.path.splitext(salida)[0] + "_informe.txt"
        if os.path.exists(informe):
            with open(informe, "a", encoding="utf-8") as f:
                f.write("".join(x + "\n" for x in lineas))

    def subtitulos_aparte(es_path, salida):
        """Audio ya sincronizado: los subtítulos del doblaje que falten (y, si no trae, los forzados con OCR)
        se sacan con el mapa de cortes que guardó su informe."""
        pistas = pistas_sub_doblaje(es_path)
        faltan = [s for s in pistas if s["ext"] and not os.path.exists(ruta_sub_doblaje(salida, s))]
        ocr = args.forzados and not any(s["ext"] for s in pistas) and not os.path.exists(ruta_forzados(salida))
        if not faltan and not ocr:
            return
        mapa = leer_mapa(salida)
        if not mapa:
            print("Subtítulos: no se pueden ajustar sin el informe del audio sincronizado (lleva el mapa de cortes)")
            return
        lineas = []
        def p(msg=""):
            print(msg, flush=True); lineas.append(msg)
        t_audio = float(probe_audio(es_path, (args.pista or 1) - 1).get("start_time") or 0)
        if faltan:
            ajustar_subs_doblaje(es_path, t_audio, mapa, salida, p)
        if ocr:
            for a in generar_forzados(es_path, t_audio, mapa, salida, args.mux_idioma, p, args.decodificar)[1]:
                p(f"Aviso: {a}")
        anotar(salida, lineas)

    resumen = []
    for es_path, en_path, salida, sub in trabajos:
        salida = salida or ruta_salida(es_path, args.idioma, pista=args.pista)
        print("\n" + "=" * 78)
        existe = [x for x in (salida, sub and os.path.splitext(salida)[0] + os.path.splitext(sub)[1])
                  if x and os.path.exists(x)]
        if args.solo_muxear:
            if not os.path.exists(salida):
                print(f"ERROR: no existe el audio sincronizado {salida}"); resumen.append((es_path, "ERROR")); continue
            if args.muxear is not None and leer_mapa(salida) is None:
                # el informe guarda la velocidad y los cortes: sin él se muxearía sin adaptar el original, desfasado
                print("ERROR: falta el informe del audio sincronizado (..._informe.txt), que guarda la velocidad y "
                      "los cortes; sin él no se sabe si hay que adaptar el original. Vuelve a sincronizar.")
                resumen.append((es_path, "ERROR: falta el informe")); continue
            if sub and not os.path.exists(os.path.splitext(salida)[0] + os.path.splitext(sub)[1]):
                # al muxear no se deja copia del subtítulo ajustado; rehacerlo con el mapa daría por hecho que va con
                # el doblaje (sin las voces no se sabe para qué versión estaba hecho)
                print("Aviso: el subtítulo ajustado ya no está (al muxear no se deja copia): este vídeo irá sin él; "
                      "para meterlo, vuelve a sincronizar")
            subtitulos_aparte(es_path, salida)
            resumen.append((es_path, "audio ya sincronizado" + mux(es_path, en_path, salida))); continue
        if existe:
            print(f"Ya existe, lo salto: {existe[0]}"); resumen.append((es_path, "ya existía")); continue
        t_trabajo = time.time()
        try:
            avisos = sincronizar(es_path, en_path, salida, sub, args.pista, args.guia, args.pista_original,
                                 args.medir, not args.sin_relleno_original, args.forzados, args.mux_idioma,
                                 args.decodificar, not args.solo_pista_principal, args.formato, args.sin_cortes,
                                 args.estirar_variable, correcciones, limpiar=args.limpiar, canales=args.canales,
                                 kbps=args.kbps)
            hecho_mux = mux(es_path, en_path, salida)
            resumen.append((es_path, ("OK" if not avisos else f"OK con {len(avisos)} aviso(s)") + hecho_mux))
            if hecho_mux == ", muxeado":
                linea = f"Tiempo total, con el muxeado: {duracion(time.time() - t_trabajo)}"
                print(linea)
                anotar(salida, [linea])
            if args.muxear is None and velocidad_del_mapa(leer_mapa(salida)) != 1:
                aviso = ("Aviso: el doblaje va a otra velocidad y este audio cuadra con el original ADAPTADO a ella, "
                         "que solo se crea al muxear con este programa (--muxear o la casilla de la GUI; como el "
                         "audio ya existe, solo muxea). Metido a mano en el original tal cual NO cuadra.")
                print(aviso)
                anotar(salida, [aviso])
        except Exception as e:
            # dónde ha fallado (función y línea de este script), para poder arreglarlo a partir del informe
            import traceback
            aqui = [f for f in traceback.extract_tb(e.__traceback__) if f.filename == os.path.abspath(__file__)]
            donde = f"  [{aqui[-1].name}, línea {aqui[-1].lineno}]" if aqui and not isinstance(e, RuntimeError) else ""
            print(f"ERROR: {e}{donde}"); resumen.append((es_path, f"ERROR: {e}"))
            print(f"Tiempo hasta el error: {texto_tiempo(time.time() - t_trabajo)}")
    if len(trabajos) > 1:
        print("\n" + "=" * 78 + "\nResumen:")
        for f, r in resumen:
            print(f"  {os.path.basename(f)}: {r}")


if __name__ == "__main__":
    main()
